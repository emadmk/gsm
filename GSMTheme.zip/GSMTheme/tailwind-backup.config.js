/** @type {import('tailwindcss').Config} */

function withOpacity(variableName) {
  return ({ opacityValue }) => {
    if (opacityValue !== undefined) {
      return `rgba(var(${variableName}), ${opacityValue})`;
    }
    return `rgb(var(${variableName}))`;
  };
}

module.exports = {
  content: ["./**/*.{php,js}", "!./node_modules/**/*.{php,js}"],
  theme: {
    container: {
      center: true,
    },
    extend: {
      colors: {
        primary: {
          20: withOpacity("--primary-20"),
          500: withOpacity("--primary-500"),
          600: withOpacity("--primary-600"),
          700: withOpacity("--primary-700"),
        },
        green: {
          20: withOpacity("--green-20"),
          300: withOpacity("--green-300"),
          400: withOpacity("--green-400"),
          500: withOpacity("--green-500"),
        },
        yellow: {
          20: withOpacity("--yellow-20"),
          300: withOpacity("--yellow-300"),
          400: withOpacity("--yellow-400"),
          500: withOpacity("--yellow-500"),
        },
        red: {
          20: withOpacity("--red-20"),
          300: withOpacity("--red-300"),
          400: withOpacity("--red-400"),
          500: withOpacity("--red-500"),
        },
        gary: {
          20: withOpacity("--gary-20"),
          50: withOpacity("--gary-50"),
          100: withOpacity("--gary-100"),
          200: withOpacity("--gary-200"),
          300: withOpacity("--gary-300"),
          400: withOpacity("--gary-400"),
          500: withOpacity("--gary-500"),
          600: withOpacity("--gary-600"),
          700: withOpacity("--gary-700"),
          800: withOpacity("--gary-800"),
          900: withOpacity("--gary-900"),
        },
      },
      fontFamily: {
        sans: ["IranSansX", "arial", "sans-serif"],
      },
      fontSize: {},
      boxShadow: {},
      dropShadow: {},
      borderRadius: {},
      backgroundImage: {},
      backgroundSize: {},
      backgroundPosition: {},
      gridTemplateRows: {},
    },
  },
  plugins: [
    ({ addUtilities }) => {
      addUtilities({
        ".flex-center": {
          display: "flex",
          alignItems: "center",
          justifyContent: "center",
        },
        ".display-lg": {
          fontSize: "2.5rem",
          lineHeight: "3.75rem",
          fontWeight: 700,
        },
        ".display-sm": {
          fontSize: "2rem",
          lineHeight: "3rem",
          fontWeight: 700,
        },
        ".h1": {
          fontSize: "1.5rem",
          lineHeight: "2.25rem",
          fontWeight: 700,
        },
        ".h2": {
          fontSize: "1.25rem",
          lineHeight: "1.875rem",
          fontWeight: 600,
        },
        ".h3": {
          fontSize: "1.125rem",
          lineHeight: "1.75rem",
          fontWeight: 700,
        },
        ".h4": {
          fontSize: "1rem",
          lineHeight: "1.5rem",
          fontWeight: 700,
        },
        ".h5": {
          fontSize: "0.875rem",
          lineHeight: "1.3125rem",
          fontWeight: 700,
        },
        ".h6": {
          fontSize: "0.75rem",
          lineHeight: "1.125rem",
          fontWeight: 700,
        },
        ".subtitle-lg": {
          fontSize: "1rem",
          lineHeight: "1.75rem",
          fontWeight: 700,
        },
        ".subtitle-lg": {
          fontSize: "0.875rem",
          lineHeight: "1.5rem",
          fontWeight: 700,
        },
        ".body-lg": {
          fontSize: "1rem",
          lineHeight: "1.75rem",
          fontWeight: 400,
        },
        ".body-sm": {
          fontSize: "0.875rem",
          lineHeight: "1.5rem",
          fontWeight: 400,
        },
        ".caption": {
          fontSize: "0.75rem",
          lineHeight: "1.125rem",
          fontWeight: 400,
        },
        ".overline": {
          fontSize: "0.75rem",
          lineHeight: "1.125rem",
          fontWeight: 700,
        },
        "@screen md": {
          ".display-lg": {
            fontSize: "4rem",
            lineHeight: "6rem",
          },
          ".display-sm": {
            fontSize: "3rem",
            lineHeight: "4.5rem",
          },
          ".h1": {
            fontSize: "2rem",
            lineHeight: "3rem",
          },
          ".h2": {
            fontSize: "1.5rem",
            lineHeight: "2.25rem",
          },
          ".h3": {
            fontSize: "1.25rem",
            lineHeight: "1.875rem",
          },
          ".h4": {
            fontSize: "1.125rem",
            lineHeight: "1.625rem",
          },
          ".h5": {
            fontSize: "1rem",
            lineHeight: "1.5rem",
          },
          ".h6": {
            fontSize: "0.875rem",
            lineHeight: "1.3125rem",
          },
        },
      });
    },
  ],
};
