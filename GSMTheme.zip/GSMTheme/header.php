<?php
use GSM\templates\layouts\header\Header;
if (is_array($args) && isset($args)){
    $type =  $args['type'] ?? 'normal';
}
$header = new Header($type);
$header->displayContent();

