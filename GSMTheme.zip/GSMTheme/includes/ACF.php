<?php

namespace GSM\includes;

if (!defined('ABSPATH')) {
    exit;
}

class ACF
{
    protected $query;
    function __construct()
    {
        if (is_admin() && function_exists('acf_add_options_page')) {

            // add acf setting page
            acf_add_options_page(array(
                'page_title' => 'تنظیمات GSM',
                'menu_title' => 'تنظیمات GSM',
                'menu_slug' => 'admin-gsm-site',
                'capability' => 'edit_posts',
                'redirect' => false,
                'update_button' => 'ذخیره',
            ));
        }
        add_filter('acf/prepare_field/name=brands', [$this, 'brandsList']);
        add_filter('acf/prepare_field/name=products', [$this, 'productList']);
        // add_filter('acf/save_post', [$this, 'saveProductLabel']);
    }

    public function setQuery($query)
    {
        $this->query = $query;
        $this->ajaxActions();
    }

    public function ajaxActions()
    {
        if ($this->query == 'product') {
            $data = json_decode(stripslashes($_POST['data']));
            $search = sanitize_text_field($data->search);
            $products = Api::getGSMProducts(['search'=>$search]);

            $results = [];
            foreach ($products->data as $product) {
                $results[] = [
                    'id' => $product->id,
                    'text' => $product->title,
                ];
            }
            if (count($results) == 0) {
                ajaxResponse(false, __('محصولی یافت نشد','gsm'));
            }else{
                ajaxResponse(true, __('لیست جدید','gsm'), ['results' => $results]);
            }
        }
    }

    public static function brandsList($field)
    {
        $brandList = Api::getGSMBrands();
        foreach ($brandList->results as $brand) {
            $field['choices'][intval($brand->id)] = $brand->title;
        }
        return $field;
    }

    public static function productList($field)
    {
        global $post;
        $productIds = $field['value'];
        foreach ($productIds as $productId) {
            $product = Api::getGSMProduct($productId);
            $field['choices'][intval($product->id)] = $product->title . ' - ' . $product->variations->group_id;
        }
        return $field;
    }

    public static function saveProductLabel($postId) {}
}
