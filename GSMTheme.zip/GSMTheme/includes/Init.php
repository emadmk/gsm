<?php

namespace GSM\includes;

if (!defined('ABSPATH')) {
    exit;
}

class Init
{
    function __construct()
    {
        require_once GSM_DIR . '/includes/widgets/popularPost/popularPostWidget.php';
        require_once GSM_DIR . '/includes/widgets/shoppingGuide/shoppingGuideWidget.php';
        require_once GSM_DIR . '/includes/widgets/ads/adsWidget.php';
        require_once GSM_DIR . '/includes/widgets/brandRelatedPost/brandRelatedPostWidget.php';
        require_once GSM_DIR . '/includes/widgets/brandRelatedProduct/brandRelatedProductWidget.php';
        require_once GSM_DIR . '/includes/widgets/latestPost/latestPostWidget.php';
    }
    public function registerPostTypeAndTaxonomy()
    {
        if (!post_type_exists('article')) {

            // Set labels for article post type
            $labels = array(
                'name'          => esc_html__('مقاله', 'gsm'),
                'singular_name' => esc_html__('مقاله', 'gsm'),
                'search_items'  => esc_html__('جستجوی مقاله', 'gsm'),
                'all_items'     => esc_html__('همه مقاله ها', 'gsm'),
                'parent_item'   => esc_html__('مقاله مادر', 'gsm'),
                'add_new'   => esc_html__('مقاله جدید', 'gsm'),
                'not_found'   => esc_html__('مقاله ی یافت نشد', 'gsm'),
                'archives'   => esc_html__('بایگانی مقالات', 'gsm'),
                'insert_into_item'   => esc_html__('قرار دادن درون مقاله', 'gsm'),
                'item_link'   => esc_html__('لینک مقاله', 'gsm'),
                'edit_item'     => esc_html__('ویرایش مقاله', 'gsm'),
                'new_item'     => esc_html__('مقاله جدید', 'gsm'),
                'add_new_item'  => esc_html__('افزودن مقاله جدید', 'gsm'),
                'view_item'     => esc_html__('نمایش مقاله', 'gsm'),
                'view_items'     => esc_html__('نمایش مقاله ها', 'gsm'),
                'item_updated'   => esc_html__('بروزرسانی مقاله', 'gsm'),
                'item_trashed'   => esc_html__('زباله دان مقاله', 'gsm'),
                'menu_name'     => esc_html__('مقاله ها', 'gsm')
            );

            // Set main arguments for article post type
            $args = array(
                'labels'          => $labels,
                'singular_label'  => esc_html__('مقاله ها', 'gsm'),
                'public'          => true,
                'capability_type' => 'post',
                'show_ui'         => true,
                'show_in_menu'    => true,
                'hierarchical'    => false,
                'menu_position'   => 10,
                'menu_icon'       => 'dashicons-media-document',
                'supports'        => ['title', 'editor','author', 'comments', 'thumbnail', 'custom-fields', 'excerpt', 'page-attributes'],
                'rewrite'         => array(
                    'slug' => 'articles',
                    'with_front' => false
                ),
                'taxonomies'      => array('post_tag'),
                // 'has_archive' => 'article',
            );

            // Register article post type
            register_post_type('article', $args);
        }

        if (!post_type_exists('review')) {

            // Set labels for review post type
            $labels = array(
                'name'          => esc_html__('بررسی', 'gsm'),
                'singular_name' => esc_html__('بررسی', 'gsm'),
                'search_items'  => esc_html__('جستجوی بررسی ها', 'gsm'),
                'all_items'     => esc_html__('همه بررسی ها', 'gsm'),
                'parent_item'   => esc_html__('بررسی مادر', 'gsm'),
                'add_new'   => esc_html__('بررسی جدید', 'gsm'),
                'not_found'   => esc_html__('بررسی یافت نشد', 'gsm'),
                'archives'   => esc_html__('بایگانی بررسی ها', 'gsm'),
                'insert_into_item'   => esc_html__('قرار دادن درون بررسی', 'gsm'),
                'item_link'   => esc_html__('لینک بررسی', 'gsm'),
                'edit_item'     => esc_html__('ویرایش بررسی', 'gsm'),
                'new_item'     => esc_html__('بررسی جدید', 'gsm'),
                'add_new_item'  => esc_html__('افزودن بررسی جدید', 'gsm'),
                'view_item'     => esc_html__('نمایش بررسی', 'gsm'),
                'view_items'     => esc_html__('نمایش بررسی ها', 'gsm'),
                'item_updated'   => esc_html__('بروزرسانی بررسی', 'gsm'),
                'item_trashed'   => esc_html__('حذف بررسی', 'gsm'),
                'menu_name'     => esc_html__('بررسی ها', 'gsm')
            );

            // Set main arguments for review post type
            $args = array(
                'labels'          => $labels,
                'singular_label'  => esc_html__('بررسی ها', 'gsm'),
                'public'          => true,
                'capability_type' => 'post',
                'show_ui'         => true,
                'show_in_menu'    => true,
                'hierarchical'    => false,
                'menu_position'   => 10,
                'menu_icon'       => 'dashicons-media-document',
                'supports'        => ['title', 'editor', 'author', 'comments', 'thumbnail', 'custom-fields', 'excerpt', 'page-attributes'],
                'rewrite'         => array(
                    'slug' => 'reviews',
                    'with_front' => false
                ),
                'taxonomies'      => array('post_tag'),
                // 'has_archive' => 'review',
            );

            // Register review post type
            register_post_type('review', $args);
        }

        
        if (!post_type_exists('news')) {

            // Set labels for review post type
            $labels = array(
                'name'          => esc_html__('خبر', 'gsm'),
                'singular_name' => esc_html__('خبر', 'gsm'),
                'search_items'  => esc_html__('جستجوی خبرها', 'gsm'),
                'all_items'     => esc_html__('همه خبرها', 'gsm'),
                'parent_item'   => esc_html__('خبر مادر', 'gsm'),
                'add_new'   => esc_html__('خبر جدید', 'gsm'),
                'not_found'   => esc_html__('خبر یافت نشد', 'gsm'),
                'archives'   => esc_html__('بایگانی خبرها', 'gsm'),
                'insert_into_item'   => esc_html__('قرار دادن درون خبر', 'gsm'),
                'item_link'   => esc_html__('لینک خبر', 'gsm'),
                'edit_item'     => esc_html__('ویرایش خبر', 'gsm'),
                'new_item'     => esc_html__('خبر جدید', 'gsm'),
                'add_new_item'  => esc_html__('افزودن خبر جدید', 'gsm'),
                'view_item'     => esc_html__('نمایش خبر', 'gsm'),
                'view_items'     => esc_html__('نمایش خبرها', 'gsm'),
                'item_updated'   => esc_html__('بروزرسانی خبر', 'gsm'),
                'item_trashed'   => esc_html__('حذف خبر', 'gsm'),
                'menu_name'     => esc_html__('خبرها', 'gsm')
            );

            // Set main arguments for review post type
            $args = array(
                'labels'          => $labels,
                'singular_label'  => esc_html__('خبرها', 'gsm'),
                'public'          => true,
                'capability_type' => 'post',
                'show_ui'         => true,
                'show_in_menu'    => true,
                'hierarchical'    => false,
                'menu_position'   => 10,
                'menu_icon'       => 'dashicons-media-document',
                'supports'        => ['title', 'editor', 'author', 'comments', 'thumbnail', 'custom-fields', 'excerpt', 'page-attributes'],
                'rewrite'         => array(
                    'slug' => 'news',
                    'with_front' => false
                ),
                'taxonomies'      => array('post_tag'),
                // 'has_archive' => 'news',
            );

            // Register review post type
            register_post_type('news', $args);
        }

        // register brand
        // $brandLabels = array(
        //     'name'          => esc_html__('برند', 'gsm'),
        //     'singular_name' => esc_html__('برند', 'gsm'),
        //     'search_items'  => esc_html__('جستجوی برند', 'gsm'),
        //     'all_items'     => esc_html__('همه برند ها', 'gsm'),
        //     'parent_item'   => esc_html__('برند مادر', 'gsm'),
        //     'no_terms'   => esc_html__('برند یافت نشد', 'gsm'),
        //     'item_link'   => esc_html__('لینک برند', 'gsm'),
        //     'edit_item'     => esc_html__('ویرایش برند', 'gsm'),
        //     'view_item'     => esc_html__('نمایش برند', 'gsm'),
        //     'view_items'     => esc_html__('نمایش برند ها', 'gsm'),
        //     'new_item'     => esc_html__('برند جدید', 'gsm'),
        //     'add_new_item'  => esc_html__('افزودن برند جدید', 'gsm'),
        //     'item_updated'   => esc_html__('بروزرسانی برند', 'gsm'),
        //     'item_trashed'   => esc_html__('حذف برند', 'gsm'),
        //     'menu_name'     => esc_html__('برند ها', 'gsm')
        // );
        // $brandArgs = array(
        //     'labels'          => $brandLabels,
        //     'public'          => true,
        //     'show_ui'         => true,
        //     'hierarchical'    => false,
        //     'show_in_quick_edit'    => true,
        //     'show_admin_column'    => true,
        //     'rewrite'         => array(
        //         'slug' => 'brand',
        //         'with_front' => false,
        //         'hierarchical' => false,
        //     ),

        // );
        // register_taxonomy('brand', ['article', 'post', 'review'], $brandArgs);
    }

    public function registerSidebarAndWidgets()
    {
        // news list sidebar
        register_sidebar(array(
            'name'          => __('سایدبار لیست خبرها', 'gsm'),
            'id'            => 'news-list-sidebar',
            'description'   => __('سایدبار اختصاصی برای صفحه لیست خبرها', 'gsm'),
            'before_widget' => '<div class="widget %2$s">',
            'after_widget'  => '</div>',
            'before_title'  => '<h2 class="widget-title">',
            'after_title'   => '</h2>',
        ));
        // news single page sidebar
        register_sidebar(array(
            'name'          => __('سایدبار صفحه تکی خبر', 'gsm'),
            'id'            => 'news-single-sidebar',
            'description'   => __('سایدبار اختصاصی برای صفحه تکی خبر', 'gsm'),
            'before_widget' => '<div class="widget %2$s">',
            'after_widget'  => '</div>',
            'before_title'  => '<h2 class="widget-title">',
            'after_title'   => '</h2>',
        ));
        // register_sidebar(array(
        //     'name'          => __('سایدبار صفحه تکی خبر (تبلیغات موبایل)', 'gsm'),
        //     'id'            => 'news-single-sidebar-mobile-ads',
        //     'description'   => __('سایدبار اختصاصی برای صفحه تکی خبر (تبلیغات موبایل)', 'gsm'),
        //     'before_widget' => '<div class="widget %2$s">',
        //     'after_widget'  => '</div>',
        //     'before_title'  => '<h2 class="widget-title">',
        //     'after_title'   => '</h2>',
        // ));
        // article list sidebar
        register_sidebar(array(
            'name'          => __('سایدبار لیست مقاله ها', 'gsm'),
            'id'            => 'article-list-sidebar',
            'description'   => __('سایدبار اختصاصی برای صفحه لیست مقاله ها', 'gsm'),
            'before_widget' => '<div class="widget %2$s">',
            'after_widget'  => '</div>',
            'before_title'  => '<h2 class="widget-title">',
            'after_title'   => '</h2>',
        ));
        // articles single page sidebar
        register_sidebar(array(
            'name'          => __('سایدبار صفحه تکی مقاله', 'gsm'),
            'id'            => 'articles-single-sidebar',
            'description'   => __('سایدبار اختصاصی برای صفحه تکی مقاله', 'gsm'),
            'before_widget' => '<div class="widget %2$s">',
            'after_widget'  => '</div>',
            'before_title'  => '<h2 class="widget-title">',
            'after_title'   => '</h2>',
        ));
        // register_sidebar(array(
        //     'name'          => __('سایدبار صفحه تکی مقاله (تبلیغات موبایل)', 'gsm'),
        //     'id'            => 'articles-single-sidebar-mobile-ads',
        //     'description'   => __('سایدبار اختصاصی برای صفحه تکی مقاله (تبلیغات موبایل)', 'gsm'),
        //     'before_widget' => '<div class="widget %2$s">',
        //     'after_widget'  => '</div>',
        //     'before_title'  => '<h2 class="widget-title">',
        //     'after_title'   => '</h2>',
        // ));

        // tags page sidebar
        register_sidebar(array(
            'name'          => __('سایدبار صفحه تگ ها', 'gsm'),
            'id'            => 'tag-list-sidebar',
            'description'   => __('سایدبار اختصاصی برای صفحه تگ ها', 'gsm'),
            'before_widget' => '<div class="widget %2$s">',
            'after_widget'  => '</div>',
            'before_title'  => '<h2 class="widget-title">',
            'after_title'   => '</h2>',
        ));


        // home page sidebar
        register_sidebar(array(
            'name'          => __('سایدبار صفحه خانه (تبلیغات)', 'gsm'),
            'id'            => 'home-sidebar-ads',
            'description'   => __('سایدبار اختصاصی برای صفحه خانه (تبلیغات)', 'gsm'),
            'before_widget' => '<div class="widget %2$s">',
            'after_widget'  => '</div>',
            'before_title'  => '<h2 class="widget-title">',
            'after_title'   => '</h2>',
        ));


        // widgets list
        register_widget('latestPostWidget');
        register_widget('PopularWidget');
        register_widget('ShoppingGuideWidget');
        register_widget('AdsWidget');
        register_widget('brandRelatedPostWidget');
        register_widget('brandRelatedProductWidget');
    }

    public function replaceImageSrcInAttachment($image, $attachment_id, $size, $icon)
    {
        if (is_array($image) && isset($image[0])) {
            $image[0] = str_replace('s3.gsm.ir', 's5.gsm.ir', $image[0]);
        }
        return $image;
    }
    public function replaceImageSrcInContent($content)
    {
        $content = str_replace('s3.gsm.ir', 's5.gsm.ir', $content);

        return $content;
    }
}
