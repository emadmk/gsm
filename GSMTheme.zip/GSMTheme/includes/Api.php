<?php

namespace GSM\includes;

/**
 * This file is the maine api
 */

// Exit if accessed directly
if (!defined('ABSPATH')) {
    exit;
}


/**
 * The main api
 *
 * this class used to fetch data from main database
 *
 */
class Api
{

    function __construct() {}

    public static function getGSMBrands()
    {
        $cache_key = 'gsm_brands_api_cache';
        $cached = wp_cache_get($cache_key, 'gsm_api');
        if ($cached !== false) {
            return $cached;
        }
        $api = get_field('apis', 'option');
        $url = isset($api['brand']) && !empty($api['brand']) ? $api['brand'] : "https://marketplace.gsm.ir/api/v1/brands/";
        $options = [
            'headers'     => [
                'Content-Type' => 'application/json',
            ],
            'timeout'     => 60,
            'redirection' => 5,
            'blocking'    => true,
            'httpversion' => '1.0',
            'sslverify'   => false,
        ];
        $result = self::generateResponse('get', $url);
        if ($result !== false) {
            wp_cache_set($cache_key, $result, 'gsm_api', HOUR_IN_SECONDS);
        }
        return $result;
    }

    public static function getGSMProducts($args)
    {
        $defaultArgs = [
            'search' => '',
            'brandIds' => [],
            'productIds' => [],
        ];

        [
            'search' => $search,
            'brandIds' => $brandIds,
            'productIds' => $productIds,
        ] = wp_parse_args($args, $defaultArgs);
        $cache_key = 'gsm_products_api_cache';
        $cache_parts = [];
        if (!empty($search)) {
            $cache_parts[] = 'search_' . md5($search);
        }
        if (!empty($brandIds)) {
            $cache_parts[] = 'brands_' . md5(json_encode($brandIds));
        }
        if (!empty($productIds)) {
            $cache_parts[] = 'products_' . md5(json_encode($productIds));
        }
        if (!empty($cache_parts)) {
            $cache_key .= '_' . implode('_', $cache_parts);
        }

        $cached = wp_cache_get($cache_key, 'gsm_api');
        if ($cached !== false) {
            return $cached;
        }
        $api = get_field('apis', 'option');
        $url = isset($api['product']) && !empty($api['product']) ? $api['product'] : "https://search-engine.gsm.ir/search/products/";

        $query = [];
        if (!empty($search)) {
            $query['query'] = $search;
        }
        if (!empty($brandIds) && is_array($brandIds)) {
            $query['brand_ids'] = implode(',', array_map('intval', $brandIds));
        }
        if (!empty($productIds) && is_array($productIds)) {
            $query['product_ids'] = implode(',', array_map('intval', $productIds));
        }
        if (!empty($query)) {
            $url .= '?' . http_build_query($query);
        }

        $result = self::generateResponse('get', $url);
        if ($result !== false) {
            wp_cache_set($cache_key, $result, 'gsm_api', HOUR_IN_SECONDS);
        }
        return $result;
    }

    public static function getGSMProduct($id)
    {
        $cache_key = 'gsm_product_api_cache' . ($id ? '_' . md5($id) : '');
        $cached = wp_cache_get($cache_key, 'gsm_api');
        if ($cached !== false) {
            return $cached;
        }
        $api = get_field('apis', 'option');
        $url = (isset($api['single_product']) && !empty($api['single_product']) ? $api['single_product'] : "https://marketplace.gsm.ir/api/v1/products/") . $id;
        $options = [
            'headers'     => [
                'Content-Type' => 'application/json',
            ],
            'timeout'     => 60,
            'redirection' => 5,
            'blocking'    => true,
            'httpversion' => '1.0',
            'sslverify'   => false,
        ];
        $result = self::generateResponse('get', $url);
        if ($result !== false) {
            wp_cache_set($cache_key, $result, 'gsm_api', HOUR_IN_SECONDS);
        }
        return $result;
    }

    public static function generateResponse($type, $url, $options = [], $body = true)
    {
        if ($type == 'post') {
            $api_response = wp_remote_post($url, $options);
        } elseif ($type == 'get') {
            if (count($options)) {
                $api_response = wp_remote_get($url, $options);
            } else {
                $api_response = wp_remote_get($url);
            }
        }
        $result = false;
        if (is_wp_error($api_response)) {
            $result = false;
        }

        if ($body) {
            if (in_array(wp_remote_retrieve_response_code($api_response), [200, 201])) {
                $result = json_decode($api_response['body']);
            }
        } else {
            $result = $api_response;
        }


        return $result;
    }
}
