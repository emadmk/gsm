<?php

namespace GSM\includes;


if (!defined('ABSPATH')) {
    exit;
}

class Assign
{
    function __construct()
    {
    }

    public  function addToFooter()
    {
    }

    public  function addToHeader()
    {
        
    }

    public  function addToBody()
    {
        
    }
}
