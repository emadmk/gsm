<?php

namespace GSM\includes;



if (!defined('ABSPATH')) {
    exit;
}

class Activation
{
    function __construct() {}

    /**
     * Generate the Representation table in the database.
     */
    public function generateNotificationTable(): void
    {
        global $wpdb;

        $tableName = $wpdb->prefix . 'gsm_notifications';
        $charsetCollate = $wpdb->get_charset_collate();

        $sql = "
        CREATE TABLE IF NOT EXISTS $tableName (
        `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT,
        `author` tinytext COLLATE utf8mb4_unicode_ci NOT NULL,
        `author_id` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '0',
        `author_role` tinytext COLLATE utf8mb4_unicode_ci NOT NULL,
        `author_avatar` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '0',
        `actor` tinytext COLLATE utf8mb4_unicode_ci NOT NULL,
        `actor_id` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '0',
        `actor_role` tinytext COLLATE utf8mb4_unicode_ci NOT NULL,
        `actor_avatar` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '0',
        `action` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
        `action_type` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
        `action_id` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
        `post_id` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
        `date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
        `date_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
        PRIMARY KEY (`id`)
        ) ENGINE=InnoDB $charsetCollate;
        ";
        $wpdb->query($sql);
    }

    public function generateViewTables()
    {
        global $wpdb;
        $charsetCollate = $wpdb->get_charset_collate();

        // view table
        $tableName = $wpdb->prefix . 'gsm_view';
        $sql = "CREATE TABLE IF NOT EXISTS $tableName (
            id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
            post_id bigint(20) NOT NULL,
            view bigint(20) NOT NULL,
            date datetime DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY (id)
        ) ENGINE=InnoDB $charsetCollate;";
        $wpdb->query($sql);
    }
}
