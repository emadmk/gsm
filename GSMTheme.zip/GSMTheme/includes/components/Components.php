<?php

namespace GSM\includes\components;

/**
 * This file is the maine api
 */

// Exit if accessed directly
if (!defined('ABSPATH')) {
    exit;
}


/**
 * The main api
 *
 * this class used to fetch data from main database
 *
 */
class Components
{

    function __construct() {}

    /**
     * Button method to create a standard button.
     *
     * @param array  $args               Array of arguments for button configuration.
     * @param string $args['content']     Button text content.
     * @param string $args['class']       Additional CSS classes.
     * @param string $args['type']        Button type: 'button' or 'a'.
     * @param string $args['variant']     Button variant: 'primary', 'secondary', 'neutrals-secondary', or 'link'.
     * @param bool   $args['loading']     Whether the button is in a loading state.
     * @param bool   $args['disabled']    Whether the button is disabled.
     * @param string $args['icon']        Icon HTML or SVG.
     * @param string $args['icon-position'] Position of the icon: 'left' or 'right'.
     * @param string $args['size']        Button size: 'md' or 'lg'.
     * @param string $args['href']        URL for <a> type buttons.
     *
     * @return string HTML output for the button.
     */
    public function button($args)
    {
        ob_start();
        get_template_part('includes/components/button', '', ['_this' => $this, 'args' => $args]);
        return  ob_get_clean();
    }

    public function checkbox($args)
    {
        ob_start();
        get_template_part('includes/components/checkbox', '', ['_this' => $this, 'args' => $args]);
        return  ob_get_clean();
    }
}
