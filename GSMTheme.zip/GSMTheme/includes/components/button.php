<?php

$_this = $args['_this'];
$args = $args['args'];


$defaultArgs = [
    'content' => '',
    'class' => '',
    'type' => 'button', // button | a
    'variant' => 'primary',// primary | secondary | neutrals-secondary | link
    'loading' => false,
    'disabled' => false,
    'icon' => '',
    'button-type'=>'button', // 'button' | 'submit'
    'icon-position' => 'right',
    'size' => 'md', //md|lg
    'href' => '#',
];

$args = wp_parse_args($args, $defaultArgs);

$cssClass = classNames(
    'btn',
    $args['class'] ?? '',
    ['loading' => $args['loading']],
    ['disabled' => $args['disabled']],
    ["btn-{$args['variant']}" => $args['variant']],
    ["btn-size-{$args['size']}" => $args['size']]
);

// Process href URL - if it doesn't start with http or https, prepend home_url()
$href = $args['href'];
if (!preg_match('/^https?:\/\//', $href)) {
    $href = home_url($href);
}

if ($args['type'] === 'a') :?>
    <a href="<?= esc_url($href) ?>" class="<?= esc_attr($cssClass) ?>">
        <?php if ($args['icon'] && $args['icon-position'] === 'right') : ?>
            <i class="<?= $args['icon'] ?>"></i>
        <?php elseif ($args['icon-position'] === 'left'): ?>
            <span class="loader"></span>
        <?php endif; ?>
        <div class="btn-content"><?= $args['content']  ?></div>
        <?php if ($args['icon'] && $args['icon-position'] === 'left') : ?>
            <i class="<?= $args['icon'] ?>"></i>
        <?php elseif ($args['icon-position'] === 'right'): ?>
            <span class="loader"></span>
        <?php endif; ?>
    </a>
<?php else : ?>
    <button type="<?= $args['button-type'] ?>"  class="<?= esc_attr($cssClass) ?> flex-center gap-2">
        <?php if ($args['icon'] && $args['icon-position'] === 'right') : ?>
            <i class="<?= $args['icon'] ?>"></i>
        <?php elseif ($args['icon-position'] === 'left'): ?>
            <span class="loader"></span>
        <?php endif; ?>
        <div class="btn-content"><?= $args['content']  ?></div>
        <?php if ($args['icon'] && $args['icon-position'] === 'left') : ?>
            <i class="<?= $args['icon'] ?>"></i>
        <?php elseif ($args['icon-position'] === 'right'): ?>
            <span class="loader"></span>
        <?php endif; ?>
    </button>
<?php endif; ?>