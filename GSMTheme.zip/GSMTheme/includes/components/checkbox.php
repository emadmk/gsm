<?php

$_this = $args['_this'];
$args = $args['args'];


$defaultArgs = [
    'type' => 'normal', // normal | chips
    'label' => '',
    'class' => '',
    'labelClass' => '',
    'variant' => 'primary', // primary
    'close' => false,
    'disabled' => false,
    'name' => '',
    'id' => '',
    'custom-attr' => [],
];

$args = wp_parse_args($args, $defaultArgs);

$cssClass = classNames(
    'checkbox',
    $args['class'] ?? '',
    ['close' => $args['close']],
    ['disabled' => $args['disabled']],
);
$labelCssClass = classNames(
    $args['labelClass'] ?? '',
    ["checkbox-{$args['variant']}" => $args['variant']],
    ["checkbox-{$args['type']}" => $args['type']],
);


?>
<div class="<?= esc_attr($cssClass) ?>">
    <input id="<?= $args['id'] ?>" name="<?= $args['name'] ?>" type="checkbox" class="hidden" <?= implode(' ', $args['custom-attr']) ?>>
    <label for="<?= $args['id'] ?>" class="<?= $labelCssClass ?>">
        <i class="gsmicon-checkmark checkmark"></i>
        <?= $args['label'] ?>
    </label>
</div>