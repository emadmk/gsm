<?php

namespace GSM\includes;

use GSM\includes\comment\Comment;
use GSM\includes\ACF;
use GSM\templates\articles\Articles;
use GSM\templates\articles\ArticlesList;
use GSM\templates\author\Author;
use GSM\templates\general\GeneralAction;
use GSM\templates\home\Home;
use GSM\templates\news\News;
use GSM\templates\news\NewsList;
use GSM\templates\reviews\Reviews;
use GSM\templates\reviews\ReviewsList;
use GSM\templates\tag\Tag;

if (!defined('ABSPATH')) {
    exit;
}

class Rewrite
{
    function __construct() {}

    public  function addQueryVars($vars)
    {
        $vars[] = 'gsmQuery';
        $vars[] = 'gsmType';
        $vars[] = 'gsmEndPoint';


        return $vars;
    }

    public  function addRewriteRules()
    {

        # ======================================================
        #  permalink structure =================================
        # ======================================================
        add_rewrite_rule(
            '^news/([^/]+)/?$',
            'index.php?name=$matches[1]',
            'top'
        );
        add_rewrite_rule(
            '^news/([0-9]+)/([^/]+)/?$',
            'index.php?post_type=news&p=$matches[1]',
            'top'
        );
        add_rewrite_rule(
            '^news/([0-9]+)/?$',
            'index.php?post_type=news&p=$matches[1]',
            'top'
        );

        // article permalink
        add_rewrite_rule(
            '^article/([^/]+)/?$',
            'index.php?name=$matches[1]',
            'top'
        );
        add_rewrite_rule(
            '^article/([0-9]+)/([^/]+)/?$',
            'index.php?post_type=article&p=$matches[1]',
            'top'
        );
        add_rewrite_rule(
            '^article/([0-9]+)/?$',
            'index.php?post_type=article&p=$matches[1]',
            'top'
        );

        // reviews permalink
        add_rewrite_rule(
            '^review/([^/]+)/?$',
            'index.php?name=$matches[1]',
            'top'
        );
        add_rewrite_rule(
            '^review/([0-9]+)/([^/]+)/?$',
            'index.php?post_type=review&p=$matches[1]',
            'top'
        );
        add_rewrite_rule(
            '^review/([0-9]+)/?$',
            'index.php?post_type=review&p=$matches[1]',
            'top'
        );

        // tag and category permalink (with optional trailing slash)
        add_rewrite_rule('^tag/([^/]+)/?$', 'index.php?tag=$matches[1]', 'top');
        add_rewrite_rule('^category/([^/]+)/?$', 'index.php?category_name=$matches[1]', 'top');

        # ======================================================
        #  AJAX rewrite Rule ===================================
        # ======================================================
        add_rewrite_tag('%gsmQuery%', '([^&/]+)');
        add_rewrite_tag('%gsmType%', '([^&/]+)');
        add_rewrite_tag('%gsmEndPoint%', '([^&/]+)');
        add_rewrite_rule('wp-ajax/?$', 'index.php?gsmQuery=ajax', 'top');
        add_rewrite_rule('wp-ajax/([^/]+)/([^/]+)/?', 'index.php?gsmQuery=ajax&gsmType=$matches[1]&gsmEndPoint=$matches[2]', 'top');

        // flush_rewrite_rules();
    }

    public  function templateRedirectHandler()
    {
        if (get_query_var('gsmQuery') === 'ajax') {
            define('WP_AJAX', true);
            $type = get_query_var('gsmType');
            $endPoint = get_query_var('gsmEndPoint');
            if ($type === 'comment') {
                $comment = new Comment();
                $comment->setQuery($endPoint);
                return;
            }
            if ($type === 'news') {
                $news = new News();
                $news->setQuery($endPoint);
                return;
            }
            if ($type === 'news-list') {
                $newsList = new NewsList();
                $newsList->setQuery($endPoint);
                return;
            }
            if ($type === 'articles') {
                $news = new Articles();
                $news->setQuery($endPoint);
                return;
            }
            if ($type === 'articles-list') {
                $articlesList = new ArticlesList();
                $articlesList->setQuery($endPoint);
                return;
            }
            if ($type === 'reviews') {
                $reviews = new Reviews();
                $reviews->setQuery($endPoint);
                return;
            }
            if ($type === 'reviews-list') {
                $reviewsList = new ReviewsList();
                $reviewsList->setQuery($endPoint);
                return;
            }
            if ($type === 'author') {
                $author = new Author();
                $author->setQuery($endPoint);
                return;
            }
            if ($type === 'tag') {
                $tag = new Tag();
                $tag->setQuery($endPoint);
                return;
            }
            if ($type === 'general') {
                $generalAction = new GeneralAction();
                $generalAction->setQuery($endPoint);
                return;
            }
            if ($type === 'home') {
                $home = new Home();
                $home->setQuery($endPoint);
                return;
            }

            if ($type === 'acf') {
                $acf = new ACF();
                $acf->setQuery($endPoint);
                return;
            }
        }
    }

    public function changePostTypePermalink($postLink, $id)
    {
        global $wpdb;
        $post = get_post($id);
        
        if (!$post) {
            return $postLink;
        }
        
        $strapi_id = $wpdb->get_var($wpdb->prepare(
            "SELECT meta_value FROM {$wpdb->prefix}postmeta WHERE post_id = %d AND meta_key = 'strapi_id'",
            $post->ID
        ));
        
        $id_to_use = $strapi_id ? $strapi_id : $post->ID;

        if ($post->post_type === 'article') {
            return home_url('article/' . $id_to_use . '/' . $post->post_name);
        } elseif ($post->post_type === 'review') {
            return home_url('review/' . $id_to_use . '/' . $post->post_name);
        } elseif ($post->post_type === 'news') {
            return home_url('news/' . $id_to_use . '/' . $post->post_name);
        }
        return $postLink;
    }

    public function customTermLink($url, $term, $taxonomy)
    {
        if ($taxonomy === 'post_tag' || $taxonomy === 'category') {
            // Modify the URL to remove '/news/'  
            $url = str_replace('/news/', '/', $url);
        }
        return $url;
    }

    /**
     * Handle URLs with Strapi IDs by mapping them to WordPress post IDs
     * 
     * @param array $query_vars The array of requested query variables
     * @return array Modified query variables
     */
    public function handle_strapi_id_request($query_vars)
    {
        global $wpdb;

        // Check if we have a post ID in the query vars
        if (isset($query_vars['p']) && is_numeric($query_vars['p'])) {
            // This might be a Strapi ID, check if we need to convert it
            $wp_post_id = $wpdb->get_var($wpdb->prepare(
                "SELECT post_id FROM {$wpdb->prefix}postmeta WHERE meta_value = %d AND meta_key = 'strapi_id'",
                $query_vars['p']
            ));

            // If we found a WordPress post ID, use it instead
            if ($wp_post_id) {
                $query_vars['p'] = $wp_post_id;
            }
        }

        return $query_vars;
    }

    /**
     * Redirect to canonical pretty URL when:
     * - URL has no slug: /news/75194/ -> /news/75194/correct-slug/
     * - URL has wrong slug: /news/75194/wrong-slug -> /news/75194/correct-slug/
     */
    public function maybe_redirect_to_pretty_permalink()
    {
        if (defined('WP_AJAX') && WP_AJAX) {
            return;
        }

        $request_uri = $_SERVER['REQUEST_URI'] ?? '';
        $full_path = parse_url($request_uri, PHP_URL_PATH);
        if ($full_path === false || $full_path === '') {
            return;
        }
        $full_path = '/' . trim($full_path, '/');

        // Path relative to site (strip home path for subdirectory installs)
        $path = $full_path;
        $home_path = parse_url(home_url(), PHP_URL_PATH);
        if ($home_path !== false && $home_path !== null && $home_path !== '' && $home_path !== '/') {
            $home_path = rtrim($home_path, '/');
            if (strpos($full_path, $home_path) === 0) {
                $path = substr($full_path, strlen($home_path)) ?: '/';
            }
        }

        // Match /post_type/id/ or /post_type/id (no slug)
        $matches = [];
        if (preg_match('#^/(news|article|review)/(\d+)/?$#', $path, $matches)) {
            $this->redirect_to_canonical_permalink($matches[1], $matches[2], $full_path);
            return;
        }
        // Match /post_type/id/slug (wrong or correct slug)
        $matches = [];
        if (preg_match('#^/(news|article|review)/(\d+)/([^/]+)/?$#', $path, $matches)) {
            $this->redirect_to_canonical_permalink($matches[1], $matches[2], $full_path);
            return;
        }
    }

    /**
     * If current path is not the canonical URL (with correct slug), redirect 301.
     *
     * @param string $post_type news|article|review
     * @param string $strapi_id Strapi post ID from URL
     * @param string $current_path Request path (e.g. /news/75194/ or /news/75194/wrong-slug)
     */
    private function redirect_to_canonical_permalink($post_type, $strapi_id, $current_path)
    {
        global $wpdb;

        $wp_post_id = $wpdb->get_var($wpdb->prepare(
            "SELECT post_id FROM {$wpdb->prefix}postmeta WHERE meta_value = %d AND meta_key = 'strapi_id'",
            $strapi_id
        ));

        if (!$wp_post_id) {
            return;
        }

        $post = get_post($wp_post_id);
        if (!$post || $post->post_type !== $post_type) {
            return;
        }

        $canonical_url  = home_url("/$post_type/$strapi_id/" . $post->post_name . "/");
        $canonical_path = urldecode(parse_url($canonical_url, PHP_URL_PATH));

        $current_normalized  = untrailingslashit(urldecode($current_path));
        $canonical_normalized = untrailingslashit(urldecode($canonical_path ?? ''));

        if ($current_normalized !== $canonical_normalized) {
            wp_redirect($canonical_url, 301);
            exit;
        }
    }
}
