<?php

namespace GSM\includes\comment;

use GSM\includes\Query;

$_this = $args['_this'];
$comment = $args['comment'];
$isFirstPage = $args['isFirstPage'];
$i = $args['i'];

$commentType = get_comment_meta($comment->comment_ID, 'gsm_type', true);
?>
<li class="comment-item body-sm relative transition-all p-4 bg-white md:rounded-lg <?= $_this->type !='review' ?'shadow-post-box':'border border-gray-100' ?>    <?= $isFirstPage && $i > 4 ? 'hidden' : '' ?> " data-comment-id="<?= esc_attr__($comment->comment_ID) ?>" id="comment-<?= esc_attr__($comment->comment_ID) ?>">
    <article class="space-y-4">
        <header class="comment-author flex items-center gap-2">
            <?php if ($commentType === 'gsm_admin'): ?>
                <div class="flex gap-1">
                    <img src="<?= GSM_URL . '/assets/img/mini-logo.svg' ?>" class="size-6 rounded-full " />
                    <p class="subtitle-lg text-primary-500"><?= __('جی‌اس‌ام', 'gsm') ?></p>
                </div>
            <?php else: ?>
                <p class=" flex"><?= esc_attr__($comment->comment_author) ?></p>
            <?php endif ?>
            <time class="text-gray-300 flex items-center">
                <?= human_time_diff(strtotime($comment->comment_date), current_time('U')) . ' پیش ' ?>
                <span class="hidden md:block"><?= __('این دیدگاه اضافه کرده است', 'gsm') ?></span>
            </time>
        </header>
        <div class="comment-content break-words bg-gray-50 rounded-lg py-2 px-4">
            <?= $comment->comment_content  ?>
            <?php if (!$comment->comment_approved) : ?>
                <p class="text-gray-500 italic">(<?= __('دیدگاه شما در انتظار تایید می باشد', 'gsm') ?>)</p>
            <?php endif ?>
        </div>
    </article>
</li>