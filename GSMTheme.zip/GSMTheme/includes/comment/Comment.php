<?php

namespace GSM\includes\comment;

use GSM\includes\Query;
use GSM\includes\Security;

if (!defined('ABSPATH')) {
    exit;
}
class Comment
{
    protected $query;
    public $type;

    function __construct($type = 'news')
    {
        $this->type = $type;
        add_action('wp_insert_comment', [$this, 'addRoleForAdminCommentReplay'], 10, 2);
    }

    public function setQuery($query)
    {
        $this->query = $query;
        $this->ajaxActions();
    }

    public function ajaxActions()
    {
        if ($this->query == 'add-comment') {
            $data = sanitizeNestedObject(json_decode(stripslashes($_POST['data'])));
            $datetime  = current_time('Y-m-d\ H:i:s');
            $this->type = isset($data['postType']) ? sanitize_text_field($data['postType']) : $this->type;
            $postId = isset($data['postId']) ? intval($data['postId']) : 0;
            if ($postId <= 0) {
                ajaxResponse(false, 'شناسه پست نامعتبر است');
            }
            $acceptableUserRole = ['administrator', 'editor', 'author'];
            $user = wp_get_current_user();
            $roles = (array) $user->roles;
            // Require captcha for guests and non-privileged users
            $requiresCaptcha = true;
            if (is_user_logged_in() && array_intersect($roles, $acceptableUserRole)) {
                $requiresCaptcha = false;
            }

            if ($requiresCaptcha) {
                $captchaToken = isset($data['captchaToken']) ? sanitize_text_field($data['captchaToken']) : '';
                $captchaValue = isset($data['captchaValue']) ? sanitize_text_field($data['captchaValue']) : '';

                if (!Security::validateCommentCaptcha($captchaToken, $captchaValue)) {
                    ajaxResponse(false, 'کد امنیتی نادرست است. لطفاً مجدداً تلاش نمایید');
                }
            }

            if (is_user_logged_in() && array_intersect($roles, $acceptableUserRole)) {
                $user = get_user_by('id', get_current_user_id());
                $userId = get_current_user_id();
                $commentArgs = [
                    'comment_post_ID' => $postId,
                    'comment_author' => $user->display_name,
                    'comment_author_email' => $user->user_email,
                    'comment_author_IP' => getUserIp(),
                    'comment_date' => $datetime,
                    'comment_content' => isset($data['content']) ? sanitize_textarea_field($data['content']) : '',
                    'comment_approved' => 1,
                    'comment_parent' => 0,
                    'user_id' => get_current_user_id(),
                    'comment_meta' => [
                        'gsm_type' => 'gsm_admin',
                    ]
                ];
            } else {
                $commentArgs = [
                    'comment_post_ID' => $postId,
                    'comment_author' => isset($data['name']) ? sanitize_text_field($data['name']) : '',
                    'comment_author_IP' => getUserIp(),
                    'comment_date' => $datetime,
                    'comment_content' => isset($data['content']) ? sanitize_textarea_field($data['content']) : '',
                    'comment_approved' => 0,
                    'comment_parent' => 0,
                    'comment_meta' => [
                        'gsm_type' => is_user_logged_in() ? 'gsm_customer' : 'gsm_anonymous',
                    ]
                ];
            }
            $commentId = wp_insert_comment($commentArgs);
            $commentObjs = get_comments(['comment__in' => [$commentId]]);


            $commentHtml = $this->generateCommentItem($commentObjs[0], 0, false);


            ajaxResponse(true, 'نظر شما با موفقیت ثبت گردید', [
                'commentId' => $commentId,
                'commentHtml' => $commentHtml,
            ]);
        } elseif ($this->query == 'list') {
            $data =  sanitizeNestedObject(json_decode(stripslashes($_POST['data'])));
            $page = isset($data['page']) ? intval($data['page']) : 1;
            $postId = isset($data['postId']) ? intval($data['postId']) : 0;
            $maxPages = isset($data['maxPages']) ? intval($data['maxPages']) : 1;
            if ($postId <= 0) {
                ajaxResponse(false, 'شناسه پست نامعتبر است');
            }
            $commentList = get_comments(['post_id' => $postId, 'status' => 'approve', 'parent__in' => [0], 'paged' => $page, 'number' => 15]);

            ob_start();
            if (is_array($commentList)) foreach ($commentList as $i => $comment) {

                echo $this->generateCommentItem($comment, $i);
            }
            $commentList = ob_get_clean();
            $pagination = $this->displayPagination($maxPages, $page);

            ajaxResponse(true, 'لیست صفحات نظرات ایجاد شد', [
                'list' => $commentList,
                'pagination' => $pagination,
            ]);
        } elseif ($this->query == 'captcha') {
            $captcha = Security::generateCommentCaptcha();
            ajaxResponse(true, 'کد امنیتی ایجاد شد', [
                'captcha' => $captcha,
            ]);
        }
    }




    public function addRoleForAdminCommentReplay($comment_id, $comment_object)
    {
        // Check if the comment was added by an admin
        if (is_user_logged_in() && is_admin()) {
            $comment_data = [
                'comment_ID' => $comment_id,
                'comment_meta' => [
                    'gsm_user_id' => get_current_user_id(),
                    'gsm_type' => 'gsm_admin',
                ],
            ];
            wp_update_comment($comment_data);
        }
    }


    public  function commentChildren($comment_id)
    {
        global $wpdb;
        $comment_id = intval($comment_id);
        $comment_query = $wpdb->prepare(
            "SELECT * FROM {$wpdb->prefix}comments c WHERE c.comment_parent = %d ORDER BY c.comment_date",
            $comment_id
        );
        $comment_result = $wpdb->get_results($comment_query);
        return $comment_result;
    }

    public function displayPagination($maxNumPages, $page = 1, $paginationOffset = 3)
    {
        ob_start();
        get_template_part('includes/comment/comment', 'pagination', ['_this' => $this, 'page' => $page, 'paginationOffset' => $paginationOffset, 'maxNumPages' => $maxNumPages]);
        return  ob_get_clean();
    }


    public function generateCommentItem($comment, $i, $isFirstPage = true)
    {
        ob_start();
        get_template_part('includes/comment/comment', 'item', ['_this' => $this, 'comment' => $comment, 'i' => $i, 'isFirstPage' => $isFirstPage]);
        return ob_get_clean();
    }

    public function generateCustomComment($postId)
    {
        ob_start();
        get_template_part('includes/comment/comment', 'custom-comment', ['_this' => $this, 'postId' => $postId]);
        return ob_get_clean();
    }
}
