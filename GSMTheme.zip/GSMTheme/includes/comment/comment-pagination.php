<?php

namespace OxyGame\templates\news;

$_this = $args['_this'];
$maxNumPages = $args['maxNumPages'];
$page = $args['page'];
$paginationOffset = $args['paginationOffset'];

if ($maxNumPages > 1): ?>
    <div class="gsm-pagination flex-center gap-2 w-full">
        <!-- Previous Page Button -->
        <div class="page-item flex-center cursor-pointer transition-all gap-1 <?= $page == 1 ? 'text-gray-300' : '' ?>" data-page="<?= $page - 1 ?>">
            <i class="gsmicon-chevron-right"></i>
            <p class="hidden md:block"><?= __('قبلی', 'gsm') ?></p>
        </div>

        <!-- Page Numbers -->
        <div class="page-numbers flex flex-wrap justify-center gap-2">
            <?php
            // First Page
            if ($page > $paginationOffset + 1): ?>
                <div class="page-item size-8 md:size-10 rounded-lg flex-center flex cursor-pointer transition-all <?= $page == 1 ? 'bg-primary-500 text-white selected' : 'hover:bg-primary-500 hover:text-white'; ?>" data-page="1">1</div>
            <?php endif;

            // Leading Ellipsis
            if ($page > $paginationOffset + 2): ?>
                <div class="page-item size-8 md:size-10 rounded-lg flex-center flex transition-all">...</div>
            <?php endif;

            // Dynamic Range of Pages
            for ($i = max(1, $page - $paginationOffset); $i <= min($maxNumPages, $page + $paginationOffset); $i++): ?>
                <div class="page-item size-8 md:size-10 rounded-lg flex-center flex cursor-pointer transition-all <?= $i == $page ? 'bg-primary-500 text-white selected' : 'hover:bg-primary-500 hover:text-white'; ?>" data-page="<?= $i ?>"><?= $i ?></div>
            <?php endfor;

            // Trailing Ellipsis
            if ($page < $maxNumPages - $paginationOffset - 1): ?>
                <div class="page-item size-8 md:size-10 rounded-lg flex-center flex transition-all">...</div>
            <?php endif;

            // Last Page
            if ($page < $maxNumPages - $paginationOffset): ?>
                <div class="page-item size-8 md:size-10 rounded-lg flex-center flex cursor-pointer transition-all <?= $page == $maxNumPages ? 'bg-primary-500 text-white selected' : 'hover:bg-primary-500 hover:text-white'; ?>" data-page="<?= $maxNumPages ?>"><?= $maxNumPages ?></div>
            <?php endif; ?>
        </div>

        <!-- Next Page Button -->
        <div class="page-item flex-center cursor-pointer transition-all gap-1 <?= $page == $maxNumPages ? 'text-gray-300' : '' ?>" data-page="<?= $page + 1 ?>">
            <p class="hidden md:block"><?= __('بعدی', 'gsm') ?></p>
            <i class="gsmicon-chevron-right rotate-180"></i>
        </div>

    </div>
<?php endif; ?>