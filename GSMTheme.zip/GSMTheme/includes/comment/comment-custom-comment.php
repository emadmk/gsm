<?php

namespace GSM\includes\comment;

use GSM\includes\Security;

global $GSMComponents;
$_this = $args['_this'];
$postId = intval($args['postId']);
$isLogin = 0;
$userId = 0;
if (is_user_logged_in()) {
    $isLogin = 1;
    $userId = get_current_user_id();
    $user = get_user_by('id', $userId);
}

$page = isset($_GET['pg']) ? intval($_GET['pg']) : 1;
$totalComment = get_comments_number($postId);
$showMoreMaxPage = ceil($totalComment / 5);
$maxPages = ceil($totalComment / 15);

// initial captcha
$captcha = Security::generateCommentCaptcha();

// enqueue js file
wp_enqueue_script('gsm-comment', GSM_URL . '/assets/js/comment.js', ['jquery', 'gsm-toast'], GSM_VERSION, true);
wp_localize_script(
    'gsm-comment',
    'commentData',
    [
        'isLogin'  => $isLogin,
        'postId'   => $postId,
        'postType' => get_post_type($postId),
        'captcha'  => $captcha,
    ]
);
$commentList = get_comments(['post_id' => $postId, 'status' => 'approve', 'parent__in' => [0], 'paged' => $page, 'number' => 15]);

?>
<section id="comments" class="<?= $_this->type =='review' ?'mx-auto px-4 md:px-0 md:max-w-[52.875rem]':'' ?>">
    <div class=" <?= $_this->type !='review' ?'shadow-post-box p-4 md:rounded-lg ':'' ?>  bg-white  mt-4 md:mt-6 w-full">
        <h2 class="h3"><?= __('نظرات', 'gsm') ?><span class="body-sm text-gray-400 pr-1">(<?= $totalComment ?>)</span></h2>
        <form class="comment-form flex flex-col w-full">
            <?php if (!$isLogin) : ?>
                <input type="text" name="gsm-comment-name" id="gsm-comment-name" class="h-8 bg-primary-20 border border-gray-200 placeholder-gray-300 outline-none rounded-lg caption px-4 mt-2" placeholder="<?= __('نام دلخواه خود را بنویسید', 'gsm') ?>">
                <p class="caption pt-2"><?= __('این نام صرفا برای نمایش دیدگاه شما در بخش نظرات کاربران استفاده خواهد شد.', 'gsm') ?></p>

            <?php endif ?>

            <textarea name="gsm-comment-content" id="gsm-comment-content" class="w-full p-4 resize-none h-[7.75rem] bg-primary-20 border border-gray-200 placeholder-gray-300 outline-none rounded-lg mt-4 caption" placeholder="<?= __('نظر خودتون رو درباره این مطلب بنویسید', 'gsm') ?>"></textarea>

            <?php if (!$isLogin) : ?>
                <div class="comment-captcha flex flex-col md:flex-row items-start md:items-center gap-3 mt-4">
                    <div class="flex items-center gap-4">
                        <img
                            src="<?= \esc_url($captcha['image']); ?>"
                            alt="<?= __('کد امنیتی', 'gsm'); ?>"
                            class="comment-captcha-image h-6 w-20 md:w-24 md:h-8 rounded-lg border border-gray-200 bg-primary-20 object-contain"
                        />
                        
                        <button
                            type="button"
                            class="comment-captcha-refresh size-6 md:size-8 flex items-center justify-center rounded-full border border-gray-300 text-gray-500 hover:bg-primary-50"
                            aria-label="<?= __('بارگذاری مجدد کد امنیتی', 'gsm'); ?>"
                        >
                            <i class="gsmicon-reply text-sm"></i>
                        </button>
                    </div>
                    <div class="w-full md:w-auto">
                        <input
                            type="text"
                            id="gsm-comment-captcha"
                            name="gsm-comment-captcha"
                            class="h-8 bg-primary-20 border border-gray-200 placeholder-gray-300 outline-none rounded-lg caption px-4 w-full md:w-40"
                            placeholder="<?= __('کد امنیتی را وارد کنید', 'gsm') ?>"
                            inputmode="numeric"
                        />
                        <input
                            type="hidden"
                            id="gsm-comment-captcha-token"
                            name="gsm-comment-captcha-token"
                            value="<?= \esc_attr($captcha['token']); ?>"
                        />
                    </div>
                </div>
            <?php endif ?>

            <?= $GSMComponents->button([
                'class' => 'overline-font mt-4 w-fit mr-auto !px-10',
                'size' => 'md',
                'content' => __('ثبت نظر', 'gsm'),
                'variant' => 'primary',
                'button-type' => 'submit',
            ]) ?>
        </form>
    </div>
    <ul class="space-y-4 mt-4 comment-container">
        <?php if (is_array($commentList)) foreach ($commentList as $i => $comment) : ?>
            <?= $_this->generateCommentItem($comment, $i); ?>
        <?php endforeach ?>
    </ul>

    <?php if ($page === 1): ?>
        <button class="comment-show-more w-full h-12 rounded-lg bg-primary-20 border border-gray-200 text-primary-500 subtitle-sm <?php echo count($commentList) > 5 ? 'flex' : 'hidden' ?> items-center justify-center gap-2 mt-4 " data-page="2" data-all-page="<?= $showMoreMaxPage ?>">
            <?= __('مشاهده بیشتر', 'gsm') ?>
            <i class="gsmicon-chevron-bottom text-md"></i>
        </button>
    <?php endif ?>
    <?php if ($maxPages > 1): ?>
        <div class="pagination md:mt-4 <?= $page === 1 ? 'hidden' : '' ?>" data-max-page="<?= $maxPages ?>">
            <?= $_this->displayPagination($maxPages,$page) ?>
        </div>
    <?php endif ?>
</section>