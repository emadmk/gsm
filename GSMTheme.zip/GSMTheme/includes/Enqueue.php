<?php

namespace GSM\includes;

use GSM\GSM;

if (!defined('ABSPATH')) {
    exit;
}

class Enqueue
{
    function __construct() {}

    public static function enqueueScripts()
    {

        // Register theme stylesheet.
        wp_enqueue_style('gsmicon', GSM_URL . '/assets/gsmicon/style.css', [], GSM_VERSION);
        wp_enqueue_style('gsm-iransans', GSM_URL . '/assets/css/iransans.css', [], 1.1);
        wp_enqueue_style('gsm-toast', GSM_URL . '/assets/css/toast.css', [], GSM_VERSION);
        wp_register_style('gsm-style', GSM_URL . '/assets/css/main-style.css', [], GSM_VERSION);
        wp_enqueue_style('gsm-style');

        // js files
        if (!isGoogleBot()) {
            // wp_enqueue_script('gsap', GSM_URL . '/assets/js/gsap.min.js', '3.12.5', true);
            // wp_enqueue_script('gsap-st', GSM_URL . '/assets/js/scrollTrigger.min.js', ['gsap'], '3.12.5', true);
            // wp_enqueue_script('gsap-stp', GSM_URL . '/assets/js/scrollToPlugin.min.js', ['gsap', 'gsap-st'], '3.12.5', true);
            // wp_enqueue_script('gsap-ss', GSM_URL . '/assets/js/scrollSmoother.min.js', ['gsap', 'gsap-st', 'gsap-stp'], GSM_VERSION, true);
            // wp_enqueue_script('gsap-text', GSM_URL . '/assets/js/splitText.min.js', ['gsap'], GSM_VERSION, true);
            // wp_enqueue_script('gsm-animation', GSM_URL . '/assets/js/animation.js', ['jquery', 'gsap', 'gsap-st', 'gsap-stp', 'gsap-ss', 'gsap-text'], GSM_VERSION, true);
        }
        wp_enqueue_script('gsm-toast', GSM_URL . '/assets/js/toast.js', ['jquery'], GSM_VERSION, true);
        wp_enqueue_script('gsm-global', GSM_URL . '/assets/js/global.js', ['gsm-toast', 'jquery'], GSM_VERSION, true);
        wp_enqueue_script('gsm-ads', GSM_URL . '/assets/js/ads.js', ['gsm-toast', 'jquery'], GSM_VERSION, true);
        wp_localize_script('gsm-global', 'gsmArr', self::globalData());
        wp_localize_script('gsm-ads', 'gsmArr', self::adsData());


        wp_dequeue_style('wp-block-library');
        wp_dequeue_style('wp-block-library-rtl-css');
        wp_dequeue_style('wp-block-library-theme');
    }

    public static function adminEnqueueScripts()
    {
        wp_enqueue_media();
        // wp_enqueue_script('gsm-admin', get_template_directory_uri() . '/assets/js/gsm-admin.js', array('jquery'), GSM_VERSION, true);

        // wp_enqueue_script('wp-color-picker-alpha', get_template_directory_uri() . '/assets/js/wp-color-picker-alpha.min.js', array('wp-color-picker'), GSM_VERSION, true);
        // wp_enqueue_style('wp-color-picker');
        // wp_enqueue_style('gsm-css', get_template_directory_uri() . '/assets/css/gsm-admin.css');
        global $pagenow;
        if ($pagenow === 'post.php' || $pagenow === 'post-new.php') {
            $screen = get_current_screen();
            if (in_array($screen->post_type, ['news', 'review', 'article','page'])) {
                wp_enqueue_style('gsm-admin-post', get_template_directory_uri() . '/assets/css/admin.css');
                wp_enqueue_script('gsm-admin-post', get_template_directory_uri() . '/assets/js/admin/admin-post.js', array('jquery'), GSM_VERSION, true);
                wp_localize_script('gsm-admin-post', 'gsmArr', self::globalData());
            }
        }
    }

    public  function removeJQueryMigrate($scripts)
    {
        if (!is_admin() && isset($scripts->registered['jquery'])) {
            $script = $scripts->registered['jquery'];
            if ($script->deps) {
                // Check whether the script has any dependencies

                $script->deps = array_diff($script->deps, array('jquery-migrate'));
            }
        }
    }

    public function addAdminMenu()
    {
        add_menu_page(
            esc_html__('تنظیمات پوسته', 'gsm'),
            esc_html__('تنظیمات پوسته', 'gsm'),
            'manage_options',
            'gsm-forum',
            [$this, 'dashboardMenuContent'],

        );

        add_submenu_page(
            'gsm-forum',
            esc_html__('پیشخوان', 'gsm'),
            esc_html__('پیشخوان', 'gsm'),
            'manage_options',
            'gsm-forum-dashboard',
            [$this, 'dashboardMenuContent'],
        );
    }

    public static function globalData()
    {

        $api = get_field('apis', 'option');
        return array(
            'ajaxUrl' => admin_url('admin-ajax.php'),
            'homeUrl' => get_home_url(),
            'templateUri' => get_template_directory_uri(),
            'wordPressLoggedIn' => is_user_logged_in(),
            'expandedUrl' => explodeUrlWithQuery()['main-url'],
        );
    }

    public static function adsData()
    {

        $api = get_field('apis', 'option');
        return array(
            'homeUrl' => get_home_url(),
            'adsUrl' => isset($api['ads']) && !empty($api['ads']) ? $api['ads'] : "https://marketplace.gsm.ir/api/v1/ads/",
            'backend_base_url' => isset($api['backend_base_url']) && !empty($api['backend_base_url']) ? $api['backend_base_url'] : "https://marketplace.gsm.ir",

        );
    }

    public function dashboardMenuContent()
    {
        // require_once get_template_directory() . '/includes//admin/dashboard.php';
    }
}
