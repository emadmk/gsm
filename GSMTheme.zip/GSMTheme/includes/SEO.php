<?php

namespace GSM\includes;

use WP_Post_Type;

if (!defined('ABSPATH')) {
    exit;
}

class SEO
{
    function __construct() {}

    public function addCustomSeparator($args)
    {

        $args['separator'] = '<i class="gsmicon-chevron-left"></i>';

        return $args;
    }
    public function changeBreadcrumbItems($crumbs, $class)
    {
        global $post;
        if (is_single()) {

            if (get_post_type() == 'news') {
                $title = $crumbs[1];
                $crumbs[1] = ['اخبار', home_url() . '/news'];
                $crumbs[2] = $title;
            } elseif (get_post_type() == 'article') {
                $title = $crumbs[1];
                $crumbs[1] = ['مقاله', home_url() . '/article'];
                $crumbs[2] = $title;
            } elseif (get_post_type() == 'review') {
                $title = $crumbs[1];
                $crumbs[1] = ['بررسی', home_url() . '/review'];
                $crumbs[2] = $title;
            }
        }
        if (is_page()) {
            if ($post->post_name == 'news') {
                $crumbs[1][0] = 'اخبار';
            } elseif ($post->post_name == 'articles') {
                $crumbs[1][0] = 'مقاله';
            } elseif ($post->post_name == 'reviews') {
                $crumbs[1][0] = 'بررسی';
            }
        }
        return $crumbs;
    }
}
