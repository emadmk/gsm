<?php
namespace GSM\includes;  

if (!defined('ABSPATH')) {  
    exit;  
}  

trait AuthorStatistics  
{  
    public function scheduleAuthorStatisticsUpdate($authorId)  
    {  
        if (!wp_next_scheduled('gsm_update_author_statistics', [$authorId])) {  
            wp_schedule_single_event(time() + 60, 'gsm_update_author_statistics', [$authorId]);  
        }  
    }  

    public function updateAuthorStatistics($authorId)  
    {  
        // Update author stats  
        $this->updateAuthorPostWordCount($authorId);  
        $this->updateAuthorCommentCount($authorId);  
        $this->updateAuthorViewCount($authorId);  
        $this->updateAuthorLikeCount($authorId);  
        $this->updateAuthorPostCount($authorId);  
    }  
}  