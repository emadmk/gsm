<?php

namespace GSM\includes\nav;

use Walker_Nav_Menu;

class NavWalker extends Walker_Nav_Menu
{

    public function __construct() {}
    private $current_item;
    private $icon;
    function start_lvl(&$output, $depth = 0, $args = null)
    {

        $indent = str_repeat("\t", $depth);
        $this->icon = get_post_meta($this->current_item->ID, 'gsm_icon', true);


        $output .= '<ul class="  ">';
    }
    function start_el(&$output, $item, $depth = 0, $args = null, $current_object_id = 0)
    {

        $this->current_item = $item;
        $this->icon = get_post_meta($this->current_item->ID, 'gsm_icon', true);
        $hideIcon = get_post_meta($this->current_item->ID, 'gsm_display_icon', true);
        $indent = ($depth) ? str_repeat("\t", $depth) : '';
        $classes = empty($item->classes) ? array() : (array) $item->classes;
        $classes[] = 'menu-item-' . $item->ID;
        $classes[] = 'level-' . ($depth + 1);

        $args = apply_filters('nav_menu_item_args', $args, $item, $depth);
        if(is_array($args))return;
        $class_names = join(' ', apply_filters('nav_menu_css_class', array_filter($classes), $item, $args, $depth));
        $class_names = $class_names ? ' class="' . esc_attr($class_names) . '"' : '';
        $id = apply_filters('nav_menu_item_id', 'menu-item-' . $item->ID, $item, $args, $depth);
        $id = $id ? ' id="' . esc_attr($id) . '"' : '';
        $style = '';
        $output .= $indent . '<li' . $id . $class_names . $style . ' >';

        $atts = array();
        $atts['title']  = !empty($item->attr_title) ? $item->attr_title : '';
        $atts['target'] = !empty($item->target)     ? $item->target     : '';
        $atts['rel']    = !empty($item->xfn)        ? $item->xfn        : '';
        $atts['href']   = !empty($item->url)        ? $item->url        : '';
        $atts = apply_filters('nav_menu_link_attributes', $atts, $item, $args, $depth);
        $attributes = '';
        foreach ($atts as $attr => $value) {
            if (!empty($value)) {
                $value = ('href' === $attr) ? esc_url($value) : esc_attr($value);
                $attributes .= ' ' . $attr . '="' . $value . '"';
            }
        }
        $item_output = '';

        $title = apply_filters('the_title', $item->title, $item->ID);
        $title = apply_filters('nav_menu_item_title', $title, $item, $args, $depth);
        $item_output = $args->before;
        $item_output .= '<div class="item-inner inner-' . ($depth + 1) . '">';
        $item_output .= '<a class="item-link link-' . ($depth + 1) . '"' . $attributes . '>';
        if ($this->icon && !empty($this->icon)) {
           
            $item_output .= '<i class="' . $this->icon . ' item-icon icon-' . ($depth + 1) . ' ' . (($depth == 0 && $hideIcon) ? "md:hidden" : "") . '"></i>';  

        }
        $item_output .= $args->link_before . $title . $args->link_after;
        $item_output .= '</a>';
        $item_output .= $args->after;

        if ($args->walker->has_children) {
            $item_output .= '<i class="gsmicon-chevron-bottom "></i>';
        }
        $item_output .= '</div>';

        $output .= apply_filters('walker_nav_menu_start_el', $item_output, $item, $depth, $args);
    }

    public function end_el(&$output, $item, $depth = 0, $args = array())
    {

        $output .= "</li>\n";
    }
    function end_lvl(&$output, $depth = 0, $args = array())
    {
        $indent = str_repeat("\t", $depth);
        $output .= "$indent</ul>\n";
    }
}
