<?php

namespace GSM\includes\nav;

class Navigation
{

    public function menuCustomFields($item_id, $menu_item, $depth, $args, $current_object_id)
    {


        $menuIcon = get_post_meta($item_id, 'gsm_icon', true);
?>
        <div class="field-custom_menu_meta description-wide" style="margin: 5px 0;">
            <div class="gsm-menu-section select-menu-icon">
                <label class="gsm-label" for="icon-for-<?php echo $item_id; ?>"><?php esc_html_e('کلاس آیکون', 'gsm') ?></label>
                <div class="select-icon-btn">
                    <input type="text" name="icon[<?php echo $item_id; ?>]" id="icon-for-<?php echo $item_id; ?>" value="<?php echo esc_attr($menuIcon); ?>" class="regular-text" />

                </div>
            </div>
        </div>

<?php
    }

    public function navUpdate($menu_id, $menu_item_db_id)
    {

        if (isset($_POST['icon'][$menu_item_db_id])) {
            $sanitized_data = sanitize_text_field($_POST['icon'][$menu_item_db_id]);
            update_post_meta($menu_item_db_id, 'gsm_icon', $sanitized_data);
        }
        if (isset($_POST['iconDisplay'][$menu_item_db_id])) {
            update_post_meta($menu_item_db_id, 'gsm_display_icon', true);
        } else {
            update_post_meta($menu_item_db_id, 'gsm_display_icon', false);
        }
    }


    public function navUpdateCache($menu_id, $menu_data = null)
    {
        delete_transient('gsm_menu_list');
    }
}
