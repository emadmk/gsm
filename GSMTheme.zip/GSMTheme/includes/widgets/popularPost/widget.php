<?php

use GSM\includes\Query;

$mostViewed = Query::getMostViewedPosts($instance['range'], $instance['number']);
$postIds = wp_list_pluck($mostViewed, 'post_id');
$args = [
    'post_type' => ['news', 'article', 'review'],
    'post__in' => $postIds,
    'orderby' => 'post__in',
    'posts_per_page' => $instance['number'],
];

$popularPosts = new WP_Query($args);

?>
<section class="md:border-r md:border-gray-200 bg-white">
    <?= $args['before_widget'] ?? '' ?>
    <div class="widget-title h3 border-r-2 border-primary-500/[0.64] p-4 md:-mr-[1px]"><?= $instance['title'] ?></div>
    <ul class="body-sm px-4 md:px-6 divide-y divide-gray-100">
        <?php foreach ($popularPosts->posts as $post): ?>
            <li class="py-2 md:py-5">
                <a href="<?= esc_url(get_permalink($post)) ?>" class="hover:text-primary-500  transition-all"><?= esc_attr($post->post_title) ?></a>
            </li>
        <?php endforeach ?>
    </ul>
    <?= $args['after_widget'] ?? '' ?>
</section>