<?php
$title = !empty($instance['title']) ? $instance['title'] : __('مقالات محبوب روز', 'gsm');  
$number = !empty($instance['number']) ? $instance['number'] : 7;  
$range = !empty($instance['range']) ? $instance['range'] : 'day';  
?>  
<p>  
    <label for="<?php echo esc_attr($this->get_field_id('title')); ?>"><?php esc_attr_e('Title:', 'gsm'); ?></label>  
    <input class="widefat" id="<?php echo esc_attr($this->get_field_id('title')); ?>" name="<?php echo esc_attr($this->get_field_name('title')); ?>" type="text" value="<?php echo esc_attr($title); ?>">  
</p>  
<p>  
    <label for="<?php echo esc_attr($this->get_field_id('range')); ?>"><?php esc_attr_e('range:', 'gsm'); ?></label>  
    <select class="widefat" id="<?php echo esc_attr($this->get_field_id('range')); ?>" name="<?php echo esc_attr($this->get_field_name('range')); ?>">
        <option value="today" <?= checked($range,'day') ?>><?= __('day', 'gsm') ?></option>
        <option value="this-week" <?= checked($range,'week') ?>><?= __('week', 'gsm') ?></option>
        <option value="this-month" <?= checked($range,'month') ?>><?= __('month', 'gsm') ?></option>
    </select>
</p>  
<p>  
    <label for="<?php echo esc_attr($this->get_field_id('number')); ?>"><?php esc_attr_e('number of post:', 'gsm'); ?></label>  
    <input type=number class="widefat" id="<?php echo esc_attr($this->get_field_id('number')); ?>" name="<?php echo esc_attr($this->get_field_name('number')); ?>" value="<?= esc_attr($number) ?>" />
</p>  
<?php 