<?php

class PopularWidget extends WP_Widget
{

    // Set up the widget's name and description  
    function __construct()
    {
        parent::__construct(
            'PopularWidget', // Base ID  
            __('مقالات محبوب روز', 'gsm'), // Name  
            array('description' => __('نمایش لیست مقالات محبوب روز', 'gsm'),) // Args  
        );

    }

    // The front-end display of the widget  
    public function widget($args, $instance)
    {
        include GSM_DIR . '/includes/widgets/popularPost/widget.php';
    }

    // The back-end form to handle the widget settings  
    public function form($instance)
    {
        include GSM_DIR . '/includes/widgets/popularPost/form.php';
    }

    // Sanitize and save widget settings  
    public function update($new_instance, $old_instance)
    {
        $instance = [];
        $instance['title'] = (!empty($new_instance['title'])) ? strip_tags($new_instance['title']) : '';
        $instance['number'] = (!empty($new_instance['number'])) ? strip_tags($new_instance['number']) : 7;
        $instance['range'] = (!empty($new_instance['range'])) ? strip_tags($new_instance['range']) : 'day';
        return $instance;
    }
}
