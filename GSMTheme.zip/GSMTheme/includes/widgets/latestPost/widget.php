<?php

use GSM\includes\Query;

$args = [
    'post_type' => ['news', 'article', 'review'],
    'orderby' => 'date',
    'posts_per_page' => $instance['number'],
];

$latestPosts = new WP_Query($args);

?>
<section class="latest-post-widget p-4 shadow-post-box bg-white md:rounded-lg">
    <?= $args['before_widget'] ?? '' ?>
    <div class="widget-title h5  pb-4 w-full text-right border-b border-gray-100">جدیدترین مطالب</div>
    <ul class="body-sm space-y-4 ">
        <?php foreach ($latestPosts->posts as $post): ?>
            <li>
                <a href="<?= esc_url(get_permalink($post)) ?>" class="flex gap-4 pt-4 items-center">
                    <?php if (has_post_thumbnail()): ?>
                        <?= get_the_post_thumbnail($post, 'thumbnail', ['class' => 'w-20 h-14 rounded-[0.25rem] skeleton object-cover shrink-0']) ?>
                    <?php else: ?>
                        <div class="w-20 h-14 rounded-[0.25rem] object-cover bg-gray-100 flex-center shrink-0">
                            <i class="gsmicon-image text-xl text-gray-300"></i>
                        </div>
                    <?php endif ?>

                    <h5 class="body-sm line-clamp-2 grow h-fit"><?= $post->post_title ?></h5>
                </a>
            </li>
        <?php endforeach ?>
    </ul>
    <?= $args['after_widget'] ?? '' ?>
</section>