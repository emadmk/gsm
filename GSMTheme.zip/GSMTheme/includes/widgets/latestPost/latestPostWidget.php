<?php

class LatestPostWidget extends WP_Widget
{

    // Set up the widget's name and description  
    function __construct()
    {
        parent::__construct(
            'latestPostWidget', // Base ID  
            __('آخرین پست ها', 'gsm'), // Name  
            array('description' => __('نمایش لیست آخرین پست ها', 'gsm'),) // Args  
        );

    }

    // The front-end display of the widget  
    public function widget($args, $instance)
    {
        include GSM_DIR . '/includes/widgets/latestPost/widget.php';
    }

    // The back-end form to handle the widget settings  
    public function form($instance)
    {
        include GSM_DIR . '/includes/widgets/latestPost/form.php';
    }

    // Sanitize and save widget settings  
    public function update($new_instance, $old_instance)
    {
        $instance = [];
        $instance['number'] = (!empty($new_instance['number'])) ? strip_tags($new_instance['number']) : 5;
        return $instance;
    }
}
