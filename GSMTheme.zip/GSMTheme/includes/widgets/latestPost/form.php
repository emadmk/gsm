<?php
$number = !empty($instance['number']) ? $instance['number'] : 7;  
?>  

<p>  
    <label for="<?php echo esc_attr($this->get_field_id('number')); ?>"><?php esc_attr_e('number of post:', 'gsm'); ?></label>  
    <input type=number class="widefat" id="<?php echo esc_attr($this->get_field_id('number')); ?>" name="<?php echo esc_attr($this->get_field_name('number')); ?>" value="<?= esc_attr($number) ?>" />
</p>  
<?php 