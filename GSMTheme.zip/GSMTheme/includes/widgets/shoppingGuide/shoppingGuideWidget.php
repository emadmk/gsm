<?php

class ShoppingGuideWidget extends WP_Widget
{

    // Set up the widget's name and description  
    function __construct()
    {
        parent::__construct(
            'ShoppingGuideWidget', // Base ID  
            __('راهنمای خرید', 'gsm'), // Name  
            array('description' => __('نمایش لیست راهنمای خرید', 'gsm'),) // Args  
        );
    }

    // The front-end display of the widget  
    public function widget($args, $instance)
    {
        include GSM_DIR . '/includes/widgets/shoppingGuide/widget.php';
    }

    // The back-end form to handle the widget settings  
    public function form($instance)
    {
        // include GSM_DIR . '/includes/widgets/shoppingGuide/form.php';
    }

    // Sanitize and save widget settings  
    public function update($new_instance, $old_instance)
    {
        $acf = array_values($new_instance['acf']);
        $instance = [];
        $instance['title'] = $acf[0];
        $instance['posts'] = $acf[1];
        return $instance;
    }
}
