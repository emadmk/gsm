<?php


$instance;

$args = [
    'post_type' => ['news', 'article', 'review'],
    'post__in' => $instance['posts'],
    'orderby' => 'post__in',
    'posts_per_page' => count($instance['posts']),
];

$shoppingGuidePosts = new WP_Query($args);
?>
<section class="shopping-guide-container bg-white">
    <?= $args['before_widget'] ?? '' ?>
    <div class="widget-title h3 border-r-2 border-primary-500/[0.64] py-2 px-4 md:-mr-[1px] "><?= $instance['title'] ?></div>
    <div class="subtitle-sm grid grid-cols-1 md:grid-cols-2 gap-4 md:gap-2 mt-4">
        <?php foreach ($shoppingGuidePosts->posts as $i => $post): ?>
            <article>
                <a href="<?= esc_url(get_permalink($post)) ?>" class="relative md:aspect-square md:rounded-lg overflow-hidden flex group <?= $i === 0 ? 'flex-col h-[13.125rem] md:h-auto' : 'px-4 md:p-0 gap-4 md:gap-0 md:flex-col' ?>">
                    <?php if (has_post_thumbnail($post)): ?>
                        <?= get_the_post_thumbnail($post, 'full', ['class' => 'object-cover skeleton transition-all duration-300  ' . ($i === 0 ? 'w-full h-full absolute inset-0 z-0 hover:scale-110' : 'size-20 rounded-lg md:w-full md:h-full md:absolute md:inset-0 group-hover:md:scale-110'), 'loading' => 'lazy']); ?>
                    <?php else: ?>
                        <div class="bg-gray-100 flex-center  shrink-0  <?= $i === 0 ? 'w-full h-full absolute inset-0 z-0' : 'size-20 rounded-lg md:w-full md:h-full md:absolute md:inset-0' ?>">
                            <i class="gsmicon-image text-xl text-gray-300"></i>
                        </div>
                    <?php endif ?>
                    <div class="cover z-10 relative <?= $i === 0 ? 'bg-gray-700/60 blur-[20] p-4 w-full mt-auto text-white h-20 flex items-center ' : 'grow md:grow-0 md:bg-gray-700/60 md:blur-[20] md:p-4 md:w-full md:mt-auto md:text-white md:h-20 md:flex md:items-center ' ?>">
                        <p class="line-clamp-2"><?= esc_html($post->post_title) ?></p>
                    </div>
                </a>
            </article>
        <?php endforeach ?>
    </div>
    <?= $args['after_widget'] ?? '' ?>
</section>