<?php

use GSM\includes\Api;
use GSM\includes\Query;

if (is_single()):
    $queried_object = get_queried_object();
    $brandIds = get_post_meta($queried_object->ID, 'brands', true); // Assume this returns an array of IDs
    if (!empty($brandIds) && is_array($brandIds)):
        $products = Api::getGSMProducts([
            'brandIds' => $brandIds,
        ]);
        if ($products):
?>
            <section class=" p-4  shadow-post-box bg-white md:rounded-lg">
                <?= $args['before_widget'] ?? ''  ?>
                <div class="widget-title h5  pb-4 w-full text-right border-b border-gray-100">محصولات مرتبط با برند</div>
                <ul class="body-sm space-y-4 ">
                    <?php foreach ($products->data as $i => $product):
                        if ($i >= $instance['number']) break;
                        $api = get_field('apis', 'option');
                        $siteAddress = isset($api['site_address']) && !empty($api['site_address']) ? $api['site_address'] : 'https://www.gsm.ir';
                    ?>
                        <li>
                            <a href="<?= $siteAddress . '/product' . '/gp-' . $product->id . '/' . $product->slug ?>" class="flex gap-4 pt-4 items-center">
                                <?php if ($product->image): ?>
                                    <img src="<?= $product->image ?>" alt="<?= __('تصویر', 'gsm') ?> <?= $product->title ?>" class="size-20 rounded-[0.25rem] object-contain shrink-0" width="80" height="80" loading="lazy">
                                <?php else: ?>
                                    <div class="size-20 rounded-[0.25rem] object-cover bg-gray-100 flex-center shrink-0">
                                        <i class="gsmicon-image text-xl text-gray-300"></i>
                                    </div>
                                <?php endif ?>
                                <h5 class="body-sm line-clamp-2 grow h-fit"><?= $product->title ?></h5>
                            </a>
                        </li>
                    <?php endforeach ?>
                </ul>
                <?= $args['after_widget'] ?? '' ?>
            </section>
        <?php endif ?>
    <?php endif ?>
<?php endif ?>