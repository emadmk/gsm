<?php

class BrandRelatedPostWidget extends WP_Widget
{

    // Set up the widget's name and description  
    function __construct()
    {
        parent::__construct(
            'brandRelatedPostWidget', // Base ID  
            __('پست های مرتبط برند', 'gsm'), // Name  
            array('description' => __('نمایش لیست پست های مرتبط برند در صفحه تکی', 'gsm'),) // Args  
        );

    }

    // The front-end display of the widget  
    public function widget($args, $instance)
    {
        include GSM_DIR . '/includes/widgets/brandRelatedPost/widget.php';
    }

    // The back-end form to handle the widget settings  
    public function form($instance)
    {
        include GSM_DIR . '/includes/widgets/brandRelatedPost/form.php';
    }

    // Sanitize and save widget settings  
    public function update($new_instance, $old_instance)
    {
        $instance = [];
        $instance['order'] = (!empty($new_instance['order'])) ? strip_tags($new_instance['order']) : 'date';
        $instance['number'] = (!empty($new_instance['number'])) ? strip_tags($new_instance['number']) : 5;
        return $instance;
    }
}
