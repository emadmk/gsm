<?php
$number = !empty($instance['number']) ? $instance['number'] : 7;  
$order = !empty($instance['order']) ? $instance['order'] :'date';  
?>  

<p>  
    <label for="<?php echo esc_attr($this->get_field_id('order')); ?>"><?php esc_attr_e('order by:', 'gsm'); ?></label>  
    <select class="widefat" id="<?php echo esc_attr($this->get_field_id('order')); ?>" name="<?php echo esc_attr($this->get_field_name('order')); ?>">
        <option value="date" <?= checked($order,'date') ?>><?= __('تاریخ', 'gsm') ?></option>
        <option value="rand" <?= checked($order,'rand') ?>><?= __('تصادفی', 'gsm') ?></option>
    </select>
</p>  
<p>  
    <label for="<?php echo esc_attr($this->get_field_id('number')); ?>"><?php esc_attr_e('number of post:', 'gsm'); ?></label>  
    <input type=number class="widefat" id="<?php echo esc_attr($this->get_field_id('number')); ?>" name="<?php echo esc_attr($this->get_field_name('number')); ?>" value="<?= esc_attr($number) ?>" />
</p>  
<?php 