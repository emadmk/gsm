<?php

use GSM\includes\Query;

if (is_single()):
    $queried_object = get_queried_object();
    $brandIds = get_post_meta($queried_object->ID, 'brands', true); // Assume this returns an array of IDs
    if (!empty($brandIds) && is_array($brandIds)):
        $meta_query = ['relation' => 'OR'];
        foreach ($brandIds as $brandId) {
            $meta_query[] = [
                'key' => 'brands',
                'value' => '"' . $brandId . '"', // For serialized array match
                'compare' => 'LIKE',
            ];
        }
        $args = [
            'post_type' => ['news', 'article', 'review'],
            'orderby' => $instance['order'],
            'posts_per_page' => $instance['number'],
            'post__not_in' => [$queried_object->ID],
            'meta_query' => $meta_query,
        ];

        $relatedPosts = new WP_Query($args);
        if ($relatedPosts->have_posts()):
?>
            <section class=" p-4  shadow-post-box bg-white md:rounded-lg">
                <?= $args['before_widget'] ?? ''  ?>
                <div class="widget-title h5  pb-4 w-full text-right border-b border-gray-100">مطالب مرتبط با برند</div>
                <ul class="body-sm space-y-4 ">
                    <?php foreach ($relatedPosts->posts as $post): ?>
                        <li>
                            <a href="<?= esc_url(get_permalink($post)) ?>" class="flex gap-4 pt-4 items-center">
                                <?php if (has_post_thumbnail()): ?>
                                    <?= get_the_post_thumbnail($post, 'thumbnail', ['class' => 'w-20 h-14 rounded-[0.25rem] skeleton object-cover shrink-0']) ?>
                                <?php else: ?>
                                    <div class="w-20 h-14 rounded-[0.25rem] object-cover bg-gray-100 flex-center shrink-0">
                                        <i class="gsmicon-image text-xl text-gray-300"></i>
                                    </div>
                                <?php endif ?>
                                <h5 class="body-sm line-clamp-2 grow h-fit"><?= $post->post_title ?></h5>
                            </a>
                        </li>
                    <?php endforeach ?>
                </ul>
                <?= $args['after_widget'] ?? '' ?>
            </section>
        <?php endif ?>
    <?php endif ?>
<?php endif ?>