<?php

class AdsWidget extends WP_Widget
{

    // Set up the widget's name and description  
    function __construct()
    {
        parent::__construct(
            'AdsWidget', // Base ID  
            __('تبلیغات', 'gsm'), // Name  
            array('description' => __('نمایش تبلیغات', 'gsm'),) // Args  
        );
        add_action( 'widgets_init', function() { register_widget( self::class ); });

    }

    // The front-end display of the widget  
    public function widget($args, $instance)
    {
        include GSM_DIR . '/includes/widgets/ads/widget.php';
    }

    public function form($instance)
    {
    }

    // Sanitize and save widget settings  
    public function update($new_instance, $old_instance)
    {
        $acf =array_values($new_instance['acf']);
        $instance = $acf ?: [];
        return $instance;
    }
}
