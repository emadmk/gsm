<?php


$instance;

?>
<section class="ads-container">
    <?= $args['before_widget'] ?? ''; ?>
    <div class="ads-title body-sm text-gray-300 pb-2 pt-4 md:pt-6 flex items-center justify-between">
        تبلیغات
        <i class="gsmicon-cross-large size-6 rounded-full bg-black/[0.24] text-white flex-center close-ads cursor-pointer"></i>
    </div>
    <div class="ads-content w-full cursor-pointer" data-zone="<?= $instance[0] ?>">
        <div class="aspect-[4/1] rounded-lg skeleton"></div>
    </div>
    <?= $args['after_widget'] ?? '' ?>
</section>