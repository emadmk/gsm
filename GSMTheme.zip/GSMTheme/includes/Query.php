<?php

namespace GSM\includes;


class Query
{
    function __construct() {}

    // search Queries
    public static  function getSearchPost($string,$items=5)
    {
        global $wpdb;
        $limit  = (int) $items;
        $string = trim((string) $string);

        // Avoid full table scan on empty search string
        if ($string === '') {
            return [];
        }

        $cache_key   = 'gsm_search_post_' . md5($string . '|' . $limit);
        $cache_group = 'gsm_search_post';

        $results = wp_cache_get($cache_key, $cache_group);

        if ($results === false) {
            $like = '%' . $wpdb->esc_like($string) . '%';
            
            if ($limit === -1) {
                // No limit when -1 is passed
                $postQuery = "
                SELECT p.ID,p.post_title FROM {$wpdb->prefix}posts as p
                WHERE p.post_title LIKE %s
                AND p.post_type in ('review','article','news')
                AND p.post_status = 'publish'
                ORDER BY p.post_date DESC
            ";
                $results = $wpdb->get_results($wpdb->prepare($postQuery, $like));
            } else {
                // Apply limit for other values (defensive lower and upper bounds)
                $limit = max(1, (int) $limit);
                $limit = min($limit, 50);
                $postQuery = "
                SELECT p.ID,p.post_title FROM {$wpdb->prefix}posts as p
                WHERE p.post_title LIKE %s
                AND p.post_type in ('review','article','news')
                AND p.post_status = 'publish'
                ORDER BY p.post_date DESC
                LIMIT %d
            ";
                $results = $wpdb->get_results($wpdb->prepare($postQuery, $like, $limit));
            }
            
            wp_cache_set($cache_key, $results, $cache_group, 3600);
        }

        return $results;
    }

    public static function userIsLikedComment($userId, $commentId, $type)
    {
        global $wpdb;
        $result = false;

        $userId    = (int) $userId;
        $commentId = (int) $commentId;
        $type      = (string) $type;

        // Validate inputs before hitting database
        if ($userId <= 0 || $commentId <= 0 || $type === '') {
            return false;
        }

        $likeQuery = "  
        SELECT n.id FROM {$wpdb->prefix}gsm_notifications n  
        WHERE  
        n.action_id = %d  
        AND n.actor_id = %d  
        AND n.action = %s  
        ";

        $likeResult = $wpdb->get_row($wpdb->prepare($likeQuery, $commentId, $userId, $type));

        if (!empty($likeResult)) {
            $result = true;
        }

        return $result;
    }

    public static function getCommentLikeCount($id, $status)
    {
        global $wpdb;

        $id     = (int) $id;
        $status = (string) $status;

        // Validate inputs before hitting database
        if ($id <= 0 || $status === '') {
            return 0;
        }

        $commentQuery = "
        SELECT COUNT(n.id) FROM {$wpdb->prefix}gsm_notifications n
        WHERE
        n.action_id =%d
        AND n.action=%s
        ";
        return  $wpdb->get_var($wpdb->prepare($commentQuery, $id, $status));
    }

    public static function checkLikeStatus($userId, $commentId, $type)
    {
        global $wpdb;
        $result = false;

        $userId    = (int) $userId;
        $commentId = (int) $commentId;
        $type      = (string) $type;

        // Validate inputs before hitting database
        if ($userId <= 0 || $commentId <= 0 || $type === '') {
            return false;
        }

        $likeQuery = "
        SELECT n.id FROM {$wpdb->prefix}gsm_notifications n
        WHERE
        n.action_id =%d
        AND n.actor_id = %d
        AND n.action = %s
        ";
        $likeResult = $wpdb->get_row($wpdb->prepare($likeQuery, $commentId, $userId, $type));
        if (!empty($likeResult)) {
            $result = true;
        }
        return $result;
    }

    public static function getUserIdByMobile($mobile)
    {
        global $wpdb;
        $query = "
		select um.user_id from {$wpdb->prefix}usermeta um
		WHERE
		um.meta_key = 'mobile'
		AND um.meta_value = %s
	";

        $mobile = trim((string) $mobile);

        // Validate and sanitize mobile before using in query
        if ($mobile === '') {
            return 0;
        }

        if (function_exists('sanitize_text_field')) {
            $mobile = sanitize_text_field($mobile);
        }

        return intval($wpdb->get_var($wpdb->prepare($query, $mobile)));
    }

    public static function updatePostViewCount($postId)
    {
        global $wpdb;

        $postId = (int) $postId;

        // Validate post id before updating views
        if ($postId <= 0) {
            return;
        }

        $currentDate = current_time('Y-m-d');
        $tableName = $wpdb->prefix . 'gsm_view';
        $existingView = $wpdb->get_row($wpdb->prepare(
            "SELECT * FROM $tableName WHERE post_id = %d AND DATE(date) = %s",
            $postId,
            $currentDate
        ));

        if ($existingView) {
            $newViewCount = $existingView->view + 1;
            $wpdb->update(
                $tableName,
                array('view' => $newViewCount),
                array('id' => $existingView->id)
            );
        } else {
            $wpdb->insert(
                $tableName,
                array(
                    'post_id' => $postId,
                    'view' => 1,
                    'date' => current_time('mysql')
                )
            );
        }
    }


    public static function getMostViewedPosts($timePeriod = 'today', $limit = 5)
    {
        global $wpdb;

        $tableName = $wpdb->prefix . 'gsm_view';

        // Whitelist time periods to avoid unexpected values
        $allowedPeriods = ['today', 'week', 'month'];
        if (!in_array($timePeriod, $allowedPeriods, true)) {
            $timePeriod = 'today';
        }

        // Defensive casting and upper bound for limit
        $limit = (int) $limit;
        if ($limit <= 0) {
            $limit = 5;
        } elseif ($limit > 50) {
            $limit = 50;
        }

        if ($timePeriod === 'today') {
            $dateCondition = "DATE(date) = CURDATE()";
        } elseif ($timePeriod === 'week') {
            $dateCondition = "YEARWEEK(date, 1) = YEARWEEK(CURDATE(), 1)";
        } elseif ($timePeriod === 'month') {
            $dateCondition = "MONTH(date) = MONTH(CURDATE()) AND YEAR(date) = YEAR(CURDATE())";
        } else {
            return [];
        }

        $query = $wpdb->prepare(
            "SELECT post_id, SUM(view) as total_views   
            FROM $tableName   
            WHERE $dateCondition   
            GROUP BY post_id   
            ORDER BY total_views DESC   
            LIMIT %d",
            $limit
        );

        return $wpdb->get_results($query);
    }

    public static function getAuthorWordCount($authorId)
    {
        global $wpdb;

        $authorId = (int) $authorId;
        if ($authorId <= 0) {
            return 0;
        }

        $query = $wpdb->prepare(
            "SELECT SUM(CAST(meta_value AS UNSIGNED)) FROM $wpdb->postmeta   
             INNER JOIN $wpdb->posts ON $wpdb->posts.ID = $wpdb->postmeta.post_id   
             WHERE $wpdb->posts.post_author = %d   
             AND $wpdb->posts.post_type IN ('news','review','article')  
             AND $wpdb->posts.post_status = 'publish'  
             AND $wpdb->postmeta.meta_key = 'word_count'",
            $authorId
        );

        $totalWordCount = $wpdb->get_var($query);

        return $totalWordCount ? intval($totalWordCount) : 0;
    }

    public static function getAuthorCommentCount($authorId)
    {
        global $wpdb;

        $authorId = (int) $authorId;
        if ($authorId <= 0) {
            return 0;
        }

        $query = $wpdb->prepare(
            "SELECT COUNT(*) FROM $wpdb->comments AS c   
         INNER JOIN $wpdb->posts AS p ON c.comment_post_ID = p.ID   
         WHERE p.post_author = %d   
         AND p.post_type IN ('news', 'review', 'article')   
         AND p.post_status = 'publish'",
            $authorId
        );

        return intval($wpdb->get_var($query)) ?: 0;
    }

    public static function getAuthorPostLikeCount($authorId)
    {
        global $wpdb;

        $authorId = (int) $authorId;
        if ($authorId <= 0) {
            return 0;
        }

        $query = $wpdb->prepare(
            "SELECT SUM(CAST(pm.meta_value AS UNSIGNED)) FROM $wpdb->postmeta AS pm   
         INNER JOIN $wpdb->posts AS p ON p.ID = pm.post_id   
         WHERE p.post_author = %d   
         AND p.post_type IN ('news', 'review', 'article')   
         AND p.post_status = 'publish'   
         AND pm.meta_key = 'like_count'",
            $authorId
        );

        return intval($wpdb->get_var($query)) ?: 0;
    }

    public static function getAuthorPostViewCount($authorId)
    {
        global $wpdb;

        $authorId = (int) $authorId;
        if ($authorId <= 0) {
            return 0;
        }

        $query = $wpdb->prepare(
            "SELECT SUM(CAST(pm.meta_value AS UNSIGNED)) FROM $wpdb->postmeta AS pm   
         INNER JOIN $wpdb->posts AS p ON p.ID = pm.post_id   
         WHERE p.post_author = %d   
         AND p.post_type IN ('news', 'review', 'article')   
         AND p.post_status = 'publish'   
         AND pm.meta_key = 'view_count'",
            $authorId
        );

        return intval($wpdb->get_var($query)) ?: 0;
    }

    public static function getAuthorPostCount($authorId)
    {
        global $wpdb;

        $authorId = (int) $authorId;
        if ($authorId <= 0) {
            return 0;
        }

        $query = $wpdb->prepare(
            "SELECT COUNT(*) FROM $wpdb->posts   
         WHERE post_author = %d   
         AND post_type IN ('news', 'review', 'article')   
         AND post_status = 'publish'",
            $authorId
        );

        return intval($wpdb->get_var($query)) ?: 0;
    }
}
