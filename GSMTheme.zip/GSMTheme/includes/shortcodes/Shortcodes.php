<?php

namespace GSM\includes\shortcodes;


if (!defined('ABSPATH')) {
    exit;
}

class Shortcodes
{
    function __construct() {}

    public function customGridImage($atts, $content = null)
    {
        $atts = shortcode_atts(
            array(
                'columns' => 1,
                'gap' => 0,
                'display' => 'normal',
                'desktop-columns' => -1,
                'desktop-gap' => -1,
            ),
            $atts,
            'gsm_image_grid'
        );
    
        $columns = intval($atts['columns']);
        $gap = intval($atts['gap']);
        $desktopColumns = intval($atts['desktop-columns']);
        $desktopGap = intval($atts['desktop-gap']);
        $display = sanitize_text_field($atts['display']);
    
        // Generate inline styles for the grid
        $gridStyle = "display: grid; grid-template-columns: repeat($columns, 1fr); gap: {$gap}px;";
    
        // Add desktop-specific media query styles if desktop-columns or desktop-gap is set
        $mediaQueryStyle = '';
        $mediaQueryClass = '';
        if ($desktopColumns > -1 || $desktopGap > -1) {
            $mediaQueryClass = $desktopColumns > -1 ? "desktop-columns-$desktopColumns ":'';
            $mediaQueryClass .= $desktopGap > -1 ? "desktop-gap-$desktopGap ":'';
            $desktopGridColumns = $desktopColumns > -1 ? "grid-template-columns: repeat($desktopColumns, 1fr)!important;" : '';
            $desktopGridGap = $desktopGap > -1 ? "gap: {$desktopGap}px !important;" : '';

            $mediaQueryClassSelector = implode('.',explode(' ',trim($mediaQueryClass)));
            $mediaQueryStyle = "
                <style>
                    @media (min-width: 768px) {
                        .gsm-image-grid.$mediaQueryClassSelector {
                            $desktopGridColumns
                            $desktopGridGap
                        }
                    }
                </style>
            ";
        }
    
        // Process the child content
        $content = do_shortcode($content);
    
        // Return the grid with content and media query styles
        return $mediaQueryStyle . "<ul class='gsm-image-grid $display $mediaQueryClass ' style='$gridStyle'>$content</ul>";
    }
    

    public function customSingleImage($atts)
    {
        // Extract attributes for the image
        $atts = shortcode_atts(
            array(
                'src' => '',
                'caption' => '',
                'class' => '',
            ),
            $atts,
            'gsm_image'
        );

        // Sanitize inputs
        $src = esc_url($atts['src']);
        $caption = sanitize_text_field($atts['caption']);
        $class = sanitize_text_field($atts['class']);

        // Check if source is provided
        if (!$src) {
            return '';
        }

        ob_start();
        get_template_part('includes/shortcodes/shortcodes', 'gsm-image', ['_this' => $this, 'src' => $src, 'caption' => $caption, 'class' => $class]);
        return ob_get_clean();
    }

    public function customHighlighter($attr=[],$content = null)
    {
       
        // Process the child content
        $content = do_shortcode($content);
    
        ob_start();
        get_template_part('includes/shortcodes/shortcodes', 'gsm-highlighter', ['_this' => $this, 'content' => $content]);
        return ob_get_clean();
        // [gsm_highlighter]این متن برجسته جهت تست هست[/gsm_highlighter]
    }
    
}
