<?php
$_this = $args['_this'];
$src = $args['src'];
$caption = $args['caption'];
$class = $args['class'];
?>
<li>
    <figure>
        <img src="<?= $src ?>" alt="<?= $caption ?>" loading="lazy" class="<?= $class ?> grid-image-item w-full" />
        <?php if ($caption): ?>
            <figcaption class="image-caption caption text-center w-full py-2"><?= $caption ?></figcaption>
        <?php endif ?>
    </figure>
</li>