<?php
$_this = $args['_this'];
$content = $args['content'];
?>
<div class="gsm-highlighter">
    <div class="highlighter-line"></div>
    <strong><?= $content ?></strong>
</div>