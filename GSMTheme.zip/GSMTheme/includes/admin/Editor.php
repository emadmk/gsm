<?php

namespace GSM\includes\admin;


if (!defined('ABSPATH')) {
    exit;
}

class Editor
{
    function __construct()
    {
        add_filter("mce_buttons", [$this,'addEditorItems']);
        add_filter("mce_external_plugins", [$this,'addEditorPlugins']);
    }

    public function addEditorItems($buttons)
    {
        array_push($buttons, "separator", "gsm_gallery","separator", "gsm_highlighter");
        return $buttons;
    }

    public function addEditorPlugins($pluginArray)
    {
        $pluginArray['gsm_gallery'] = GSM_URL . "/assets/js/admin/gallery-plugin.js";
        $pluginArray['gsm_highlighter'] = GSM_URL . "/assets/js/admin/highlighter-plugin.js";
        return $pluginArray;
    }

}
