<?php

namespace GSM\includes\admin;

use GSM\includes\AuthorStatistics;
use GSM\includes\Query;

if (!defined('ABSPATH')) {
    exit;
}

class Admin
{
    use AuthorStatistics;
    function __construct()
    {
        add_action('gsm_update_author_statistics', [$this, 'updateAuthorStatistics']);

        $editor = new Editor();
    }

    public function savePostExtraData($postId)
    {
        if (defined('DOING_AUTOSAVE') && DOING_AUTOSAVE) {
            return;
        }

        if (!in_array(get_post_type($postId), ['post', 'article', 'review'])) {
            return;
        }

        $postContent = get_post_field('post_content', $postId);
        $authorId = get_post_field('post_author', $postId);
        $cleanContent = strip_tags($postContent);
        $cleanContent = preg_replace('/\s+/', ' ', trim($cleanContent));
        $wordCount = count(preg_split('/\s+/', $cleanContent, -1, PREG_SPLIT_NO_EMPTY));

        // Save the word count as post meta  
        update_post_meta($postId, 'word_count', $wordCount);

        // Update author stats  
        $this->scheduleAuthorStatisticsUpdate($authorId);
    }

    public function updateAuthorPostWordCount($authorId)
    {
        $totalWord = Query::getAuthorWordCount($authorId);
        update_user_meta($authorId, 'word_count', $totalWord);
    }

    public function updateAuthorCommentCount($authorId)
    {
        $totalComments = Query::getAuthorCommentCount($authorId);
        update_user_meta($authorId, 'comment_count', $totalComments);
    }

    public function updateAuthorViewCount($authorId)
    {
        $totalViews = Query::getAuthorPostViewCount($authorId);
        update_user_meta($authorId, 'view_count', $totalViews);
    }

    public function updateAuthorLikeCount($authorId)
    {
        $totalLikes = Query::getAuthorPostLikeCount($authorId);
        update_user_meta($authorId, 'like_count', $totalLikes);
    }
    public function updateAuthorPostCount($authorId)
    {
        $totalPosts = Query::getAuthorPostCount($authorId);
        update_user_meta($authorId, 'post_count', $totalPosts);
    }
}
