<!doctype html>
<html lang="fa">

<head>
    <meta charset="UTF-8">
    <meta name="viewport"
        content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <style>
        html {
            font-family: Tahoma;
            font-size: 15px;
        }

        body {
            direction: rtl;
            text-align: right;
        }

        .col-form-label {
            margin-bottom: 10px;
        }
    </style>
</head>

<body id="edrp">
    <form id="gsm-gallery-form">
        <fieldset>
            <div class="form-group">
                <label>تعداد ستون‌ها (موبایل):</label>
                <input type="number" name="columns" min="1" max="6" value="2" required>
            </div>
            <div class="form-group">
                <label>فاصله بین ستون‌ها (gap):</label>
                <input type="number" name="gap" min="0" max="100" value="10" required>
            </div>
            <div class="form-group">
                <label>تعداد ستون‌ها (دسکتاپ):</label>
                <input type="number" name="desktop-columns" min="1" max="12" value="4">
            </div>
            <div class="form-group">
                <label>فاصله بین ستون‌ها (دسکتاپ):</label>
                <input type="number" name="desktop-gap" min="0" max="100" value="20">
            </div>
            <div class="form-group">
                <label>نمایش تمام عرض:</label>
                <input type="checkbox" name="display" id="display-full-screen" value="full-screen">
                <label for="display-full-screen" style="display:inline;">تمام عرض (full-screen)</label>
            </div>
            <div class="form-group">
                <label>تصاویر گالری:</label>
                <div id="gsm-gallery-images" style="margin-top:10px;"></div>
                <button type="button" id="gsm-add-image" class="btn btn-primary" style="margin-top:10px;">افزودن تصویر جدید</button>
            </div>
            <div class="form-group actions">
                <button type="submit" class="btn btn-success">افزودن به ویرایشگر</button>
                <button type="button" class="btn btn-secondary" onclick="window.top.tinymce.activeEditor.windowManager.close();">انصراف</button>
            </div>
        </fieldset>
    </form>
    <script>
    document.addEventListener('DOMContentLoaded', function() {
        let images = [];
        const container = document.getElementById('gsm-gallery-images');
        function renderImages() {
            container.innerHTML = '';
            images.forEach((img, idx) => {
                container.innerHTML += `
                    <div style="margin-bottom:8px;display:flex;align-items:center;gap:8px;">
                        <input type="text" placeholder="آدرس تصویر" value="${img.url || ''}" data-idx="${idx}" class="gsm-url-input" style="flex:2;">
                        <input type="text" placeholder="کپشن" value="${img.caption || ''}" data-idx="${idx}" class="gsm-caption-input" style="flex:2;">
                        <button type="button" data-idx="${idx}" class="gsm-remove-image">حذف</button>
                    </div>
                `;
            });
            // حذف تصویر
            container.querySelectorAll('.gsm-remove-image').forEach(btn => {
                btn.onclick = function() {
                    images.splice(btn.dataset.idx, 1);
                    renderImages();
                }
            });
            // ویرایش آدرس تصویر
            container.querySelectorAll('.gsm-url-input').forEach(input => {
                input.oninput = function() {
                    images[input.dataset.idx].url = input.value;
                }
            });
            // ویرایش کپشن
            container.querySelectorAll('.gsm-caption-input').forEach(input => {
                input.oninput = function() {
                    images[input.dataset.idx].caption = input.value;
                }
            });
        }
        document.getElementById('gsm-add-image').addEventListener('click', function(e) {
            e.preventDefault();
            images.push({ url: '', caption: '' });
            renderImages();
        });
        // شروع با یک تصویر پیش‌فرض
        images.push({ url: '', caption: '' });
        renderImages();
        // ساخت شورت‌کد و ارسال به ویرایشگر
        document.getElementById('gsm-gallery-form').addEventListener('submit', function(e) {
            e.preventDefault();
            const validImages = images.filter(img => img.url.trim() !== '');
            if (validImages.length === 0) {
                alert('حداقل یک آدرس تصویر وارد کنید');
                return;
            }
            const columns = this.elements['columns'].value;
            const gap = this.elements['gap'].value;
            const desktopColumns = this.elements['desktop-columns'].value;
            const desktopGap = this.elements['desktop-gap'].value;
            const display = this.elements['display'].checked ? 'full-screen' : '';
            let shortcode = `[gsm_image_grid columns="${columns}" gap="${gap}" desktop-columns="${desktopColumns}" desktop-gap="${desktopGap}"`;
            if(display) {
                shortcode += ` display="${display}"`;
            }
            shortcode += `]\n`;
            validImages.forEach(img => {
                shortcode += `[gsm_image src="${img.url}" caption="${img.caption.replace(/"/g, '&quot;')}"][/gsm_image]\n`;
            });
            shortcode += `[/gsm_image_grid]`;
            window.top.tinymce.activeEditor.insertContent(shortcode);
            window.top.tinymce.activeEditor.windowManager.close();
        });
    });
    </script>
    <style>
        button,input {
            cursor: pointer;
            font-family:tahoma;
        }
        #gsm-gallery-form {
            direction: rtl;
            font-family: inherit;
        }

        #gsm-gallery-form .form-group {
            margin-bottom: 15px;
        }

        #gsm-gallery-form label {
            display: block;
            margin-bottom: 5px;
        }

        #gsm-gallery-form input[type="number"],
        #gsm-gallery-form input[type="text"] {
            width: 100%;
            padding: 4px 8px;
            box-sizing: border-box;
        }

        #gsm-gallery-form .btn {
            padding: 6px 16px;
            margin-left: 8px;
            cursor: pointer;
        }

        #gsm-gallery-images {
            margin-top: 10px;
        }
    </style>
</body>

</html>