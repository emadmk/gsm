<?php

namespace GSM\includes;

use WP_Error;

if (!defined('ABSPATH')) {
    exit;
}

class Security
{
    public function __construct()
    {
    }

    /**
     * Generate captcha data for comment form.
     *
     * The generated captcha:
     * - Stores the numeric value in a transient tied to a random token.
     * - Returns an inline SVG image (as data URI) that renders Persian digits.
     *
     * @return array{token:string,image:string}
     */
    public static function generateCommentCaptcha()
    {
        // Generate a simple 6 digit numeric code
        $code = \wp_rand(100000, 999999);

        // Unique token for this captcha instance
        try {
            $token = \bin2hex(\random_bytes(16));
        } catch (\Exception $e) {
            // Fallback if random_bytes is not available
            $token = \wp_generate_password(32, false, false);
        }

        // Store numeric (western) value in transient for limited time
        \set_transient(self::getCommentCaptchaKey($token), (string) $code, 10 * MINUTE_IN_SECONDS);

        // Convert to Persian digits for display
        $persianCode = self::convertToPersianDigits((string) $code);

        // Build a simple SVG-based captcha image so browser fonts handle Persian digits
        $svg = self::buildCaptchaSvg($persianCode);
        $image = 'data:image/svg+xml;base64,' . \base64_encode($svg);

        return [
            'token' => $token,
            'image' => $image,
        ];
    }

    /**
     * Validate submitted captcha for comment form.
     *
     * @param string $token  Captcha token from client.
     * @param string $value  Captcha value entered by user (can contain Persian/Arabic digits).
     * @return bool
     */
    public static function validateCommentCaptcha($token, $value)
    {
        $token = \is_string($token) ? \trim($token) : '';
        $value = \is_string($value) ? \trim($value) : '';

        if ($token === '' || $value === '') {
            return false;
        }

        $key = self::getCommentCaptchaKey($token);
        $stored = \get_transient($key);

        // One-time use: remove stored value regardless of result
        \delete_transient($key);

        if ($stored === false) {
            return false;
        }

        // Normalize all digits (Persian/Arabic/Latin) to Latin before comparison
        $normalizedInput = self::normalizeDigits($value);

        return (string) $stored === (string) $normalizedInput;
    }

    /**
     * Build a unique transient key for storing captcha value.
     *
     * @param string $token
     * @return string
     */
    protected static function getCommentCaptchaKey($token)
    {
        return 'gsm_comment_captcha_' . \md5($token);
    }

    /**
     * Convert western digits to Persian digits for display.
     *
     * @param string $number
     * @return string
     */
    protected static function convertToPersianDigits($number)
    {
        $western = ['0', '1', '2', '3', '4', '5', '6', '7', '8', '9'];
        $persian = ['۰', '۱', '۲', '۳', '۴', '۵', '۶', '۷', '۸', '۹'];

        return \str_replace($western, $persian, $number);
    }

    /**
     * Normalize any Persian/Arabic-Indic digits into western digits.
     *
     * @param string $value
     * @return string
     */
    protected static function normalizeDigits($value)
    {
        // Persian digits
        $persian = ['۰', '۱', '۲', '۳', '۴', '۵', '۶', '۷', '۸', '۹'];
        // Arabic-Indic digits
        $arabicIndic = ['٠', '١', '٢', '٣', '٤', '٥', '٦', '٧', '٨', '٩'];

        $western = ['0', '1', '2', '3', '4', '5', '6', '7', '8', '9'];

        $value = \str_replace($persian, $western, $value);
        $value = \str_replace($arabicIndic, $western, $value);

        // Only keep digits to avoid accidental extra chars
        $value = \preg_replace('/\D+/', '', $value);

        return $value;
    }

    /**
     * Build an SVG string containing the Persian captcha code.
     *
     * Using SVG avoids dependency on server-side fonts and still counts as an image.
     *
     * @param string $persianCode
     * @return string
     */
    protected static function buildCaptchaSvg($persianCode)
    {
        $width = 150;
        $height = 50;

        // Simple background and a few random lines for basic obfuscation
        $bgColor = '#f5f5f5';
        $textColor = '#222222';

        $lines = '';
        for ($i = 0; $i < 4; $i++) {
            $x1 = \rand(0, $width);
            $y1 = \rand(0, $height);
            $x2 = \rand(0, $width);
            $y2 = \rand(0, $height);
            $color = \sprintf('#%02x%02x%02x', \rand(150, 220), \rand(150, 220), \rand(150, 220));
            $lines .= '<line x1="' . $x1 . '" y1="' . $y1 . '" x2="' . $x2 . '" y2="' . $y2 . '" stroke="' . $color . '" stroke-width="1"/>';
        }

        // Centered text; font-family is generic so browser picks available Persian-capable font
        $svg = \sprintf(
            '<svg xmlns="http://www.w3.org/2000/svg" width="%1$d" height="%2$d" viewBox="0 0 %1$d %2$d" role="img" aria-hidden="true">
                <rect width="100%%" height="100%%" fill="%3$s" />
                %4$s
                <text x="50%%" y="50%%" dominant-baseline="middle" text-anchor="middle"
                      font-size="26" font-family="Tahoma, Arial, sans-serif" fill="%5$s">%6$s</text>
            </svg>',
            $width,
            $height,
            \esc_attr($bgColor),
            $lines,
            \esc_attr($textColor),
            \esc_html($persianCode)
        );

        return $svg;
    }

    /**
     * Disable specific WordPress core REST API routes (wp/v2).
     * Blocks: posts, pages, and users list (and single user by ID). Allows: wp/v2/users/me (e.g. menu save).
     * Custom namespaces remain allowed.
     *
     * @param mixed $result Existing authentication result.
     * @return mixed|WP_Error
     */
    public function disableRestApi($result)
    {
        // If another authentication handler has already sent a response, respect it.
        if (!empty($result)) {
            return $result;
        }

        if (!defined('REST_REQUEST') || !REST_REQUEST) {
            return $result;
        }

        $request_uri = isset($_SERVER['REQUEST_URI']) ? sanitize_text_field(wp_unslash($_SERVER['REQUEST_URI'])) : '';
        $path = strtok($request_uri, '?');

        // Block wp/v2/posts (posts list and single post)
        if (preg_match('#/wp-json/wp/v2/posts(?:/|$)#', $path)) {
            return new WP_Error(
                'rest_disabled',
                __('The default WordPress REST API on this site has been disabled.', 'gsm'),
                ['status' => 403]
            );
        }

        // Block wp/v2/pages (pages list and single page)
        if (preg_match('#/wp-json/wp/v2/pages(?:/|$)#', $path)) {
            return new WP_Error(
                'rest_disabled',
                __('The default WordPress REST API on this site has been disabled.', 'gsm'),
                ['status' => 403]
            );
        }

        // Block wp/v2/users list only (allow users/me, users/{id})
        if (preg_match('#/wp-json/wp/v2/users/?$#', $path)) {
            return new WP_Error(
                'rest_disabled',
                __('The default WordPress REST API on this site has been disabled.', 'gsm'),
                ['status' => 403]
            );
        }

        return $result;
    }

    /**
     * Disable XML-RPC by returning false to the xmlrpc_enabled filter.
     *
     * @param bool $enabled Current XML-RPC enabled state.
     * @return bool
     */
    public function disableXmlRpc($enabled)
    {
        return false;
    }

    /**
     * Send basic security headers similar to the provided web server configuration.
     *
     * Intended to be hooked into the "send_headers" action:
     * add_action( 'send_headers', [ $security, 'sendBasicSecurityHeaders' ] );
     *
     * @return void
     */
    public function sendBasicSecurityHeaders()
    {
        // If headers are already sent, do nothing to avoid warnings.
        if (headers_sent()) {
            return;
        }

        // X-Content-Type-Options: nosniff
        if (function_exists('send_nosniff_header')) {
            send_nosniff_header();
        } else {
            header('X-Content-Type-Options: nosniff');
        }

        // X-Frame-Options: SAMEORIGIN
        header('X-Frame-Options: SAMEORIGIN');

        // Referrer-Policy: strict-origin-when-cross-origin
        header('Referrer-Policy: strict-origin-when-cross-origin');
    }

    /**
     * Prevent PHP execution inside the uploads directory by writing a .htaccess rule.
     *
     * Note: This works on Apache-based setups. For Nginx you must add an equivalent
     * location block in the server configuration:
     * location ~* ^/wp-content/uploads/.*\.php$ { deny all; }
     *
     * @return void
     */
    public function preventPhpExecutionInUploads()
    {
        if (!function_exists('wp_get_upload_dir')) {
            return;
        }

        $upload_dir = wp_get_upload_dir();
        if (empty($upload_dir['basedir'])) {
            return;
        }

        $htaccess_path = trailingslashit($upload_dir['basedir']) . '.htaccess';

        $rule_header = '# Deny PHP execution in uploads generated by GSM Security' . PHP_EOL;
        $rules = $rule_header . '<FilesMatch "\.php$">' . PHP_EOL
            . '    Require all denied' . PHP_EOL
            . '</FilesMatch>' . PHP_EOL;

        // If .htaccess already contains our header, do not duplicate rules.
        if (file_exists($htaccess_path)) {
            $contents = @file_get_contents($htaccess_path);
            if ($contents !== false && strpos($contents, $rule_header) !== false) {
                return;
            }
        }

        // Append the rules safely.
        @file_put_contents($htaccess_path, $rules, FILE_APPEND | LOCK_EX);
    }
}

