<?php

use FlameCore\UserAgent\UserAgent;

function persianSort($a, $b)
{
    $collator = new Collator('fa_IR');
    return $collator->compare($a, $b);
}

function isLocalhost()
{
    return in_array($_SERVER['REMOTE_ADDR'], array('127.0.0.1', '::1', '192.168.1.51', '192.168.1.50'));
}

function getFirstParagraph($content, $character = 200)
{

    $str = $content;
    // $str = substr($str, 0, strpos($str, '</p>') + 4);
    $str = strip_tags($str, '');
    $str = substr($str, 0, $character);
    return  $str;
}

function sortByPersianAlphabet($drugs)
{
    $sorted_data = [];
    foreach ($drugs as $drug) {
        $first = mb_substr($drug->PersianName, 0, 1, 'utf-8');
        if ($first == 'ا' || $first == 'آ') {
            $first = 'الف';
        }
        $sorted_data[$first][] = $drug;
    }
    return  $sorted_data;
}

function isAdministrator()
{
    $response = false;
    if (is_user_logged_in()) {
        $user = wp_get_current_user(); // getting & setting the current user 
        $roles = (array) $user->roles;
        if (in_array('administrator', $roles)) {
            $response = true;
        }
    }
    return $response;
}


function explodeUrl()
{
    $exploded_url = explode('/', $_SERVER['REQUEST_URI']);
    if (strpos(end($exploded_url), '?') == 0) {
        unset($exploded_url[count($exploded_url) - 1]);
    }
    return $exploded_url;
}
function explodeUrlWithQuery($url = null)
{
    if ($url === null) {
        $url = $_SERVER['REQUEST_URI'];
    }
    $parsUrl = wp_parse_url($url);
    $explodedPath = explode('/', $parsUrl['path']);
    $queryString = isset($parsUrl['query']) ? explode('&', $parsUrl['query']):false;
    $result['query-string'] = [];
    $result['main-url'] = [];
    if ($queryString) {
        $result['query-string'] = $queryString;
    }
    $i = 1;
    $homeExplode = explode('/', home_url());
    foreach ($explodedPath as $slug) {
        if (empty($slug) || in_array($slug, $homeExplode)) continue;
        $result['main-url'][$i] = $slug;
        $i++;
    }
    return $result;
}


function ajaxResponse($success = true, $message = null, $content = null, $status = 200)
{

    $response = array(
        'success' => $success,
        'message' => $message,
        'content' => $content
    );

    wp_send_json($response, $status);
    wp_die();
}



function isRoleExists($role)
{

    if (!empty($role)) {
        return $GLOBALS['wp_roles']->is_role($role);
    }

    return false;
}

function getUserIp()
{
    if (!empty($_SERVER['HTTP_CLIENT_IP'])) {
        //check ip from share internet
        $ip = $_SERVER['HTTP_CLIENT_IP'];
    } elseif (!empty($_SERVER['HTTP_X_FORWARDED_FOR'])) {
        //to check ip is pass from proxy
        $ip = $_SERVER['HTTP_X_FORWARDED_FOR'];
    } else {
        $ip = $_SERVER['REMOTE_ADDR'];
    }
    return $ip;
}

function getPageIdByTemplate($template)
{
    $args = [
        'post_type'  => 'page',
        'fields'     => 'ids',
        'nopaging'   => true,
        'meta_key'   => '_wp_page_template',
        'meta_value' => $template
    ];
    $pages = get_posts($args);
    return $pages;
}

function sanitizeNestedObject($object)
{
    $sanitized_object = array();

    foreach ($object as $key => $value) {
        if (is_array($value) || is_object($value)) {
            $sanitized_object[$key] = /* todo */ sanitizeNestedObject((array)$value);
        } elseif (is_string($value)) {
            $sanitized_object[$key] = sanitize_text_field($value);
        } else {
            $sanitized_object[$key] = $value;
        }
    }
    return $sanitized_object;
}

function isGoogleBot()
{
    $userAgent = UserAgent::createFromGlobal();
    return $userAgent->getBrowserName() === 'googlebot';
}

function generateSpinner($class = 'flex gap-2', $dotClass = "bg-white size-4")
{
    ob_start();
?>
    <div class="gsm-spinner <?= $class ?>">
        <div class="bounce1 <?= $dotClass ?>"></div>
        <div class="bounce2 <?= $dotClass ?>"></div>
        <div class="bounce3 <?= $dotClass ?>"></div>
    </div>
<?php
    return ob_get_clean();
}


function classNames(...$args)
{
    $classes = [];

    foreach ($args as $arg) {
        if (is_string($arg)) {
            $classes[] = $arg;
        } elseif (is_array($arg)) {
            foreach ($arg as $key => $value) {
                if ($value) {
                    // Process dynamic keys with placeholders like `btn-{$variant}`
                    if (strpos($key, '{$') !== false) {
                        $key = preg_replace_callback('/\{\$(.*?)\}/', function ($matches) use ($value) {
                            return $value;
                        }, $key);
                    }
                    $classes[] = $key;
                }
            }
        }
    }

    // Join all classes with a space separator
    return implode(' ', $classes);
}

function removeKeys($array) {  
    $newArray = [];  
    
    foreach ($array as $value) {  
        if (is_array($value)) {  
            $newArray[] = removeKeys($value);
        } else {  
            $newArray[] = $value;
        }  
    }  
    
    return $newArray;
}  

function gsmImageSrc($url)
    {
        $url = str_replace('s3.gsm.ir', 's5.gsm.ir', $url);

        return $url;
    }
