<?php

namespace GSM\includes;

use WP_Query;

if (!defined('ABSPATH')) {
    exit;
}

class Cron
{
    function __construct() {
        add_filter('cron_schedules', [$this, 'cronSchedules']);
        
        add_action('gsm_brand_update_hook', [$this, 'brandUpdateHandler']);
        
        add_action('after_setup_theme', [$this, 'addCronJobEvent']);
        add_action('switch_theme', [$this, 'removeCronJobEvent']);
    }


    public function cronSchedules($schedules)
    {
        if (!isset($schedules['daily'])) {
            $schedules['daily'] = [
                'interval' => 86400,
                'display'  => __('Once Daily')
            ];
        }
        return $schedules;
    }

    public function addCronJobEvent()
    {
        if (!wp_next_scheduled('gsm_brand_update_hook')) {
            wp_schedule_event(time(), 'daily', 'gsm_brand_update_hook');
        }
    }
    public function removeCronJobEvent()
    {
        $timestamp = wp_next_scheduled('gsm_brand_update_hook');
        if ($timestamp) {
            wp_unschedule_event($timestamp, 'gsm_brand_update_hook');
        }
    }

    public function brandUpdateHandler()
    {
        $post_types = ['news', 'article', 'review'];
        $postsPerPage = 500;

        foreach ($post_types as $postType) {
            $allBrandIds = [];
            $paged = 1;

            do {
                $query = new WP_Query([
                    'post_type'      => $postType,
                    'posts_per_page' => $postsPerPage,
                    'paged'          => $paged,
                    'fields'         => 'ids',
                    'no_found_rows'  => false,
                ]);

                foreach ($query->posts as $postId) {
                    $brands = get_post_meta($postId, 'brands', true);
                    if (is_array($brands)) {
                        $allBrandIds = array_merge($allBrandIds, $brands);
                    }
                }

                $paged++;
            } while ($query->max_num_pages >= $paged);

            $allBrandIds = array_unique($allBrandIds);

            update_option('all_' . $postType . '_brands', $allBrandIds);
        }
    }
}
