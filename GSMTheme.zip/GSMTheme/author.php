<?php 
namespace GSM;
use GSM\templates\author\Author;
get_header();
$author = new Author();
$author->displayContent();
get_footer();