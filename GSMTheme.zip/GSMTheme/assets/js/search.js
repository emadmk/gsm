(function ($) {
  "use strict";
  class Search {
    constructor() {
      let _this = this;
      this.toast = new Toast();
      // show more product
      $(document).on("click", ".product-show-more", function (e) {
        _this.showMoreProduct($(this));
      });
      $(document).on("click", ".post-show-more", function (e) {
        _this.showMorePost($(this));
      });
    }

    showMoreProduct(btn) {
      const page = parseInt(btn.data("page"));
      const allPage = parseInt(btn.data("all-page"));
      $(".product-item").each(function (e, i) {
        if (e + 1 > (page - 1) * 32 && e + 1 <= page * 32) {
          $(this).removeClass("hidden").addClass("flex");
        }
      });
      btn.data("page", page + 1);
      if (page >= allPage) {
        btn.addClass("hidden");
        $(".pagination").removeClass("hidden");
      } else {
        btn.removeClass("hidden");
      }
    }
    showMorePost(btn) {
      const page = parseInt(btn.data("page"));
      const allPage = parseInt(btn.data("all-page"));
      $(".post-item").each(function (e, i) {
        if (e + 1 > (page - 1) * 32 && e + 1 <= page * 32) {
          $(this).removeClass("hidden").addClass("flex");
        }
      });
      btn.data("page", page + 1);
      if (page >= allPage) {
        btn.addClass("hidden");
        $(".pagination").removeClass("hidden");
      } else {
        btn.removeClass("hidden");
      }
    }



  }
  const search = new Search();
})(jQuery);
