(function ($) {
  "use strict";

  class ReviewsList {
    constructor() {
      const _this = this;
      this.searchTimeout;
      this.isSearching = false;
      this.toast = new Toast();

      if ($(".pin-review-slider").length) {
        const pinReview = new Splide(".pin-review-slider", {
          direction: "rtl",
          pagination: true,
          gap: 20,
          arrows: false,
          mediaQuery: "min",
          perPage: 1,
          breakpoints: {
            768: {
              perPage: 2,
            },
            340: {
              perPage: 1,
            },
          },
        });
        pinReview.mount();
      }

      $(document).on("click", ".page-item", function (e) {
        _this.updateList($(this).data("page"));
      });
      $(document).on("click", ".brand-item", function (e) {
        $(".brand-item").removeClass("selected");
        $(this).addClass("selected");
        _this.updateList(1);
      });

      // seo box
      _this.calcSeoBoxHeight();
      $(document).on("click", ".show-more-seo-box", function (e) {
        $(".seo-content").toggleClass("max-h-[9rem] md:max-h-[4.5rem]");
        $(this).find("i").toggleClass("rotate-180");
        $(".bg-show-more-cover").toggleClass("hidden");
        const text = $(this).find("span");
        if (text.hasClass("close")) {
          text.html("کمتر").toggleClass("close open");
        } else {
          text.html("بیشتر").toggleClass("close open");
        }
      });
    }

    calcSeoBoxHeight() {
      if ($(".seo-content").length) {
        const height = $(".seo-content").height();
        console.log($(window).width(), height);
        if (
          ($(window).width() > 768 && height > 72) ||
          ($(window).width() < 768 && height > 144)
        ) {
          $(".seo-content").addClass("max-h-[9rem] md:max-h-[4.5rem]");
          $(".show-more-seo-box").addClass("flex-center").removeClass("hidden");
          $(".bg-show-more-cover").removeClass("hidden");
        }
      }
    }

    updateList(page = 1) {
      const _this = this;
      if (_this.isSearching) return;
      _this.generateLoading(".list-container");
      $(".pagination").addClass("skeleton");
      $(".gsm-pagination").addClass("opacity-0");
      _this.isSearching = true;
      const arg = {
        page,
        pinned: $(".reviews-list-container").data("pinned-list").split(","),
      };
      const formData = new FormData();
      formData.append("data", JSON.stringify(arg));
      $.ajax({
        url: gsmArr.homeUrl + "/wp-ajax/reviews-list/filter",
        data: formData,
        processData: false,
        contentType: false,
        dataType: "json",
        mode: "no-cors",
        type: "POST",
        success: function (response) {
          if (response.success) {
            $(".list-container").html(response.content.list);
            $(".pagination").html(response.content.pagination);
          } else {
            _this.toast.create(
              response.message || "خطا د در دریافت اطلاعات از سرور",
              "error",
              4000
            );
            $(".list-container").html("");
            $(".pagination").html("");
          }
          $(".pagination").removeClass("skeleton");
          // window.dispatchEvent(
          //   new CustomEvent("queryLoaded", {
          //     detail: { container: $(".products-list").get(0) },
          //   })
          // );
        },
        error: function (xhr, status, error) {
          $(".pagination").removeClass("skeleton");
          $(".list-container").html("");
          _this.toast.create(
            xhr.responseJSON?.message ||
              "خطای ناشناخته لطفاً مجدداً سعی نمایید",
            "error",
            3000
          );
        },
        complete: function () {
          _this.isSearching = false;
          _this.addNewUrl(arg);
        },
      });
    }

    generateLoading(selector, number = 20) {
      let skeleton = "";
      for (let i = 0; i < number; i++) {
        skeleton += `
        <div class="w-full border border-gray-200 rounded-2xl bg-white flex md:flex-col overflow-hidden">
          <div class="size-[6.5rem] md:w-full md:h-[10.5rem] object-cover shrink-0 skeleton"></div>
          <div class="grow flex flex-col px-4 py-3 md:py-4">
            <div class="h-5 mt-2 rounded-full skeleton w-3/4"></div>
              <div class="flex items-center justify-between gap-2 caption mt-[0.625rem]">
                <div class="flex-center gap-1 w-1/3">
                  <div class="hidden md:block size-5 skeleton rounded-full shrink-0"></div>
                  <div class="grow h-2 skeleton rounded-full"></div> 
                </div>
                <div class="w-1/3 h-2 skeleton rounded-full"></div> 
              </div>
          </div>
        </div>
        `;
      }
      $(selector).html(skeleton);
    }

    addNewUrl({ page, brand }) {
      const params = {};
      if (page > 1) {
        params.pg = page;
      }
      if (brand) {
        params.brand = brand;
      }

      let newUrl;
      if (Object.keys(params).length) {
        const baseURL = window.location.href.split("?")[0];
        const queryString = new URLSearchParams(params).toString();

        newUrl = `${baseURL}?${queryString}`;
      } else {
        newUrl = window.location.href.split("?")[0];
      }
      if (history.pushState) {
        history.pushState(null, null, newUrl);
      } else {
        window.location.href = newUrl;
      }
    }
  }

  const reviewsList = new ReviewsList();
})(jQuery);
