(function ($) {
  "use strict";

  class Ads {
    constructor() {
      const _this = this;
      this.adsData = [];

      // view counter
      $(document).ready(function () {
        if (!_this.adsData.length) {
          _this.getAdsData();
        }
        $(window).on("resize", function () {
          _this.applyAds();
        });

        _this.closeAdsHandler();
      });
    }

    getAdsData() {
      const _this = this;
      $.ajax({
        url: gsmArr.adsUrl,
        processData: false,
        contentType: false,
        dataType: "json",
        mode: "no-cors",
        type: "GET",
        success: function (response) {
          if (response.results) {
            _this.adsData = response.results;
            _this.applyAds();
          }
        },
        error: function (xhr, status, error) {
          _this.applyAds();
        },
        complete: function () {},
      });
    }

    applyAds() {
      const _this = this;
      const adsData = _this.adsData;
      const adsZone = $(".ads-content");
      adsZone.each(function () {
        const zone = $(this).data("zone");
        const ad = adsData.find((ad) => ad.zone === zone);
        if (ad) {
          const imageUrl =
            $(window).width() > 768
              ? ad.images.find((image) => image.device === "lg")?.image
              : ad.images.find((image) => image.device === "sm")?.image;
          if (imageUrl) {
            $(this).html(`
                <a href="${gsmArr.backend_base_url}${ad.url}" target="_blank">
                    <img src="${imageUrl}" alt="${ad.title}" class="w-full h-full object-cover">
                </a>
                `);
          } else if (ad && ad.html_content.length) {
            $(this).html(`
                <a href="${gsmArr.backend_base_url}${ad.url}" target="_blank">
                    ${ad.html_content}
                </a>
                `);
          } else {
            $(this).parents(".ads-container").addClass("hidden");
          }
        } else {
          $(this).parents(".ads-container").addClass("hidden");
        }
      });
    }

    closeAdsHandler() {
      $(document).on("click", ".close-ads", function () {
        $(this).parents(".ads-container").slideUp();
      });
    }
  }

  const ads = new Ads();
})(jQuery);
