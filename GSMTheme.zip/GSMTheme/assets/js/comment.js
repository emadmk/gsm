(function ($) {
  "use strict";
  class Comment {
    constructor() {
      let _this = this;
      this.toast = new Toast();

      _this.isUpdating = false;
      $(document).on("submit", ".comment-form", function (e) {
        e.preventDefault();
        _this.submitComment($(this));
      });

      // show more comment
      $(document).on("click", ".comment-show-more", function (e) {
        _this.showMoreComment($(this));
      });

      // comment pagination
      $(document).on("click", ".page-item", function (e) {
        _this.updateList($(this).data("page"));
      });

      // captcha refresh
      $(document).on("click", ".comment-captcha-refresh", function (e) {
        e.preventDefault();
        _this.refreshCaptcha();
      });

      // apply initial captcha from localized data (if exists)
      if (typeof commentData !== "undefined" && commentData.captcha) {
        _this.applyCaptcha(commentData.captcha);
      }
    }

    submitComment(form) {
      let _this = this;
      let btn = form.find("button");
      const content = $("#gsm-comment-content").val();
      const name = Number(commentData.isLogin)
        ? ""
        : $("#gsm-comment-name").val();
      const captchaValue = $("#gsm-comment-captcha").val();
      const captchaToken = $("#gsm-comment-captcha-token").val();
      if (!commentData.isLogin && !name.length) {
        _this.toast.create("لطفاً نام خود را وارد نمایید", "error", 3000);
        return;
      }
      if (!content.length) {
        _this.toast.create("لطفاً متن نظر خود را وارد نمایید", "error", 3000);
        return;
      }
      if (!Number(commentData.isLogin)) {
        if (!captchaValue || !captchaValue.length) {
          _this.toast.create(
            "لطفاً کد امنیتی را وارد نمایید",
            "error",
            3000
          );
          return;
        }
      }

      btn.prop("disabled", true).addClass("loading");

      const arg = {
        postId: commentData.postId,
        name,
        content: content,
        postType: commentData.postType,
        captchaToken,
        captchaValue,
      };
      const formData = new FormData();
      formData.append("data", JSON.stringify(arg));
      $.ajax({
        url: gsmArr.homeUrl + "/wp-ajax/comment/add-comment",
        data: formData,
        processData: false,
        contentType: false,
        dataType: "json",
        mode: "no-cors",
        type: "POST",
        success: function (response) {
          if (response.success) {
            _this.toast.create(response.message, "success", 3000);
            $(".comment-container").prepend(response.content.commentHtml);
            $(".comment-form input ,.comment-form textarea").val("");
          } else {
            _this.toast.create(
              response.message || "خطای ناشناخته لطفاً مجدداً سعی نمایید",
              "error",
              3000
            );
          }
          _this.refreshCaptcha();
        },
        error: function (xhr, status, error) {
          _this.toast.create(
            xhr.responseJSON?.message ||
              "خطای ناشناخته لطفاً مجدداً سعی نمایید",
            "error",
            3000
          );
          _this.refreshCaptcha();
        },
        complete: function (response) {
          btn.prop("disabled", false).removeClass("loading");
        },
      });
    }

    showMoreComment(btn) {
      const page = parseInt(btn.data("page"));
      const allPage = parseInt(btn.data("all-page"));
      $(".comment-item").each(function (e, i) {
        if (e + 1 > (page - 1) * 5 && e + 1 <= page * 5) {
          $(this).removeClass("hidden");
        }
      });
      btn.data("page", page + 1);
      if (page >= allPage) {
        btn.addClass("hidden");
        $(".pagination").removeClass("hidden");
      } else {
        btn.removeClass("hidden");
      }
    }

    updateList(page = 1) {
      const _this = this;
      if (_this.isUpdating) return;
      _this.generateLoading(".comment-container");
      $(".pagination").addClass("skeleton");
      $(".pagination .gsm-pagination").addClass("opacity-0");
      _this.isUpdating = true;
      const arg = {
        page,
        postId: commentData.postId,
        maxPages: $(".pagination").data("max-page"),
      };
      const formData = new FormData();
      formData.append("data", JSON.stringify(arg));
      $.ajax({
        url: gsmArr.homeUrl + "/wp-ajax/comment/list",
        data: formData,
        processData: false,
        contentType: false,
        dataType: "json",
        mode: "no-cors",
        type: "POST",
        success: function (response) {
          if (response.success) {
            $(".comment-container").html(response.content.list);
            $(".pagination").html(response.content.pagination);
            _this.addNewUrl(arg);

          } else {
            _this.toast.create(
              response.message || "خطا د در دریافت اطلاعات از سرور",
              "error",
              4000
            );
            $(".comment-container").html("");
            $(".pagination").html("");
          }
          $(".pagination").removeClass("skeleton");
          // window.dispatchEvent(
          //   new CustomEvent("queryLoaded", {
          //     detail: { container: $(".products-list").get(0) },
          //   })
          // );
        },
        error: function (xhr, status, error) {
          $(".pagination").removeClass("skeleton");
          $(".comment-container").html("");
          _this.toast.create(
            xhr.responseJSON?.message ||
              "خطای ناشناخته لطفاً مجدداً سعی نمایید",
            "error",
            3000
          );
        },
        complete: function () {
          _this.isUpdating = false;
        },
      });
    }

    generateLoading(selector, number = 15) {
      let skeleton = "";
      for (let i = 0; i < number; i++) {
        skeleton += `
        <div class="comment-item body-sm relative p-4 bg-white md:rounded-lg shadow-post-box ">
            <div class="space-y-4">
                <div class="comment-author flex items-center gap-2">
                    <h3 class=" flex h-4 rounded-full skeleton w-6 md:w-12 skeleton"></h3>
                    <div class="h-3 rounded-full w-20 md:w-28 skeleton"></div>
                </div>
                <div class="comment-content rounded-lg py-2 px-4 skeleton h-20 md:h-12"></div>
            </div>
        </div>
        `;
      }
      $(selector).html(skeleton);
    }

    addNewUrl({ page }) {
      const params = {};
      if (page > 1) {
        params.pg = page;
      }

      let newUrl;
      if (Object.keys(params).length) {
        const baseURL = window.location.href.split("?")[0];
        const queryString = new URLSearchParams(params).toString();

        newUrl = `${baseURL}?${queryString}`;
      } else {
        newUrl = window.location.href.split("?")[0];
      }
      if (history.pushState) {
        history.pushState(null, null, newUrl);
      } else {
        window.location.href = newUrl;
      }
    }

    refreshCaptcha() {
      const _this = this;
      const formData = new FormData();
      formData.append("data", JSON.stringify({}));

      $.ajax({
        url: gsmArr.homeUrl + "/wp-ajax/comment/captcha",
        data: formData,
        processData: false,
        contentType: false,
        dataType: "json",
        mode: "no-cors",
        type: "POST",
        success: function (response) {
          if (response.success && response.content?.captcha) {
            _this.applyCaptcha(response.content.captcha);
          } else {
            _this.toast.create(
              response.message ||
                "خطا در دریافت کد امنیتی، لطفاً مجدداً تلاش نمایید",
              "error",
              3000
            );
          }
        },
        error: function () {
          _this.toast.create(
            "خطا در دریافت کد امنیتی، لطفاً مجدداً تلاش نمایید",
            "error",
            3000
          );
        },
      });
    }

    applyCaptcha(captcha) {
      if (!captcha) return;
      if (captcha.image) {
        $(".comment-captcha-image").attr("src", captcha.image);
      }
      if (captcha.token) {
        $("#gsm-comment-captcha-token").val(captcha.token);
      }
      $("#gsm-comment-captcha").val("");
    }
  }
  let newComment = new Comment();
})(jQuery);
