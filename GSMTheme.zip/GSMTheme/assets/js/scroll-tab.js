(function ($) {
  "use strict";
  $.gsmScrollTab = function (selector, scrollTrigger = true) {
    const tabSelector = `${selector}-tab`;
    const tabContainer = `${selector}-tab-container`;
    const content = `${selector}-content`;
    const line = $(`${selector} .line`);

    $(tabSelector).on("click", function (e) {
      if (!scrollTrigger) {
        if ($(this).hasClass("text-primary-500")) return;
        $(content).addClass("hidden");
        const tabName = $(this).data("tab");
        $(`${content}.${tabName}-content`).removeClass("hidden");
      }
      $(tabSelector).removeClass("text-primary-500 subtitle-sm");

      const lineWidth = $(this).outerWidth();
      const tabOffset = $(this).offset().left;
      const containerOffset = $(tabContainer).offset().left;
      const rightPosition =
        containerOffset + $(tabContainer).outerWidth() - tabOffset - lineWidth;

      line.css({
        width: lineWidth + "px",
        right: rightPosition + "px",
      });

      $(this).addClass("text-primary-500 subtitle-sm");
    });

    const navHeight = $(`${selector}`).outerHeight();
    let offset = 52;
    if ($(window).width() < 768) {
      offset = 52;
    } else {
      offset = 48;
    }
    if (scrollTrigger) {
      $(window).on("scroll", function () {
        const cur_pos = $(this).scrollTop();
        $(content).each(function () {
          const top = $(this).offset().top - navHeight - offset,
            bottom = top + $(this).outerHeight();
          if (cur_pos >= top && cur_pos <= bottom) {
            const currentMenu = $(tabContainer).find(
              'a[href="#' + $(this).attr("id") + '"]'
            );
            $(tabSelector).removeClass("text-primary-500");
            const lineWidth = currentMenu.outerWidth();
            const tabOffset = currentMenu.offset().left;
            const containerOffset = $(tabContainer).offset().left;
            const rightPosition =
              containerOffset +
              $(tabContainer).outerWidth() -
              tabOffset -
              lineWidth;

            line.css({
              width: lineWidth + "px",
              right: rightPosition + "px",
            });

            currentMenu.addClass("text-primary-500");
          }
        });
      });
    } else {
    }
  };
})(jQuery);
