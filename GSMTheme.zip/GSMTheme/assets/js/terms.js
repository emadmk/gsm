(function ($) {
  "use strict";

  class Terms {
    constructor() {
      const _this = this;
      $.gsmToggleTab('.faq-section');
    }

  }
  const terms = new Terms();
})(jQuery);
