(function ($) {
  "use strict";
  $.gsmToggleTab = function (selector, { singleOpen = true } = {}) {
    const tabSelector = `${selector}-item`;
    const contentSelector = `${selector}-content`;

    $(tabSelector).on("click", function (e) {
      const toggleContent = $(this).siblings(contentSelector);
      const arrow = $(this).find("span.plus");
      if (singleOpen) {
        if (arrow.hasClass("rotate-90")) {
          $(contentSelector).slideUp(300);
          $(tabSelector).find("span.plus").addClass("rotate-90");
          if ($(`${tabSelector} h4`).hasClass("body-sm")) {
            $(tabSelector).find('h4').removeClass("h4").addClass("body-sm");
          }
        }
      }
      if ($(`${tabSelector} h4`).hasClass("body-sm")) {
        $(this).find('h4').toggleClass("h4 body-sm");
      }
      toggleContent.slideToggle(300);
      $(this).find(".plus").toggleClass("rotate-90");
    });
  };
})(jQuery);
