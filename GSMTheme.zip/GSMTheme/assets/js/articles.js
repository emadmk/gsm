(function ($) {
  "use strict";

  class Articles {
    constructor() {
      const _this = this;
      this.toast = new Toast();

      // view counter
      $(document).ready(function () {
        _this.viewCount();
      });

      if (typeof $.gsmToggleTab !== "undefined") {
        $.gsmToggleTab(".faq-section");
      }

      $(document).on("click", ".table-of-content .head-section", function (e) {
        $(this).parent().find(".content-section").slideToggle(500);
        $(this).find("i.arrow").toggleClass("rotate-180");
      });

      this.sideBarHandler();
    }

    viewCount() {
      const arg = {
        id: $(".articles-container").data("articles-id"),
      };
      const formData = new FormData();
      formData.append("data", JSON.stringify(arg));
      $.ajax({
        url: gsmArr.homeUrl + "/wp-ajax/articles/view",
        data: formData,
        processData: false,
        contentType: false,
        dataType: "json",
        mode: "no-cors",
        type: "POST",
        success: function (response) {
          if (response.success) {
          } else {
          }
        },
        error: function (xhr, status, error) {
          _this.toast.create(
            xhr.responseJSON?.message ||
              "خطای ناشناخته لطفاً مجدداً سعی نمایید",
            "error",
            3000
          );
        },
      });
    }

    sideBarHandler() {
      const sideBarHeight = $(".main-sidebar-container");
      if (sideBarHeight.height() < $(window).height() - 112) {
        $("aside").removeClass("flex");
        $("#sticky-sidebar")
          .removeClass("h-fit md:bottom-0 md:pb-4")
          .addClass("md:top-4");
      }
    }
  }

  const articles = new Articles();
})(jQuery);
