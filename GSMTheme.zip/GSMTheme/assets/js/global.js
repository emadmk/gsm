(function ($) {
  "use strict";

  class Global {
    constructor() {
      const _this = this;
      this.searchTimeout;
      this.toast = new Toast();
      // mobile menu toggle
      $(document).on("click", ".hamburger-menu, .menu-close", function (e) {
        $(".menu-container").toggleClass("-right-full right-0");
      });
      $(document).on(
        "click",
        ".search-btn, .search-close",
        function (e) {

          $(".main-search-form").toggleClass("-right-full right-0");
          $(".search-result-backdrop").toggleClass("hidden");
          $(".main-search-container").toggleClass("hidden");
        }
      );
      // search bar toggle
      $(document).on(
        "click",
        ".search-icon-container , .search-overlay, .close-search",
        function (e) {
          $(".search-overlay").toggleClass("hidden");
          $(".search-container").toggleClass("translate-y-[-150%]");
        }
      );

      // search action
      $(document).on("change pest keyup", "#main-search", function (e) {
        e.preventDefault();
        clearTimeout(_this.searchTimeout);
        _this.searchTimeout = setTimeout(() => {
          _this.searchRequest($(this));
        }, 800);
      });

      // search outside click handler
      $(document).on("mousedown", function (e) {
        if (!$(e.target).closest(".main-search-form").length) {
          $(".search-result-backdrop").addClass("hidden");
          $(".main-search-container").addClass("hidden");$(".search-result-backdrop").addClass("hidden");
        }
      });

      // $("#main-search").on("focus", function () {
      //   if ($(".search-result").length) {
      //     $(".main-search-result-content").removeClass("hidden");
      //     $(".search-result-backdrop").removeClass("hidden");
      //   }
      // });
      // search result toggle tab
      $(document).on("click", ".search-tab-item", function (e) {
        const tab = $(this).data("tab");
        $(".search-tab-item").removeClass("bg-primary-500 text-white");
        $(this).addClass("bg-primary-500 text-white");
        $(".search-tab-content").addClass("hidden");
        $(`.search-tab-content.search-tab-${tab}`).removeClass("hidden");
        if(tab === "all") {
          $(".search-tab-content").removeClass("hidden");
        }
      });

      // mobile profile menu action
      $(document).on("click", ".profile-logo-container", function (e) {
        if ($(window).width() < 1024) {
          $(".profile-menu").toggleClass(
            "opacity-0 opacity-100 pointer-events-none pointer-events-auto translate-y-4 translate-y-0 "
          );
        }
      });

      // logout action
      $(document).on("click", ".logout-btn", function (e) {
        _this.logoutRequest($(this));
      });

      // menu items toggle
      $(".mobile-menu-item").click(function (e) {
        if ($(window).width() < 768) {
          const self = $(this);
          $(this)
            .siblings(".gsm-sub-menu")
            .slideToggle(function () {
              if ($(this).is(":visible")) {
                self
                  .find(".gsmicon-chevron-down")
                  .addClass("rotate-180 duration-200");
                $(this).css("display", "flex");
              } else {
                self
                  .find(".gsmicon-chevron-down")
                  .removeClass("rotate-180 duration-200");
              }
            });
        }
      });

      $(document).on(
        "click",
        ".menu-item-has-children > .item-inner",
        function (e) {
          $(this).siblings("ul").slideToggle();
          $(this).find("i").toggleClass("rotate-180");
        }
      );

      // max input typing
      $(document).on("input", ".input-number , .phone-number", function (e) {
        let value = $(this).val();
        // Remove any non-numeric characters
        value = _this.p2e(_this.a2e(value));
        value = value.replace(/\D/g, "");
        if ($(this).hasClass("phone-number")) {
          value = value.slice(0, 11);
        }
        $(this).val(value);
      });

      // grid image width handler
      _this.gridImageSizeHandler();
      $(window).resize(function () {
        _this.gridImageSizeHandler();
      });
    }

    searchRequest(input) {
      const _this = this;
      const search = input.val();
      if (input.prop("disabled")) return;
      const container = $(".main-search-result-content");
      const loading = input.parent().find(".loader");
      container.html("").addClass("hidden");
      if (search.length > 2) {
        loading.removeClass("hidden");
        input.prop("disabled", true);
        input.addClass("opacity-60");
        const arg = {
          search,
        };
        const formData = new FormData();
        formData.append("data", JSON.stringify(arg));
        $.ajax({
          url: gsmArr.homeUrl + "/wp-ajax/general/search",
          data: formData,
          processData: false,
          contentType: false,
          dataType: "json",
          mode: "no-cors",
          type: "POST",
          success: function (response) {
            if (response.success) {
              container.html(response.content.result).removeClass("hidden");
            }
          },
          error: function (xhr, status, error) {
            _this.toast.create(
              xhr.responseJSON?.message ||
                "خطای ناشناخته لطفاً مجدداً سعی نمایید",
              "error",
              3000
            );
          },
          complete: function () {
            loading.addClass("hidden");
            input.prop("disabled", false);
            input.removeClass("opacity-60");
          },
        });
      }
    }

    logoutRequest(btn) {
      const _this = this;
      const loading = btn.parent().find(".loader");

      loading.removeClass("hidden");

      $.ajax({
        url: gsmArr.homeUrl + "/wp-ajax/general/logout/",
        processData: false,
        contentType: false,
        dataType: "json",
        mode: "no-cors",
        type: "GET",
        success: function (response) {
          if (response.success) {
            _this.toast.create(response.message, "success", 3000);
            location.reload();
          }
        },
        error: function (xhr, status, error) {
          _this.toast.create(
            xhr.responseJSON?.message ||
              "خطای ناشناخته لطفاً مجدداً سعی نمایید",
            "error",
            3000
          );
        },
        complete: function () {
          loading.addClass("hidden");
        },
      });
    }

    gridImageSizeHandler() {
      $(".gsm-image-grid").each(function (e) {
        if ($(this).hasClass("full-width") || $(this).hasClass("full-screen")) {
          const windowWidth = $(window).width();
          let containerWidth = $(".container").width();
          const contentWidth = $(".post-content").width();
          let extendOffset = 0;
          if (containerWidth > contentWidth) {
            extendOffset = (containerWidth - contentWidth) / 2;
          } else {
            extendOffset = (windowWidth - contentWidth) / 2;
            containerWidth = windowWidth;
          }
          if ($(this).hasClass("full-screen")) {
            extendOffset = (windowWidth - contentWidth) / 2;
            containerWidth = windowWidth;
          }
          $(this).css({
            width: containerWidth + "px",
            right: "-" + extendOffset + "px",
            position: "relative",
          });
        }
      });
    }

    p2e = (s) => s.replace(/[۰-۹]/g, (d) => String("۰۱۲۳۴۵۶۷۸۹".indexOf(d)));

    a2e = (s) => s.replace(/[٠-٩]/g, (d) => String("٠١٢٣٤٥٦٧٨٩".indexOf(d)));
  }

  const global = new Global();

  $.gsmSelectHandler = function (modifySelect = null) {
    const getSelector = () =>
      modifySelect == null ? $(".gsm-select") : modifySelect;

    const processField = ($self) => {
      const field = $self.find("select");
      const fieldOptions = field.find("option");
      const fieldClass = field.attr("class") || "";
      const listClass = field.attr("list-class") || "";
      const searchClass = field.attr("search-class") || "";
      const fieldId = field.attr("id");
      const arrowIcon = getArrowIcon($self);
      const fieldHeight = getFieldHeight($self, field);
      const searchPlaceholder = getSearchPlaceholder(field);
      const multipleClass = getMultipleClass(field);

      field.addClass("hidden");
      $self.addClass("rendered").removeClass("not-rendered");

      insertElements(
        field,
        $self,
        arrowIcon,
        fieldHeight,
        searchPlaceholder,
        multipleClass,
        listClass,
        searchClass,
        fieldClass,
        fieldId
      );

      const list = $self.find(".gsm-select-list");
      fieldOptions.each(function () {
        const optionContent = $(this).attr("html") || $(this).text();
        const isDisabled = $(this).attr("disabled");
        const optionValue = $(this).val();
        const optionClass = $(this).attr("class");
        createListItem(
          field,
          list,
          optionContent,
          optionValue,
          isDisabled,
          optionClass
        );
      });

      const dropdown = $self.find(".gsm-select-dropdown");
      const search = $self.find(".gsm-select-search");
      const searchContainer = $self.find(".gsm-select-search-container");
      const option = $self.find(".gsm-select-option");
      const optionText = $self.find(".gsm-select-text");

      // add position top to list
      calculateListTop(list, field, dropdown, searchContainer);

      // filter based on search for not ajax list
      if (field.is("[search]") && !field.is("[ajax-request]")) {
        search
          .on("change keyup paste", function (e) {
            handleSearch($(this), list);
          })
          .change();
        calculateListTop(list, field, dropdown, searchContainer);
      }

      // action for default selected option
      if (field.find("option:selected").length) {
        const optionContent =
          field.find("option:selected").attr("html") ||
          field.find("option:selected").text();
        dropdown.find("span").html(optionContent).addClass("");
        list
          .find(
            `.gsm-select-option[gsm-value="${field
              .find("option:selected")
              .val()}"]`
          )
          .addClass("bg-light-blue selected");
      }

      // action for simple select option
      simpleSelectHandler(
        $self,
        option,
        fieldOptions,
        field,
        dropdown,
        list,
        searchContainer
      );

      // simple selection dropdown Click handler
      if (!field.is("[ajax-request]")) {
        dropdownClickHandler(
          $self,
          field,
          dropdown,
          list,
          searchContainer,
          fieldId
        );
      }
    };

    const getArrowIcon = ($self) => {
      console.log($self.hasClass("no-arrow"));
      if ($self.hasClass("no-arrow")) {
        return $self.attr("icon")
          ? `<i class="${$self.attr("icon")} transition-all"></i>`
          : ``;
      }
      return `<i class="gsmicon-arrow-bottom absolute left-3 ${$self.attr(
        "icon"
      )} transition-all"></i>`;
    };

    const getFieldHeight = ($self) => {
      return $self.attr("height") ? parseInt($self.attr("height")) : 0;
    };

    const getSearchPlaceholder = (field) => {
      return field.is("[search]") ? field.attr("search-placeholder") || "" : "";
    };

    const getMultipleClass = (field) => {
      if (field.is("[multiple]")) {
        return field.is("[search]")
          ? "flex-wrap h-full justify-start"
          : "flex-wrap justify-start ";
      }
      return "";
    };

    const insertElements = (
      field,
      $self,
      arrowIcon,
      fieldHeight,
      searchPlaceholder,
      multipleClass,
      listClass,
      searchClass,
      fieldClass,
      fieldId
    ) => {
      if (field.is("[search]")) {
        field.is("[ajax-request]")
          ? field.after(`
        <div class="gsm-select-dropdown flex  items-center relative ${multipleClass} ${fieldClass} ">
          <input type="text" placeholder="${searchPlaceholder}" class="gsm-select-search w-full pl-10 h-full outline-none">
        </div>
        <ul class="gsm-select-list ${fieldId} ${listClass} bg-white w-full rounded-xl absolute right-0 opacity-0 invisible overflow-y-auto h-fit max-h-72  transition-all z-10  "></ul>
        `)
          : field.after(`
        <div class="gsm-select-dropdown flex  items-center relative  ${multipleClass} ${fieldClass} "><span></span>${arrowIcon}
        </div>
        <div class="gsm-select-search-container ${fieldClass} -mt-1 flex justify-center items-center  border-t-0 opacity-0 invisible rounded-t-none overflow-hidden">
          <input type="text" placeholder="${searchPlaceholder}" class="gsm-select-search !border-none w-full pl-10 h-full outline-none ${searchClass}">
          <svg class="hidden shrink-0 absolute left-2 w-4 h-4">
            <use href="#loading-spinner"></use>
          </svg>
        </div>
        <ul class="gsm-select-list  ${fieldId} ${listClass} bg-white w-full rounded-md absolute right-0 opacity-0 invisible overflow-y-auto max-h-72 transition-all z-10"></ul>
        `);
      } else {
        field.after(`
        <div class="gsm-select-dropdown flex items-center ${multipleClass} ${fieldClass}"><span></span>${arrowIcon}
        </div>
        <ul class="gsm-select-list ${fieldId} ${listClass} bg-white w-full absolute right-0 opacity-0 invisible overflow-y-auto max-h-72 transition-all z-10 "></ul>
        `);
      }
    };

    const createListItem = (
      field,
      list,
      content,
      value,
      isDisabled,
      optionClass
    ) => {
      const listItem = $("<li>", {
        class: `gsm-select-option gsm-select-li ${optionClass || ""}`,
        "gsm-value": value,
        html: content,
      });

      if (isDisabled) {
        listItem.addClass(
          "disabled p-6 hover:bg-midnight-50 hover:text-blue-main"
        );
      } else {
        listItem.click(function (e) {
          field.find(`option[value="${value}"]`).prop("selected", true);
          field.trigger("change");
        });
      }
      list.append(listItem);
    };

    const calculateListTop = (list, field, dropdown, searchContainer) => {
      let position;
      list.css("top", "calc(100% + 5px)");
    };

    const dropdownClickHandler = (
      $self,
      field,
      dropdown,
      list,
      searchContainer,
      fieldId
    ) => {
      $self.on("click", ".gsm-select-dropdown", function (e) {
        if ($(this).parents(".select-container") != undefined) {
          $(this)
            .parents(".select-container")
            .find(".gsm-select-search-container")
            .toggleClass("opacity-100 visible opacity-0 invisible open");
          $(this)
            .parents(".select-container")
            .find(".gsm-select-list")
            .each(function (e) {
              if ($(this).hasClass("open") && !$(this).hasClass(fieldId)) {
                $(this)
                  .toggleClass("opacity-100 visible opacity-0 invisible open")
                  .scrollTop(0);
                if (!$(this).parents(".gsm-select").hasClass("no-arrow")) {
                  $(this)
                    .parents(".gsm-select")
                    .find("i")
                    .removeClass("rotate-180");
                }
              }
            });
        }

        if (!field.attr("disabled")) {
          searchContainer.toggleClass(
            "opacity-100 visible opacity-0 invisible open"
          );
          list
            .toggleClass("opacity-100 visible opacity-0 invisible open")
            .scrollTop(0);
          if (!$self.hasClass("no-arrow")) {
            $(this).find("i").toggleClass("rotate-180");
          }
        }

        calculateListTop(list, field, dropdown, searchContainer);
      });
    };

    const simpleSelectHandler = (
      $self,
      option,
      fieldOptions,
      field,
      dropdown,
      list,
      searchContainer
    ) => {
      $self.on("click", ".gsm-select-option", function (e) {
        if (!$(this).hasClass("disabled")) {
          const optionContent = $(this).html();
          option.removeClass("bg-light-blue");
          $(this).addClass("bg-light-blue selected");
          fieldOptions.prop("selected", false);
          field.find("option").removeAttr("selected");
          field
            .find(`option[value="${$(this).attr("gsm-value")}"]`)
            .prop("selected", true);

          dropdown.find("span").html(optionContent).addClass("has-value");
        }

        if (field.is("[search]")) {
          dropdown.toggleClass("open rounded-b-none border-b-0");
        }

        if ($(this).attr("icon") == undefined) {
          dropdown.find("i").toggleClass("rotate-180");
        }
        list
          .scrollTop(0)
          .toggleClass("opacity-100 visible opacity-0 invisible open");
        searchContainer.toggleClass(
          "opacity-100 visible opacity-0 invisible open"
        );

        calculateListTop(list, field, dropdown, searchContainer);
      });
    };

    // Call the processField function for each selector
    getSelector().each(function () {
      processField($(this));
    });
  };

  $.gsmSelectHandler();
})(jQuery);
