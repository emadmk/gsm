(function ($) {
  "use strict";

  class Reviews {
    constructor() {
      const _this = this;
      this.toast = new Toast();

      // view counter
      $(document).ready(function () {
        _this.viewCount();
      });

      if (typeof $.gsmToggleTab !== "undefined") {
        $.gsmToggleTab(".faq-section");
      }

      $(document).on("click", ".table-of-content .head-section", function (e) {
        $(this).parent().find(".content-section").slideToggle(500);
        $(this).find("i.arrow").toggleClass("rotate-180");
      });

      _this.imageSizeHandler();
      $(window).resize(function () {
        _this.imageSizeHandler();
      });

      if (typeof GLightbox !== "undefined") {
        const gLightbox = GLightbox({
          loop: true,
          touchNavigation: true,
          closeOnOutsideClick: true,
        });
      }
    }

    viewCount() {
      const arg = {
        id: $(".reviews-container").data("reviews-id"),
      };
      const formData = new FormData();
      formData.append("data", JSON.stringify(arg));
      $.ajax({
        url: gsmArr.homeUrl + "/wp-ajax/reviews/view",
        data: formData,
        processData: false,
        contentType: false,
        dataType: "json",
        mode: "no-cors",
        type: "POST",
        success: function (response) {
          if (response.success) {
          } else {
          }
        },
        error: function (xhr, status, error) {
          _this.toast.create(
            xhr.responseJSON?.message ||
              "خطای ناشناخته لطفاً مجدداً سعی نمایید",
            "error",
            3000
          );
        },
      });
    }

    imageSizeHandler() {
      $(".review-content img").each(function (e) {
        if (!$(this).hasClass("grid-image-item")) {
          const windowWidth = $(window).width();
          let containerWidth = $(".container").width();
          const contentWidth = $(".review-content").width();
          let extendOffset = 0;
          if (containerWidth > contentWidth) {
            extendOffset = (containerWidth - contentWidth) / 2;
          } else {
            extendOffset = (windowWidth - contentWidth) / 2;
            containerWidth = windowWidth;
          }
          if ($(this).hasClass("full-screen")) {
            extendOffset = (windowWidth - contentWidth) / 2;
            containerWidth = windowWidth;
          }
          $(this).css({
            width: containerWidth + "px",
            right: "-" + extendOffset + "px",
            position: "relative",
          });
          $(this)
            .parentsUntil(".post-content")
            .css({
              width: containerWidth + "px",
            });
          // Remove 'overflow-hidden' from up to 4 ancestor levels if present
          var $overflowHiddenParents = $(this)
          .parentsUntil(".post-content").filter(".overflow-hidden").removeClass("overflow-hidden");
        }
      });
    }
  }

  const reviews = new Reviews();
})(jQuery);
