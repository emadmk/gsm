(function ($) {
  "use strict";

  class Home {
    constructor() {
      const _this = this;
      this.toast = new Toast();
      this.playerList = [];
      this.fetchedStory = false;
      this.fetchingStory = false;
      this.mainStoryList = null;

      const storyList = new Splide(".story-slider", {
        direction: "rtl",
        autoWidth: true,
        arrows: false,
        pagination: false,
        // type: "loop",
        perPage: 1,
        gap: 12,
        breakpoints: {
          1024: {
            gap: 34,
          },
          768: {
            gap: 12,
          },
          340: {
            gap: 12,
          },
        },
        mediaQuery: "min",
      });
      storyList.mount();
      $(".story-item").each(function (e) {
        _this.playerList.push({});
      });

      $(document).on("click", ".store-item", function (e) {
        const slider = $(this).data("slide");
        if (_this.fetchedStory) {
          _this.mainStoryList.go(slider);
        } else {
          _this.getStory();
        }
        $(".story-modal").toggleClass("modal-close modal-open");
      });

      $(document).ready(function () {
        setTimeout(() => {
          if(!_this.fetchedStory) _this.getStory();
        }, 4000);
      });

      $(document).on("click", ".close-story-btn", function (e) {
        $(".story-modal").toggleClass("modal-close modal-open");
      });

      const breakLine = new Splide(".break-line-slider", {
        type: "loop",
        direction: "rtl",
        autoWidth: true,
        arrows: false,
        autoplay: true,
        interval: 5000,
        pauseOnHover: true,
        easing: "linear",
        speed: 5000,
        pagination: false,
        // drag:'free',
        // perPage: 4,
        gap: 8,
        // mediaQuery: "min",
      });
      breakLine.mount();

      const brands = new Splide(".brands-slider", {
        type: "loop",
        direction: "rtl",
        autoWidth: true,
        arrows: false,
        pagination: false,
        drag: "free",
        gap: 8,
        breakpoints: {
          768: {
            gap: 24,
          },
        },
        mediaQuery: "min",
      });
      brands.mount();
    }

    mainStoryAction() {
      const _this = this;
      _this.mainStoryList = new Splide(".main-story-slider", {
        direction: "rtl",
        arrows: true,
        autoplay: true,
        interval: 3000,
        pagination: true,
        type: "loop",
        perPage: 1,
        gap: 12,
      });
      _this.mainStoryList.mount();

      // inter video
      if ($(".story-video-item").length) {
        $(".story-video-item").each(function (e) {
          const item = $(this).data("item");
          const player = new Plyr($(this).get(0), {
            controls: [
              "play-large",
              "play",
              "progress",
              "current-time",
              "mute",
              "volume",
              "settings",
              "airplay",
              "fullscreen",
            ],
            autoplay: true,
            settings: ["quality", "speed"],
            fullscreen: {
              enabled: true,
            },
            ration: "9:16",
          });
          player.on("ended", (ended) => {
            _this.mainStoryList.go(">");
          });
          _this.playerList[item] = player;
        });
        _this.mainStoryList.on("moved", function (newIndex, prevIndex) {
          if (_this.playerList[newIndex] != undefined) {
            _this.playerList[newIndex].play();
          }
        });
      }

      $(".story-product-slider").each(function (e) {
        const productSlider = new Splide($(this).get(0), {
          direction: "rtl",
          autoWidth: true,
          arrows: false,
          pagination: false,
          // type: "loop",
          gap: 8,
        });
        productSlider.mount();
      });
    }

    getStory() {
      const _this = this;
      if (_this.fetchingStory) return;
      _this.fetchingStory = true;
      const arg = {
        pageId: $(".page-view-count").data("id"),
      };
      const formData = new FormData();
      formData.append("data", JSON.stringify(arg));
      $.ajax({
        url: gsmArr.homeUrl + "/wp-ajax/home/story",
        data: formData,
        processData: false,
        contentType: false,
        dataType: "json",
        mode: "no-cors",
        type: "POST",
        success: function (response) {
          if (response.success) {
            $(".story-modal").html(response.content);
            _this.mainStoryAction();
            _this.fetchedStory = true;
          } else {
            _this.toast.create(
              response.message || "خطا د در دریافت اطلاعات از سرور",
              "error",
              4000
            );
          }
        },
        error: function (xhr, status, error) {
          _this.toast.create(
            xhr.responseJSON?.message ||
              "خطای ناشناخته لطفاً مجدداً سعی نمایید",
            "error",
            3000
          );
        },
        complete: function () {
          _this.fetchingStory = false;
        },
      });
    }
  }

  let home = new Home();
})(jQuery);
