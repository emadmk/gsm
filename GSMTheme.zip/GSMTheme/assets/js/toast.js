class Toast {
  constructor() {
    this.container = document.getElementById("toast-container");
    if (!this.container) {
      this.container = document.createElement("div");
      this.container.id = "toast-container";
      document.body.appendChild(this.container);
    }
  }

  create(message, type = "success", duration = 3000) {
    const toast = document.createElement("div");
    toast.classList.add("toast", type);
    toast.innerHTML = message;

    const progressBar = document.createElement("div");
    progressBar.classList.add("progress");
    toast.appendChild(progressBar);

    const closeButton = document.createElement("button");
    closeButton.classList.add("close-btn");
    closeButton.innerHTML = "&times;";
    closeButton.onclick = () => this.removeToast(toast);
    toast.appendChild(closeButton);

    this.container.appendChild(toast);

    setTimeout(() => {
      toast.classList.add("show");
      progressBar.style.transitionDuration = `${duration}ms`;
      progressBar.style.transform = "scaleX(1)";
    }, 100);

    // Start the auto-hide timeout
    let timeoutId = setTimeout(() => {
      this.removeToast(toast);
    }, duration);

    // Store the timeout ID and remaining duration in the toast element
    toast.dataset.timeoutId = timeoutId;
    toast.dataset.remaining = duration;

    // Pause on hover or touch
    const pauseHide = () => {
      clearTimeout(toast.dataset.timeoutId);
      const elapsed = Date.now() - toast.dataset.startTime;
      toast.dataset.remaining -= elapsed;
    };

    const resumeHide = () => {
      toast.dataset.startTime = Date.now();
      timeoutId = setTimeout(() => {
        this.removeToast(toast);
      }, toast.dataset.remaining);
      toast.dataset.timeoutId = timeoutId;
    };

    // Attach event listeners to pause and resume hiding
    toast.addEventListener("mouseenter", pauseHide);
    toast.addEventListener("mouseleave", resumeHide);
    toast.addEventListener("touchstart", pauseHide);
    toast.addEventListener("touchend", resumeHide);

    // Start time tracking
    toast.dataset.startTime = Date.now();
  }

  removeToast(toast) {
    clearTimeout(toast.dataset.timeoutId);

    toast.classList.remove("show");
    toast.classList.add("hide");

    setTimeout(() => {
      toast.remove();
    }, 500);
  }
}


document.addEventListener('DOMContentLoaded', () => {
  const toast = new Toast();

  // Function to extract WooCommerce notices and display as Toasts
  function showWooCommerceNotices() {
    const noticeSelectors = [
      '.woocommerce-notices-wrapper',
      '.woocommerce-NoticeGroup',
      '.woocommerce-NoticeGroup-checkout'
    ];
    
    noticeSelectors.forEach(selector => {
      const noticesWrapper = document.querySelector(selector);
      
      if (noticesWrapper) {
        const notices = noticesWrapper.querySelectorAll('.woocommerce-message, .woocommerce-error, .woocommerce-info');
        
        notices.forEach(notice => {
          const message = notice.textContent.trim();
          const type = notice.classList.contains('woocommerce-error') ? 'error' : 
                       notice.classList.contains('woocommerce-info') ? 'info' : 'success';
          
          toast.create(message, type);
          
          // Optionally, clear the WooCommerce notice from the DOM after displaying it in Toast
          notice.remove();
        });
      }
    });
  }

  // Observe changes in WooCommerce notice elements
  const observer = new MutationObserver(showWooCommerceNotices);
  const targets = document.querySelectorAll('.checkout, .woocommerce-notices-wrapper, .woocommerce-NoticeGroup, .woocommerce-NoticeGroup-checkout');
  
  targets.forEach(target => {
    observer.observe(target, { childList: true });
  });
});

