/**
 * http://archive.tinymce.com/wiki.php/Tutorials:Creating_custom_dialogs
 */
(function () {

    tinymce.create('tinymce.plugins.gsm_highlighter', {

        init: function (editor, url) {
            editor.addButton('gsm_highlighter', {
                title: 'هایلایتر',
                image: url.replace("js/admin", "img/editor-highlighter.svg"),
                onclick: function () {
                    var selectedText = editor.selection.getContent({format: 'text'});
                    if (selectedText.length > 0) {
                        editor.selection.setContent('[gsm_highlighter]' + selectedText + '[/gsm_highlighter]');
                    } else {
                        // editor.selection.setContent('[gsm_highlighter]متن هایلایت شده[/gsm_highlighter]');
                    }
                }
            });
        },
        setup: function (ed) {
            ed.onSubmit.add(function (ed, e) {
                console.debug('Form submit:' + e.target);
            });
        },
        getInfo: function () {
            return {
                longname: 'GSM highlighter Shortcode',
                author: 'Ehsan Ravanbakhsh',
                authorurl: '',
                infourl: 'https://wordpress.org/plugins',
                version: "1"
            };
        }
    });

    tinymce.PluginManager.add('gsm_highlighter', tinymce.plugins.gsm_highlighter);

})();