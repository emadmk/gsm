(function ($) {
  "use strict";

  class AdminPost {
    constructor() {
      const _this = this;
      this.isSearching = false;

      // view counter
      $(document).ready(function () {
        // 1. Wrap the select
        $(".acf-product-input select").each(function () {
          if (!$(this).parent().hasClass("acf-product-select-container")) {
            $(this).wrap(
              '<div class="acf-product-select-container" style="position:relative;display:inline-block;width:100%;"></div>'
            );
          }
        });

        // 2. Add the search input always visible below the select
        $(".acf-product-select-container").each(function () {
          if ($(this).find(".acf-product-search").length === 0) {
            $(this).append(
              '<input type="text" class="acf-product-search" placeholder="جستجوی محصول..." style="margin-top:4px;width:100%;box-sizing:border-box;">'
            );
          }
          if ($(this).find(".acf-product-loader").length === 0) {
            $(this).append('<span class="acf-product-loader spinner"></span>');
          }
        });

        // 3. Handle search input keyup
        let productSearchDebounce;
        $(document).on("keyup", ".acf-product-search", function (e) {
          $(this).each(function (e) {
            let search = $(this).val();
            const input = $(this).parent(".acf-product-select-container");
            clearTimeout(productSearchDebounce);
            productSearchDebounce = setTimeout(() => {
              _this.getProducts(search, input);
            }, 800);
          });
        });
      });
    }
    getProducts(search, input) {
      const _this = this;
      if (this.isSearching) return;
      this.isSearching = true;
      const loader = input.find(".acf-product-loader");
      loader.addClass("is-active");

      // Store the currently selected value and text
      let $select = input.find("select");
      console.log($select);
      let currentSelectedValue = $select.val();
      let currentSelectedText = "";

      // Get the text of currently selected option before clearing
      if (currentSelectedValue) {
        currentSelectedText = $select
          .find('option[value="' + currentSelectedValue + '"]')
          .text();
      }

      const arg = {
        search: search || "",
      };
      const formData = new FormData();
      formData.append("data", JSON.stringify(arg));
      $.ajax({
        url: gsmArr.homeUrl + "/wp-ajax/acf/product",
        data: formData,
        processData: false,
        contentType: false,
        dataType: "json",
        mode: "no-cors",
        type: "POST",
        success: function (response) {
          if (
            response.success &&
            response.content &&
            response.content.results
          ) {
            // Populate the select with new options
            $select.empty();

            // Check if current selected value exists in new results
            let currentValueExists = false;

            response.content.results.forEach(function (product) {
              $select.append(
                '<option value="' +
                  product.id +
                  '">' +
                  product.text +
                  "</option>"
              );
              // Check if this option matches the previously selected value
              if (product.id == currentSelectedValue) {
                currentValueExists = true;
              }
            });

            // If current selected value is not in new results, add it back at the top
            if (
              currentSelectedValue &&
              !currentValueExists &&
              currentSelectedText
            ) {
              $select.prepend(
                '<option value="' +
                  currentSelectedValue +
                  '">' +
                  currentSelectedText +
                  "</option>"
              );
            }

            // Restore the selected value
            if (currentSelectedValue) {
              $select.val(currentSelectedValue);
            }
          } else {
            // No results found or invalid response - preserve current selection
            if (currentSelectedValue && currentSelectedText) {
              $select.empty();
              $select.append(
                '<option value="' +
                  currentSelectedValue +
                  '">' +
                  currentSelectedText +
                  "</option>"
              );
              $select.val(currentSelectedValue);
            }
          }
        },
        error: function (xhr, status, error) {},
        complete: function (e) {
          loader.removeClass("is-active");
          _this.isSearching = false;
        },
      });
    }
  }

  const adminPost = new AdminPost();
})(jQuery);
