/**
 * http://archive.tinymce.com/wiki.php/Tutorials:Creating_custom_dialogs
 */
(function () {

    tinymce.create('tinymce.plugins.gsm_gallery', {

        init: function (editor, url) {
            console.log(url);
            editor.addButton('gsm_gallery', {
                title: 'گالری',
                onclick: function () {
                    editor.windowManager.open({
                        title   : 'گالری',
                        url     : url.replace("assets/js/admin", "includes/admin/editor-gallery.php?v=1"),
                        width   : "690px",
                        height  : "485px"
                    });
                },
                image: url.replace("js/admin", "img/editor-gallery.svg")
            });
        },
        setup: function (ed) {
            ed.onSubmit.add(function (ed, e) {
                console.debug('Form submit:' + e.target);
            });
        },
        getInfo: function () {
            return {
                longname: 'GSM Gallery Shortcode',
                author: 'Ehsan Ravanbakhsh',
                authorurl: '',
                infourl: 'https://wordpress.org/plugins',
                version: "1"
            };
        }
    });

    tinymce.PluginManager.add('gsm_gallery', tinymce.plugins.gsm_gallery);

})();