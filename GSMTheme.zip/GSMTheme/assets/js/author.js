(function ($) {
  "use strict";

  class Author {
    constructor() {
      const _this = this;
      this.toast = new Toast();

      $.gsmScrollTab('.author-section',false);
      $('.author-section-tab.first-tab').click();

      $(document).on("click", ".page-item", function (e) {
        _this.updateList($(this).data("page"));
      });
    }

    updateList(page = 1) {
        const _this = this;
        if (_this.isSearching) return;
        _this.generateLoading(".list-container");
        $(".pagination").addClass("skeleton");
        _this.isSearching = true;
        const arg = {
          page,
          author: $(".author-container").data("author"),
        };
        const formData = new FormData();
        formData.append("data", JSON.stringify(arg));
        $.ajax({
          url: gsmArr.homeUrl + "/wp-ajax/author/filter",
          data: formData,
          processData: false,
          contentType: false,
          dataType: "json",
          mode: "no-cors",
          type: "POST",
          success: function (response) {
            if (response.success) {
                $(".list-container").html(response.content.list);
                $(".pagination").html(response.content.pagination);
    
            } else {
              _this.toast.create(
                response.message || "خطا د در دریافت اطلاعات از سرور",
                "error",
                4000
              );
              $(".list-container").html("");
              $(".pagination").html("");
            }
            $(".pagination").removeClass("skeleton");
            // window.dispatchEvent(
            //   new CustomEvent("queryLoaded", {
            //     detail: { container: $(".products-list").get(0) },
            //   })
            // );
          },
          error: function (xhr, status, error) {
            $(".pagination").removeClass("skeleton");
            $(".list-container").html("");
            _this.toast.create(
              xhr.responseJSON?.message ||
                "خطای ناشناخته لطفاً مجدداً سعی نمایید",
              "error",
              3000
            );
          },
          complete: function () {
            _this.isSearching = false;
            _this.addNewUrl(arg);
          },
        });
      }
  
      generateLoading(selector, number = 12) {
        let skeleton = "";
        for (let i = 0; i < number; i++) {
          skeleton += `
          <div class="w-full border border-gray-200 rounded-2xl p-4 bg-white flex gap-2 md:gap-4">
            <div class="size-24 md:size-[7.5rem] shrink-0 rounded-lg skeleton"></div>
            <div class="grow flex flex-col">
              <div class="h-5 mt-2 rounded-full skeleton w-3/4"></div>
                <div class="flex items-center justify-between md:justify-start gap-2 mt-auto">
                  <div class="flex-center gap-1 w-1/3">
                    <div class="h-6 rounded-[0.25rem] skeleton w-14 shrink-0"></div>
                    <div class="grow h-2 skeleton rounded-full"></div> 
                  </div>
                </div>
            </div>
          </div>
          `;
        }
        $(selector).html(skeleton);
      }
  
      addNewUrl({ page, brand }) {
        const params = {};
        if (page > 1) {
          params.pg = page;
        }
        if (brand) {
          params.brand = brand;
        }
  
        let newUrl;
        if (Object.keys(params).length) {
          const baseURL = window.location.href.split("?")[0];
          const queryString = new URLSearchParams(params).toString();
  
          newUrl = `${baseURL}?${queryString}`;
        } else {
          newUrl = window.location.href.split("?")[0];
        }
        if (history.pushState) {
          history.pushState(null, null, newUrl);
        } else {
          window.location.href = newUrl;
        }
      }
  }
  const author = new Author();
})(jQuery);
