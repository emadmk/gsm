<?php

namespace GSM;

use GSM\templates\category\Category;
get_header();
    $category = new Category();
    $category->displayContent();

get_footer();