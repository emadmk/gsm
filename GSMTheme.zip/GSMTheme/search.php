<?php 
use GSM\templates\search\Search;
get_header();
$search = new Search();
$search->displayContent();
get_footer();