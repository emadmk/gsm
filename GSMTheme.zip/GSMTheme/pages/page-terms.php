<?php
namespace GSM\pages;
use GSM\templates\terms\Terms;
// Template Name: Terms Page



get_header();
$termsTemplate = new Terms();
$termsTemplate->displayContent();
get_footer();
?>