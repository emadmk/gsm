<?php
namespace GSM\pages;
use GSM\templates\articles\ArticlesList;
// Template Name: Article List Page



get_header();
$articleListTemplate = new ArticlesList();
$articleListTemplate->displayContent();
get_footer();
?>