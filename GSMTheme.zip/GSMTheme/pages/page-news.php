<?php
namespace GSM\pages;
use GSM\templates\news\NewsList;
// Template Name: News List Page



get_header();
$newsListTemplate = new NewsList();
$newsListTemplate->displayContent();
get_footer();
?>