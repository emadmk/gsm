<?php
namespace GSM\pages;
use GSM\templates\contactUs\ContactUs;
// Template Name: Contact Us Page



get_header();
$contactUsTemplate = new ContactUs();
$contactUsTemplate->displayContent();
get_footer();
?>