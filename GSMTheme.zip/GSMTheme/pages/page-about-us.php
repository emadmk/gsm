<?php
namespace GSM\pages;
use GSM\templates\aboutUs\AboutUs;
// Template Name: About Us Page



get_header();
$aboutUsTemplate = new AboutUs();
$aboutUsTemplate->displayContent();
get_footer();
?>