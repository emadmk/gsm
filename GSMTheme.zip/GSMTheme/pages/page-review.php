<?php
namespace GSM\pages;
use GSM\templates\reviews\ReviewsList;
// Template Name: Review List Page



get_header();
$reviewListTemplate = new ReviewsList();
$reviewListTemplate->displayContent();
get_footer();
?>