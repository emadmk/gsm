<?php

use GSM\templates\articles\Articles;
use GSM\templates\news\News;
use GSM\templates\reviews\Reviews;

get_header();
$postType = get_post_type();
if (get_post_type() == 'news') {
    $news = new News();
    $news->displayContent();
} elseif (get_post_type() == 'article') {
    $articles = new Articles();
    $articles->displayContent();
} elseif (get_post_type() == 'review') {
    $reviews = new Reviews();
    $reviews->displayContent();
} else {
    while (have_posts()) :
        the_post();
    endwhile;
}
?>
<?php get_footer('',['background'=>get_post_type() == 'review'?'bg-white':'bg-gray-50']); ?>