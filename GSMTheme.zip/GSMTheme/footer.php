<?php
use GSM\templates\layouts\footer\Footer;
if (is_array($args) && isset($args)){
    $type =  $args['type']??'normal';
    $background =  $args['background']??'bg-gray-50';
}
$footer = new Footer($type,$background);

$footer->displayContent();