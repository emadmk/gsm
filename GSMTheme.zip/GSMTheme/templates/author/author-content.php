<?php

namespace GSM\templates\author;

use WP_Query;

$_this = $args['_this'];
wp_enqueue_script('gsm-scrollTab', GSM_URL . '/assets/js/scroll-tab.js', ['jquery'], GSM_VERSION, true);
wp_enqueue_script('gsm-author', GSM_URL . '/assets/js/author.js', ['jquery', 'gsm-scrollTab'], GSM_VERSION, true);

$author = get_user_by('slug', get_query_var('author_name'));
$userLabel = !empty(get_field('author-label', 'user_' . $author->ID)) ? get_field('author-label', 'user_' . $author->ID) : 'نویسنده جی اس ام';
$shortDescription = get_field('short-description', 'user_' . $author->ID);
$aboutMe = get_field('about-me', 'user_' . $author->ID);
$activityDuration = get_field('activity-duration', 'user_' . $author->ID);
$viewCount = get_user_meta($author->ID, 'view_count',true) ?: 0;
$likeCount = get_user_meta($author->ID, 'like_count',true) ?: 0;
$commentCount = get_user_meta($author->ID, 'comment_count',true) ?: 0;
$postCount = get_user_meta($author->ID, 'post_count',true) ?: 0;
$wordCount = get_user_meta($author->ID, 'word_count',true) ?: 0;
$userImageId = get_field('profile-image', 'user_' . $author->ID);
if (!empty($userImageId)) {
    $userImage = wp_get_attachment_image($userImageId, 'thumbnail', false,  ['class' => 'size-16 md: rounded-full object-cover shrink-0']);
} else {
    $userAvatar = get_avatar_url($author->ID);
    $userImage = '<img class="size-16 md:size-36 rounded-full object-cover shrink-0" src="' . $userAvatar . '">';
}
$page = (get_query_var('paged')) ? get_query_var('paged') : 1;
$args = array(
    'post_type'         => ['news', 'article', 'review'],
    'order'             => 'DESC',
    'post_status'       => 'publish',
    'posts_per_page'    => 12,
    'paged'             => $page,
    'author'            => $author->ID,
);
$posts = new WP_Query($args);

?>
<div class="author-container relative bg-gray-50 md:py-6 grow" data-author="<?= $author->ID ?>">
    <main class="container xl:max-w-screen-xl lg:px-10  md:bg-white p-4 md:p-6 rounded-2xl grid grid-cols-1 md:grid-cols-[1fr_1.5fr] gap-6 md:gap-8">
        <article class="">
            <div class="md:sticky top-0 h-fit">
                <div class="flex items-center gap-4 md:gap-6">
                    <?= $userImage ?>
                    <div class="space-y-2 md:spacey-4">
                        <h1 class="h4"><?= $author->display_name ?></h1>
                        <div class="bg-primary-500/[0.08] text-primary-700 overline-font py-1 px-3 md:px-4 rounded-[0.25rem]"><?= $userLabel ?></div>
                    </div>
                </div>
                <p class="text-justify mt-10 md:mt-6"><?= $shortDescription ?></p>
                <ul class="grid grid-cols-2 md:grid-cols-3 gap-3 md:gap-x-5 md:gap-y-4 body-sm mt-6">
                    <li class="py-4 md:py-6 bg-primary-500/[0.08] border border-primary-500/[0.08] flex center flex-col px-2 md:px-4 rounded-lg">
                        <p class="text-center"><?= __('مدت زمان فعالیت', 'gsm') ?></p>
                        <span class="subtitle-lg text-center"><?= $activityDuration ?></span>
                    </li>
                    <li class="py-4 md:py-6 bg-primary-500/[0.08] border border-primary-500/[0.08] flex center flex-col px-2 md:px-4 rounded-lg">
                        <p class="text-center"><?= __('تعداد بازدید کاربران', 'gsm') ?></p>
                        <span class="subtitle-lg text-center"><?= $viewCount ?></span>
                    </li>
                    <li class="py-4 md:py-6 bg-primary-500/[0.08] border border-primary-500/[0.08] flex center flex-col px-2 md:px-4 rounded-lg">
                        <p class="text-center"><?= __('تعداد لایک', 'gsm') ?></p>
                        <span class="subtitle-lg text-center"><?= $likeCount ?></span>
                    </li>
                    <li class="py-4 md:py-6 bg-primary-500/[0.08] border border-primary-500/[0.08] flex center flex-col px-2 md:px-4 rounded-lg">
                        <p class="text-center"><?= __('تعداد کامنت', 'gsm') ?></p>
                        <span class="subtitle-lg text-center"><?= $commentCount ?></span>
                    </li>
                    <li class="py-4 md:py-6 bg-primary-500/[0.08] border border-primary-500/[0.08] flex center flex-col px-2 md:px-4 rounded-lg">
                        <p class="text-center"><?= __('مطالب نوشته شده', 'gsm') ?></p>
                        <span class="subtitle-lg text-center"><?= $postCount ?></span>
                    </li>
                    <li class="py-4 md:py-6 bg-primary-500/[0.08] border border-primary-500/[0.08] flex center flex-col px-2 md:px-4 rounded-lg">
                        <p class="text-center"><?= __('کلمات نوشته شده', 'gsm') ?></p>
                        <span class="subtitle-lg text-center"><?= number_format($wordCount) ?></span>
                    </li>
                </ul>
            </div>
        </article>
        <div class="">
            <div class="gsm-scroll-tab author-section body-sm text-gray-500 border-b border-gray-100 bg-white px-4 md:px-0">
                <div class="author-section-tab-container relative flex py-3 w-full md:w-fit *:cursor-pointer *:transition-all">
                    <div href="#post-list-tab" class="author-section-tab first-tab w-full md:w-36 flex-center" data-tab="post-list"><?= __('مطالب', 'gsm') ?></div>
                    <div href="#about-me-tab" class="author-section-tab w-full md:w-36 flex-center" data-tab="about-me"><?= __('درباره من', 'gsm') ?></div>
                    <div class="line h-[2px] rounded-full absolute bg-primary-500 -bottom-[2px] duration-500"></div>
                </div>
            </div>
            <div class="tab-content-container mt-2 md:mt-8 bg-white">
                <section id="post-list-tab" class="post-list-content author-section-content ">
                    <div class="list-container space-y-2 md:space-y-4">
                        <?= $_this->displayList($posts) ?>
                    </div>
                    <nav class="pagination mt-8" aria-label="Page navigation">
                        <?= $_this->displayPagination($posts->max_num_pages, $page) ?>
                    </nav>
                </section>
                <section id="about-me-tab" class="about-me-content author-section-content body-lg hidden">
                    <div class="bg-primary-20 border border-primary-500/[0.08] p-4 md:rounded-2xl text-justify">
                        <?= $aboutMe ?>
                    </div>
                </section>
            </div>
        </div>
    </main>