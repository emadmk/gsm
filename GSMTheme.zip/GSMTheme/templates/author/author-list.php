<?php

namespace GSM\templates\author;


$_this = $args['_this'];
$posts = $args['posts'];
if ($posts->have_posts())  foreach ($posts->posts as $post):
    switch ($post->post_type) {
        case 'post':
            $postType = __('خبر', 'gsm');
            break;
        case 'article':
            $postType = __('مقاله', 'gsm');
            break;
        case 'review':
            $postType = __('بررسی', 'gsm');
            break;

        default:
            $postType = __('خبر', 'gsm');
            break;
    }
    $readingTime = get_post_meta($post->ID, 'word_count', true);

?>
    <article class="w-full border border-gray-200 rounded-2xl p-4 bg-white flex gap-2 md:gap-4">
        <a href="<?= esc_url(get_permalink($post)) ?>" class="size-24 md:size-[7.5rem] shrink-0">
            <?php if (has_post_thumbnail($post)): ?>
                <?= get_the_post_thumbnail($post, 'full', ['class' => 'skeleton size-24 md:size-[7.5rem] object-cover shrink-0 rounded-lg', 'loading' => "lazy"]) ?>
            <?php else: ?>
                <div class="size-24 md:size-[7.5rem] shrink-0 rounded-lg bg-gray-100 flex-center ">
                    <i class="gsmicon-image text-xl text-gray-300"></i>
                </div>
            <?php endif ?>
        </a>
        <div class="grow flex flex-col justify-center">
            <header>
                <a href="<?= esc_url(get_permalink($post)) ?>" class="">
                    <div class="subtitle-sm md:subtitle-lg line-clamp-2"><?= esc_html($post->post_title) ?></div>
                </a>
            </header>
            <footer class="flex items-center justify-between md:justify-start gap-2 mt-2 caption">
                <div class="caption bg-gray-100 text-gray-700 flex-center px-4 h-6 rounded-[0.25rem]"><?= $postType ?></div>
                <span class="hidden md:block size-[2px] rounded-full bg-gray-300"></span>
                <time datetime="<?= $post->post_date ?>"><?php esc_attr_e(date_i18n('d M Y - h:m', strtotime($post->post_date)))  ?></time>
                <span class="hidden md:block size-[2px] rounded-full bg-gray-300"></span>
                <div class="hidden md:block"><?= __('مطالعه', 'gsm') ?> <?= ceil(intval($readingTime) / 200) ?> <?= __('دقیقه', 'gsm') ?></div>
            </footer>
        </div>
    </article>
<?php endforeach ?>