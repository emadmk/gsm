<?php
namespace GSM\templates\author;

use GSM\templates\general\General;
use WP_Query;

class Author
{
    use General;
    protected $query;
    public function __construct()
    {
    }

    

    public function setQuery($query)
    {
        $this->query = $query;
        $this->ajaxActions();
    }

    public function ajaxActions()
    {
        if ($this->query == 'filter') {
            $data =  sanitizeNestedObject(json_decode(stripslashes($_POST['data'])));
            $page = intval($data['page']);
            $author = intval($data['author']);
            $args = array(
                'post_type'         => ['news', 'article', 'review'],
                'order'             => 'DESC',
                'post_status'       => 'publish',
                'posts_per_page'    => 12,
                'paged'             => $page,
                'author'            => $author,
            );
            $filterList = new WP_Query($args);
            $list = $this->displayList($filterList);
            $pagination = $this->displayPagination($filterList->max_num_pages, $page);
            ajaxResponse(true, '', ['list' => $list, 'pagination' => $pagination]);
        }
    }

    public function displayList($posts)
    {
        ob_start();
        get_template_part('templates/author/author', 'list', ['_this' => $this, 'posts' => $posts]);
        return  ob_get_clean();
    }

    public function displayContent()
    {
        get_template_part('templates/author/author', 'content', ['_this' => $this]);
    }
}
