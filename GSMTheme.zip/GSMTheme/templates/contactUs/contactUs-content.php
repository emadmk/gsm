<?php

namespace GSM\templates\contactUs;


wp_enqueue_style('gsm-leaflet', GSM_URL . '/assets/css/leaflet.css', [], '1.9.2');
wp_enqueue_script('gsm-leaflet', GSM_URL . '/assets/js/leaflet.min.js', ['jquery'], '1.9.2', true);
wp_enqueue_script('gsm-contact-us', GSM_URL . '/assets/js/contact-us.js', ['jquery', 'gsm-leaflet'], GSM_VERSION, true);

$section1 = get_field('section_1');

?>

<div class="contact-us-container relative bg-gray-50 md:p-4">
    <div class="w-full h-full bg-white md:rounded-2xl px-4 md:px-0">
        <main class="container xl:max-w-screen-xl lg:px-10 pb-[4.5rem]">
            <?php if (function_exists('rank_math_the_breadcrumbs')): ?>
                <div class="breadcrumb pt-5 md:pt-8 caption ">
                    <?= rank_math_the_breadcrumbs(); ?>
                </div>
            <?php endif ?>
            <h1 class="h1 pt-6 md:pt-8 bg-white"><?= get_the_title() ?></h1>
            <section class="flex flex-col md:flex-row gap-6 md:gap-0 mt-6 md:my-8">
                <div class="w-full md:w-1/2 md:pl-6">
                    <?= do_shortcode($section1['form_shortcode']) ?>
                </div>
                <div id="gsm-map" class="gsm-map relative w-full md:w-1/2 h-[28.125rem] md:h-[32.75rem] flex flex-col rounded-2xl !font-sans transition-all" data-lat="<?= $section1['lat'] ?>" data-lng="<?= $section1['lng'] ?>">
                    <div class="absolute w-full p-4 bg-primary-700/[0.56] backdrop-blur-sm bottom-10 md:bottom-16 text-white z-[500]">
                        <h3 class="subtitle-lg"><?= __('آدرس:', 'gsm') ?></h3>
                        <p class="body-lg mt-2"><?= $section1['address'] ?></p>
                        <div class="body-lg flex flex-col md:flex-row md:items-center gap-5 md:gap-2">
                            <a href="tel:<?= $section1['phone']['number'] ?>" class="flex items-center gap-2 grow !text-white">
                                <i class="gsmicon-phone text-xl"></i>
                                <p class=""><?= $section1['phone']['text'] ?></p>
                            </a>
                            <a href="mailto:<?= $section1['email'] ?>" class="flex items-center gap-2 grow !text-white">
                                <i class="gsmicon-email text-xl"></i>
                                <p class=""><?= $section1['email'] ?></p>
                            </a>
                        </div>
                    </div>
                </div>
            </section>
        </main>
    </div>
</div>