<?php

namespace GSM\templates\search;

use GSM\templates\general\General;

class Search
{
    use General;
    protected $query;
    public function __construct()
    {
    }


    public function setQuery($query)
    {
        $this->query = $query;
        $this->ajaxActions();
    }

    public function ajaxActions()
    {
        
    }


    public function displayContent()
    {
        get_template_part('templates/search/search', 'content', ['_this' => $this]);
    }
}
