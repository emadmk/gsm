<?php

use GSM\includes\Api;
use GSM\includes\Query;
wp_enqueue_script('gsm-search', GSM_URL . '/assets/js/search.js', ['jquery'], GSM_VERSION, true);

$search = get_search_query();
$posts = Query::getSearchPost($search, -1);
$products = Api::getGSMProducts(['search' => $search]);
?>
<div class="search-container bg-gray-50 relative" data-search-id="<?= esc_attr(get_the_ID()) ?>">
    <main class="container xl:max-w-screen-xl py-4 md:pb-10 lg:px-10 ">
        <h1 class="h1 mt-4 mb-2 md:mb-6"><?= __('نتایج جستجو عبارت', 'gsm') . ' "' . $search . '"' ?></h1>
        <?php if ($products && $products->data && !empty($products->data)):
            $showMoreMaxPage = ceil($totalComment / 32);
            $api = get_field('apis', 'option');
            $siteAddress = isset($api['site_address']) && !empty($api['site_address']) ? $api['site_address'] : 'https://www.gsm.ir';
        ?>
            <h2 class="h3 mb-2 md:mb-6"><?= __('گوشی ها', 'gsm') ?></h2>
            <div class="grid grid-cols-1 md:grid-cols-3 lg:grid-cols-5 gap-6 mb-12">
                <?php foreach ($products->data as $key => $product):
                ?>
                    <a href="<?= $siteAddress . '/product' . '/gp-' . $product->id . '/' . $product->slug ?>" class="product-item <?= $key > 32 ? 'hidden' : 'flex' ?> relative items-stretch gap-2 lg:gap-4 flex-row md:flex-col h-full bg-white p-4 cursor-pointer rounded-lg">
                        <img src="<?= $product->image ?>" alt="<?= $product->title ?>" class="shrink-0 w-full rounded aspect-square p-2 md:p-4 relative" width="154" height="154" loading="lazy">
                        <div class="caption"><?= $product->brand_title ?></div>
                        <div class="subtitle-sm line-clamp-2 "><?= $product->title ?></div>
                        <?php if ($product->price && intval($product->price) > 0): ?>
                            <div class="h5 mt-auto flex gap-1 items-end"><?= __('قیمت', 'gsm') . ' ' . number_format(intval($product->price)) ?>
                                <span class="caption"><?= __('تومان', 'gsm') ?></span>
                            </div>
                        <?php else: ?>
                            <span class="caption"><?=$product->market_availability_status==='SOON' ? __('بزودی', 'gsm') : __('ناموجود', 'gsm') ?></span>
                        <?php endif; ?>
                    </a>
                <?php endforeach; ?>
            </div>
            <?php if (is_array($products->data) && count($products->data) > 32): ?>
                <button class="product-show-more w-full h-12 rounded-lg max-w-[24rem] border border-primary-500 text-primary-500 subtitle-sm mx-auto <?php echo count($products->data) > 32 ? 'flex' : 'hidden' ?> items-center justify-center gap-2 mt-4 " data-page="2" data-all-page="<?= $showMoreMaxPage  ?>">
                    <?= __('مشاهده بیشتر', 'gsm') ?>
                    <i class="gsmicon-chevron-bottom text-md"></i>
                </button>
            <?php endif ?>
        <?php endif; ?>
        <?php if ($posts && !empty($posts)):
            $showMoreMaxPage = ceil(count($posts) / 15);

        ?>
            <h2 class="h3 mb-2 md:mb-6"><?= __('اخبار و مقاله‌ها', 'gsm') ?></h2>
            <div class="grid grid-cols-1 md:grid-cols-3 lg:grid-cols-5 gap-6 mb-12">
                <?php foreach ($posts as $key => $post):
                ?>
                    <a href="<?= get_permalink($post->ID) ?>" class="post-item <?= $key > 15 ? 'hidden' : 'flex' ?> relative aspect-square cursor-pointer rounded-lg flex-col overflow-hidden">
                        <?php if (has_post_thumbnail($post)): ?>
                            <?= get_the_post_thumbnail($post->ID, 'medium', ['class' => ' absolute inset-0 w-full h-full skeleton object-cover shrink-0 z-0']) ?>
                        <?php else: ?>
                            <div class="absolute inset-0 w-full h-full bg-gray-100 object-cover shrink-0 flex-center z-0">
                                <i class="gsmicon-image text-xl text-gray-300"></i>
                            </div>
                        <?php endif ?>
                        <div class="backdrop-blur-md bg-gray-500/30 px-4 py-2 mt-auto relative text-white z-10">
                            <p class="subtitle-sm line-clamp-2"><?= $post->post_title ?></p>
                        </div>
                    </a>
                <?php endforeach; ?>
            </div>
            <?php if (is_array($posts) && count($posts) > 15): ?>
                <button class="post-show-more w-full h-12 rounded-lg max-w-[24rem] border border-primary-500 text-primary-500 subtitle-sm mx-auto <?php echo count($posts) > 15 ? 'flex' : 'hidden' ?> items-center justify-center gap-2 mt-4 " data-page="2" data-all-page="<?= $showMoreMaxPage  ?>">
                    <?= __('مشاهده بیشتر', 'gsm') ?>
                    <i class="gsmicon-chevron-bottom text-md"></i>
                </button>
            <?php endif ?>
        <?php endif; ?>
    </main>
</div>