<?php

namespace GSM\templates\home;

use GSM\includes\Api;
use GSM\includes\Query;
use WP_Query;

wp_enqueue_style('splide', GSM_URL . '/assets/css/splide-core.min.css', [], '4.1.2');
wp_enqueue_script('splide', GSM_URL . '/assets/js/splide.min.js', [], '4.1.2', true);
wp_enqueue_style('plyr', GSM_URL . '/assets/css/plyr.min.css', [], '3.6.12');
wp_enqueue_script('plyr', GSM_URL . '/assets/js/plyr.min.js', [], '3.6.12', true);
wp_enqueue_script('gsm-home', GSM_URL . '/assets/js/home.js', ['jquery', 'splide', 'plyr'], GSM_VERSION, true);

$_this = $args['_this'];
global $GSMComponents;
$stories = get_field('story');
$updatedPostsArgs = [
    'post_type'         => ['news', 'review', 'article'],
    'orderby'           => 'modified',
    'order'             => 'DESC',
    'post_status'       => 'publish',
    'posts_per_page'    => 10,
];

$updatedPosts = new WP_Query($updatedPostsArgs);

$latestPostsArgs = [
    'post_type'         => ['news', 'review', 'article'],
    'orderby'           => 'date',
    'order'             => 'DESC',
    'post_status'       => 'publish',
    'posts_per_page'    => 5,
];

$latestPosts = new WP_Query($latestPostsArgs);

$newsPostsArgs = [
    'post_type'         => 'news',
    'orderby'           => 'date',
    'order'             => 'DESC',
    'post_status'       => 'publish',
    'posts_per_page'    => 4,
];

$newsPosts = new WP_Query($newsPostsArgs);

$mostViewedRange = get_field('most-viewed-range') ?? 'today';
$mostViewed = Query::getMostViewedPosts($mostViewedRange, 5);
$mostViewedPostIds = wp_list_pluck($mostViewed, 'post_id');


$api = get_field('apis', 'option');
$siteAddress = isset($api['site_address']) && !empty($api['site_address']) ? $api['site_address'] : 'https://www.gsm.ir';
$mostViewedPostsArgs = [
    'post_type' => ['news', 'article', 'review'],
    'post__in' => $mostViewedPostIds,
    'orderby' => 'post__in',
    'posts_per_page' => 5,
];

$mostViewedPosts = new WP_Query($mostViewedPostsArgs);

$reviewsPostsArgs = [
    'post_type'         => 'review',
    'orderby'           => 'date',
    'order'             => 'DESC',
    'post_status'       => 'publish',
    'posts_per_page'    => 5,
];

$reviewsPosts = new WP_Query($reviewsPostsArgs);

$articlesPostsArgs = [
    'post_type'         => 'article',
    'orderby'           => 'date',
    'order'             => 'DESC',
    'post_status'       => 'publish',
    'posts_per_page'    => 5,
];

$articlesPosts = new WP_Query($articlesPostsArgs);
$customPosts = get_field('custom-post');

$allBrands = Api::getGSMBrands();
$articleBrans = get_option('all_article_brands', []);
$newsBrans = get_option('all_news_brands', []);
$reviewBrans = get_option('all_review_brands', []);
$allPostBrandsId = array_unique([...$articleBrans, ...$newsBrans, ...$reviewBrans]);
$filteredBrands = isset($allBrands) && !empty($allBrands->results) ? array_filter($allBrands->results, function ($brand) use ($allPostBrandsId) {
    return in_array($brand->id, $allPostBrandsId);
}) : [];


?>
<div class="home-container page-view-count relative" data-id="<?= get_the_ID() ?>">
    <main class="container xl:max-w-screen-xl py-4 lg:px-10 md:py-6">
        <h1 class="absolute size-[1px] overflow-hidden text-white"><?= __('جی‌‌اس‌ام | از بررسی تا خرید موبایل', 'gsm') ?></h1>
        <section class="">
            <div id="story-slider" class="splide story-slider w-full " aria-label="story slider">
                <div class="splide__track">
                    <ul class="splide__list ">
                        <?php if (isset($stories)) foreach ($stories as $i => $story): ?>
                            <li class="splide__slide flex-center pt-2 pr-2">
                                <figure class="cursor-pointer store-item" data-slide="<?= $i ?>">
                                    <?php if ($story['cover']): ?>
                                        <?= wp_get_attachment_image($story['cover'], 'thumbnail', false, ['class' => 'size-[3.75rem] rounded-full ring-2 ring-offset-4 ring-primary-500 skeleton'])    ?>
                                    <?php else: ?>
                                        <div class="size-[3.75rem] rounded-full ring-2 ring-offset-4 ring-primary-500 bg-gray-100 flex-center"><i class="gsmicon-image text-xl text-gray-300"></i></div>
                                    <?php endif ?>
                                    <figcaption class="caption text-center max-w-[4.25rem] mt-2"><?= esc_html($story['title']) ?></figcaption>
                                </figure>
                            </li>
                        <?php endforeach ?>
                    </ul>
                </div>
            </div>
            <div class="story-modal fixed w-full h-dvh bg-black flex-center modal-close top-0 right-0 transition-all duration-500 z-[99999]">
                <i class="gsmicon-cross-large close-story-btn text-white text-lg py-2 px-4 md:p-4 shrink-0 cursor-pointer absolute top-4 right-4"></i>
                <div class="loader size-12 md:size-16"></div>
            </div>
        </section>

        <section class="my-2 md:mt-10 md:mb-4 bg-gray-50 md:rounded-lg px-4 py-2 flex overflow-hidden">
            <div class="overline-font text-primary-500 shrink-0 pl-2"><?= __('مطالب آپدیت شده:', 'gsm') ?></div>
            <div id="break-line-slider" class="splide break-line-slider grow caption overflow-hidden" aria-label="break-line-slider">
                <div class="splide__track">
                    <ul class="splide__list ">
                        <?php if ($updatedPosts->have_posts()) foreach ($updatedPosts->posts as $post): ?>
                            <li class="splide__slide flex-center gap-2 w-fit">
                                <a href="<?= get_permalink($post) ?>" class="whitespace-nowrap w-fit"><?= $post->post_title ?></a>
                                <span class="size-1 rounded-full bg-primary-500/[0.64]"></span>
                            </li>
                        <?php endforeach ?>
                    </ul>
                </div>
            </div>
        </section>

        <section class="grid grid-cols-1 md:grid-cols-4 gap-2 md:gap-4 subtitle-sm">
            <?php if ($latestPosts->have_posts()) foreach ($latestPosts->posts as $i => $post): ?>
                <a href="<?= esc_url(get_permalink($post)) ?>" class="relative w-full overflow-hidden flex md:rounded-lg group  <?= $i === 0 ? 'flex-col h-[15.875rem] md:h-[26.25rem] md:col-span-2 md:row-span-2 mb-2 md:mb-0' : 'px-4 md:p-0 gap-4 md:gap-0 md:flex-col md:h-[12.5rem]' ?>">
                    <div class="absolute top-0 right-0 h-7 <?= $i === 0 ? '' : 'hidden' ?> md:flex-center px-4 text-white bg-primary-700 z-20"><?= esc_html(get_post_type_object($post->post_type)->labels->singular_name); ?></div>
                    <?php if (has_post_thumbnail($post)): ?>
                        <?= get_the_post_thumbnail($post, 'full', ['class' => 'object-cover skeleton transition-all duration-300 shrink-0 ' . ($i === 0 ? 'w-full h-full absolute inset-0 z-0 group-hover:scale-110' : 'size-20 rounded-lg md:w-full md:h-full md:absolute md:inset-0 md:group-hover:scale-110'), 'loading' => 'lazy']); ?>
                    <?php else: ?>
                        <div class="bg-gray-100 flex-center shrink-0  <?= $i === 0 ? 'w-full h-full absolute inset-0 z-0' : 'size-20 rounded-lg md:w-full md:h-full md:absolute md:inset-0' ?>">
                            <i class="gsmicon-image text-xl text-gray-300"></i>
                        </div>
                    <?php endif ?>
                    <div class="cover z-10 relative <?= $i === 0 ? 'bg-gray-700/60 blur-[20] p-4 w-full mt-auto text-white h-20 md:h-[10.375rem] flex items-center md:items-start md:flex-col' : 'grow md:grow-0 md:bg-gray-700/60 md:blur-[20] md:p-4 md:w-full md:mt-auto md:text-white md:h-20 md:flex md:items-center ' ?>">
                        <div class="line-clamp-2 <?= $i === 0 ? 'h3' : '' ?>"><?= esc_html($post->post_title) ?></div>
                        <?php if ($i === 0): ?>
                            <div class="mt-4 hidden md:block">
                                <p class="line-clamp-3"><?= wp_trim_words($post->post_content, 100) ?></p>
                            </div>
                        <?php endif ?>
                    </div>
                </a>
            <?php endforeach ?>
        </section>
        <section class="py-6 md:py-10 border-t border-gray-100 ">
            <div class="flex items-center justify-between gap-2 px-4 lg:px-0">
                <h2 class="h2"><?= __('بررسی‌های تخصصی', 'gsm') ?></h2>
                <?= $GSMComponents->button([
                    'content' => 'مشاهده همه',
                    'class' => 'subtitle-sm',
                    'type' => 'a',
                    'variant' => 'link',
                    'icon' => 'gsmicon-chevron-left',
                    'icon-position' => 'left',
                    'href' => '/reviews',
                ]) ?>
            </div>
            <div class="grid grid-cols-1 md:grid-cols-3 gap-4 subtitle-sm md:gap-y-16 pt-4">
                <?php if ($reviewsPosts->have_posts()) foreach ($reviewsPosts->posts as $i => $post):
                    $user = get_user_by('ID', $post->post_author);
                ?>
                    <a href="<?= esc_url(get_permalink($post)) ?>" class="relative w-full overflow-hidden flex md:rounded-lg group  <?= $i === 0 ? 'flex-col h-[15rem] md:h-[17.5rem] md:row-span-2 text-white ' : 'h-full px-4 md:p-0 gap-4 md:pl-5 ' ?>">
                        <?php if (has_post_thumbnail($post)): ?>
                            <?= get_the_post_thumbnail($post, 'full', ['class' => 'object-cover skeleton transition-all duration-300 shrink-0 ' . ($i === 0 ? 'w-full h-full absolute inset-0 z-0 group-hover:scale-110' : 'size-[6.5rem] rounded-lg'), 'loading' => 'lazy']); ?>
                        <?php else: ?>
                            <div class="bg-gray-100 flex-center shrink-0  <?= $i === 0 ? 'w-full h-full absolute inset-0 z-0' : 'size-[6.5rem] rounded-lg' ?>">
                                <i class="gsmicon-image text-xl text-gray-300"></i>
                            </div>
                        <?php endif ?>
                        <div class="cover z-10 relative flex flex-col <?= $i === 0 ? 'bg-gray-700/60 blur-[20] p-4 w-full mt-auto text-white h-[6.625rem] ' : 'grow h-full justify-center' ?>">
                            <div class="line-clamp-2 subtitle-sm"><?= esc_html($post->post_title) ?></div>
                            <div class="flex items-center gap-2  caption md:body-sm <?= $i === 0 ? ' mr-auto mt-auto' : 'text-gray-500  mt-2' ?>">
                                <address class="flex-center gap-1 not-italic">
                                    <?= __('نوشتهٔ', 'gsm') ?> <?= isset($user) && !empty($user) ? esc_html($user->display_name) : __('نویسنده GSM', 'gsm') ?>
                                </address>
                                <span class="">در</span>
                                <time datetime="<?= $post->post_date ?>"><?php esc_attr_e(date_i18n('d M Y', strtotime($post->post_date)))  ?></time>
                            </div>
                        </div>
                    </a>
                <?php endforeach ?>
            </div>
        </section>
        <div class="pt-6 md:pt-10 border-t border-gray-100 grid grid-cols-1 md:grid-cols-[3fr_2fr] gap-2 md:gap-6 mt-4 md:mt-10">
            <div class="w-full md:space-y-10">
                <section class="w-full px-4 lg:px-0 ">
                    <div class="flex items-center justify-between gap-2">
                        <h2 class="h2"><?= __('اخبار', 'gsm') ?></h2>
                        <?= $GSMComponents->button([
                            'content' => 'مشاهده همه',
                            'class' => 'subtitle-sm',
                            'type' => 'a',
                            'variant' => 'link',
                            'icon' => 'gsmicon-chevron-left',
                            'icon-position' => 'left',
                            'href' => '/news',
                        ]) ?>
                    </div>

                    <div class="divide-y divide-gray-100">
                        <?php if ($newsPosts->have_posts()) foreach ($newsPosts->posts as $post):
                            $user = get_user_by('ID', $post->post_author);
                            if ($user) {
                                $userImageId = get_field('profile-image', 'user_' . $user->ID);

                                if (!empty($userImageId)) {
                                    $userImageUrl = wp_get_attachment_image_src($userImageId, 'thumbnail', false)[0];
                                } else {
                                    $userImageUrl = get_avatar_url($user->ID);
                                }
                            }
                            $readingTime = get_post_meta($post->ID, 'word_count', true);

                        ?>
                            <article class="w-full flex items-center gap-2 md:gap-4 py-[0.875rem]">
                                <a href="<?= get_permalink($post) ?>" class="size-[6.5rem] md:size-[7.5rem] rounded-lg flex-center shrink-0">
                                    <?php if (has_post_thumbnail($post)): ?>
                                        <?= get_the_post_thumbnail($post, 'thumbnail', ['class' => 'size-[6.5rem] md:size-[7.5rem] object-cover rounded-lg skeleton']) ?>
                                    <?php else: ?>
                                        <div class="size-[6.5rem] md:size-[7.5rem] rounded-lg bg-gray-100 flex-center">
                                            <i class="gsmicon-image text-xl text-gray-300"></i>
                                        </div>
                                    <?php endif ?>
                                </a>
                                <div class="grow flex flex-col h-full justify-center">
                                    <header class="">
                                        <a href="<?= get_permalink($post) ?>" class="subtitle-sm md:subtitle-lg line-clamp-2 "><?= esc_html($post->post_title) ?></a>
                                    </header>
                                    <a href="<?= get_permalink($post) ?>" class="hidden md:block mt-2">
                                        <p class="line-clamp-1 "><?= esc_html($post->post_excerpt) ?></p>
                                    </a>
                                    <footer class="flex items-center justify-between md:justify-start gap-2 mt-5 md:mt-4 caption ">
                                        <div class="flex-center gap-1  text-gray-800">
                                            <img src="<?= esc_url($userImageUrl) ?>" alt="<?= __('تصویر', 'gsm') ?> <?= $user ? $user->display_name : __('نویسنده GSM', 'gsm') ?>" class="hidden md:block size-5 rounded-full skeleton " width="20" height="20">
                                            <address class="not-italic"><?= $user ? esc_html($user->display_name) : __('نویسنده GSM', 'gsm') ?></a>
                                        </div>
                                        <span class="hidden md:block size-[2px] rounded-full bg-gray-300"></span>
                                        <time datetime="<?= $post->post_date ?>"><?php esc_attr_e(date_i18n('d M Y - h:m', strtotime($post->post_date)))  ?></time>
                                        <span class="hidden md:block size-[2px] rounded-full bg-gray-300"></span>
                                        <div class="hidden md:block"><?= __('مطالعه', 'gsm') ?> <?= ceil(intval($readingTime) / 200) ?> <?= __('دقیقه', 'gsm') ?></div>
                                    </footer>
                                </div>
                            </article>
                        <?php endforeach ?>
                    </div>
                </section>
                <section class="w-full px-4 lg:px-0 ">
                    <div class="flex items-center justify-between gap-2 px-4 lg:px-0">
                        <h2 class="h2"><?= __('مقالات', 'gsm') ?></h2>
                        <?= $GSMComponents->button([
                            'content' => 'مشاهده همه',
                            'class' => 'subtitle-sm',
                            'type' => 'a',
                            'variant' => 'link',
                            'icon' => 'gsmicon-chevron-left',
                            'icon-position' => 'left',
                            'href' => '/articles',
                        ]) ?>
                    </div>

                    <div class="divide-y divide-gray-100">
                        <?php if ($articlesPosts->have_posts()) foreach ($articlesPosts->posts as $post):
                            $user = get_user_by('ID', $post->post_author);
                            if ($user) {
                                $userImageId = get_field('profile-image', 'user_' . $user->ID);
                                if (!empty($userImageId)) {
                                    $userImageUrl = wp_get_attachment_image_src($userImageId, 'thumbnail', false)[0];
                                } else {
                                    $userImageUrl = get_avatar_url($user->ID);
                                }
                            }
                            $readingTime = get_post_meta($post->ID, 'word_count', true);

                        ?>
                            <article class="w-full flex items-center gap-2 md:gap-4 py-[0.875rem]">
                                <a href="<?= get_permalink($post) ?>" class="size-[6.5rem] md:size-[7.5rem] rounded-lg flex-center shrink-0">
                                    <?php if (has_post_thumbnail($post)): ?>
                                        <?= get_the_post_thumbnail($post, 'thumbnail', ['class' => 'size-[6.5rem] md:size-[7.5rem] object-cover rounded-lg skeleton']) ?>
                                    <?php else: ?>
                                        <div class="size-[6.5rem] md:size-[7.5rem] rounded-lg bg-gray-100 flex-center">
                                            <i class="gsmicon-image text-xl text-gray-300"></i>
                                        </div>
                                    <?php endif ?>
                                </a>
                                <div class="grow flex flex-col h-full justify-center">

                                    <header class="">
                                        <a href="<?= get_permalink($post) ?>" class="subtitle-sm md:subtitle-lg line-clamp-2"><?= esc_html($post->post_title) ?></a>
                                    </header>
                                    <a href="<?= get_permalink($post) ?>" class="hidden md:block mt-2">
                                        <p class="line-clamp-1 "><?= esc_html($post->post_excerpt) ?></p>
                                    </a>
                                    <footer class="flex items-center justify-between md:justify-start gap-2 mt-5 md:mt-4 caption ">
                                        <div class="flex-center gap-1  text-gray-800">
                                            <img src="<?= esc_url($userImageUrl) ?>" alt="تصویر <?= $user ? $user->display_name : __('نویسنده GSM', 'gsm') ?>" class="hidden md:block size-5 rounded-full skeleton " width="20" height="20">
                                            <address class="not-italic"><?= $user ? esc_html($user->display_name) : __('نویسنده GSM', 'gsm') ?></address>
                                            </d>
                                            <span class="hidden md:block size-[2px] rounded-full bg-gray-300"></span>
                                            <time datetime="<?= $post->post_date ?>"><?php esc_attr_e(date_i18n('d M Y - h:m', strtotime($post->post_date)))  ?></time>
                                            <span class="hidden md:block size-[2px] rounded-full bg-gray-300"></span>
                                            <div class="hidden md:block">مطالعه <?= ceil(intval($readingTime) / 200) ?> دقیقه</div>

                                    </footer>
                                </div>
                            </article>
                        <?php endforeach ?>
                    </div>
                </section>
            </div>

            <?php if ($mostViewedPosts->have_posts() || (is_array($customPosts) && count($customPosts))): ?>
                <aside class="md:space-y-10">
                    <?php if ($mostViewedPosts->have_posts()): ?>
                        <section class="bg-primary-20 border-y border-primary-500/[0.08] md:border p-4 md:p-6 md:rounded-2xl">
                            <h2 class="h3"><?= __('پربازدیدترین مطالب', 'gsm') ?></h2>
                            <ul class="w-full divide-y divide-gray-100 body-sm pt-4">
                                <?php foreach ($mostViewedPosts->posts as $post): ?>
                                    <li class="flex items-center gap-4 py-[0.625rem]">
                                        <a href="<?= get_permalink($post) ?>" class="size-[5.5rem] shrink-0">
                                            <?php if (has_post_thumbnail($post)): ?>
                                                <?= get_the_post_thumbnail($post, 'thumbnail', ['class' => 'size-[5.5rem] object-cover rounded-lg skeleton']) ?>
                                            <?php else: ?>
                                                <div class="size-[5.5rem] rounded-lg bg-gray-100 flex-center">
                                                    <i class="gsmicon-image text-xl text-gray-300"></i>
                                                </div>
                                            <?php endif ?>
                                        </a>
                                        <a href="<?= get_permalink($post) ?>" class="">
                                            <div class="line-clamp-3"><?= esc_html($post->post_title) ?></div>
                                        </a>
                                    </li>
                                <?php endforeach ?>
                            </ul>
                        </section>
                    <?php endif ?>
                    <?php if (is_array($customPosts) && count($customPosts)): ?>
                        <section class="bg-primary-20 border-y border-primary-500/[0.08] md:border p-4 md:p-6 md:rounded-2xl">
                            <h2 class="h3"><?= __('تیتر دلخواه', 'gsm') ?></h2>
                            <div class="w-full divide-y divide-gray-100 body-sm pt-4 *:line-clamp-2 *:transition-all">
                                <?php foreach ($customPosts as $post): ?>
                                    <a href="<?= get_permalink($post) ?>" class="">
                                        <div class=" hover:text-primary-500 my-2 md:my-5"><?= esc_html($post->post_title) ?></div>
                                    </a>
                                <?php endforeach ?>
                            </div>
                        </section>
                    <?php endif ?>
                </aside>
            <?php endif ?>
        </div>
        <?php if (is_active_sidebar('home-sidebar-ads') && 0): ?>
            <section class="pb-6 md:pb-8 px-4 lg:px-0">
                <?php dynamic_sidebar('home-sidebar-ads'); ?>
            </section>
        <?php endif ?>
        <?= $_this->displayAds("home_middle"); ?>
        <section class="pt-6 md:pt-10 border-t border-gray-100 px-4 lg:px-0 mb-36">
            <h2 class="h3"><?= __('برندها', 'gsm') ?></h2>
            <div id="brands-slider" class="splide brands-slider w-full body-sm overflow-hidden mt-6" aria-label="brands-slider">
                <div class="splide__track">
                    <ul class="splide__list ">
                        <?php if (!empty($filteredBrands)) foreach ($filteredBrands as $brand):
                        ?>
                            <li class="splide__slide  w-24 md:w-28 h-[7.5rem] md:h-[8.5rem] rounded-lg border border-gry-200 flex items-center justify-between gap-2">
                                <a href="<?= $siteAddress . "/brands/" . str_replace('', '-', strtolower($brand->title_en)) ?>" class=" w-full h-full">
                                    <figure class="flex-center flex-col w-full h-full">
                                        <img src="<?= $brand->logo  ?>" alt="" class="size-12 md:size-14  object-contain" width="56" height="56" loading="lazy">
                                        <figcaption><?= esc_html($brand->title) ?></figcaption>
                                    </figure>
                                </a>
                            </li>
                        <?php endforeach ?>
                    </ul>
                </div>
            </div>
        </section>
        <?= $_this->displayFooterAds("home_footer"); ?>

    </main>
</div>