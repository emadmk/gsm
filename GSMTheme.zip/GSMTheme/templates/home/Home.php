<?php

namespace GSM\templates\home;

use Collator;
use GSM\templates\general\General;

class Home
{
    use General;
    protected $query;
    public function __construct() {}

    public  function getBlogPosts($blogPosts, $ajax = false)
    {
        ob_start();
        get_template_part('templates/home/home', 'blog-posts', ['class' => $this]);
        return ob_get_clean();
    }

    public function setQuery($query)
    {
        $this->query = $query;
        $this->ajaxActions();
    }

    public function ajaxActions()
    {
        if ($this->query == 'story') {
            $data =  sanitizeNestedObject(json_decode(stripslashes($_POST['data'])));
            $pageId = intval($data['pageId']);
            $story = $this->displayStory($pageId);
            ajaxResponse(true,'', $story);
        }
    }
    public function persianSort($a, $b)
    {
        $collator = new Collator('fa_IR');
        return $collator->compare($a, $b);
    }

    public function displayStory($postId)
    {
        ob_start();
        get_template_part('templates/home/home', 'story', ['_this' => $this, 'postId' => $postId]);
        return ob_get_clean();
    }

    public function displayContent()
    {

        get_template_part('templates/home/home', 'content', ['_this' => $this]);
    }
}
