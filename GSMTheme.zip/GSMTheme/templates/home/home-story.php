<?php

use GSM\includes\Api;

$_this = $args['_this'];
$postId = $args['postId'];
$stories = get_field('story', $postId);
?>
<div id="main-story-slider" class="splide main-story-slider flex flex-col w-full h-full grow relative" aria-label="main sotry slide">
    <div class="w-full flex items-center absolute top-0 z-[99] md:relative md:top-0">
        <i class="gsmicon-cross-large close-story-btn text-white text-lg py-2 px-4 md:p-4 shrink-0 cursor-pointer"></i>
        <ul class="splide__pagination story-pagination h-4 rounded-full hidden md:flex w-fit gap-1 md:gap-2 grow"></ul>
    </div>
    <div class="w-full max-w-[21rem] min-w-0 flex-center flex-col mx-auto relative">
        <div class="splide__track w-full">
            <ul class="splide__list ">
                <?php if (isset($stories)) foreach ($stories as $i => $story):
                    $type = $story['type'];
                ?>
                    <li class="splide__slide " data-splide-interval="<?= $type === 'video' ? -1 : (isset($story['interval']) ? $story['interval'] : 3000) ?>">
                        <?php if ($type === 'img'): ?>
                            <a href="<?= isset($story['link']['url']) ? $story['link']['url'] : '#' ?>" class="w-full h-full" aria-label="<?= isset($story['link']['title']) ? $story['link']['title'] : '' ?>">
                                <?= wp_get_attachment_image($story['img'], 'full', false, ['class' => 'w-full aspect-[9/16] max-h-[calc(100dvh_-_5rem)] md:max-h-[calc(100dvh_-_10rem)] object-cover', 'loading' => 'lazy']) ?>
                            </a>
                        <?php else : ?>
                            <?php if ($story['video']): ?>
                                <video controls crossorigin playsinline class="w-full  max-h-[calc(100dvh_-_5rem)] md:max-h-[calc(100dvh_-_10rem)] aspect-[9/16] story-video-item" data-item="<?= $i ?>">
                                    <source src="<?= $story['video'] ?>" type="video/mp4" size="720">
                                </video>
                            <?php endif ?>
                        <?php endif ?>
                        <?php if (isset($story['products']) && !empty($story['products'])):
                            $product = $story['products'][0];
                        ?>


                            <a href="<?= $siteAddress . '/product' . '/gp-' . $product->id . '/' . $product->slug ?>" class="product-item w-full flex items-center gap-2 px-4 py-3 bg-white border border-primary-500/[0.16] rounded-lg transition-all duration-300 cursor-pointer" target="_blank">
                                <?php if ($product->images[0]->url): ?>
                                    <img src="<?= $product->images[0]->url ?>" alt="<?= __('تصویر', 'gsm') ?> <?= $product->title ?>" class="size-12 md:size-16 object-contain shrink-0 skeleton" width="64" height="64" loading="lazy">
                                <?php else: ?>
                                    <div class="bg-gray-100 flex-center size-16 shrink-0">
                                        <i class="gsmicon-image text-xl text-gray-300"></i>
                                    </div>
                                <?php endif ?>
                                <div class="flex flex-col gap-1 grow">
                                    <h3 class="text-sm font-bold line-clamp-2"><?= $product->title ?></h3>
                                </div>
                            </a>
                        <?php endif ?>
                    </li>
                <?php endforeach ?>
            </ul>
        </div>
        <div class="splide__arrows hidden md:flex-center gap-4 w-full absolute">
            <button class="splide__arrow splide__arrow--prev absolute -right-24">
                <i class="gsmicon-chevron-right size-11 rounded-full flex-center bg-white text-lg text-gray-900"></i>
            </button>
            <button class="splide__arrow splide__arrow--next absolute -left-24">
                <i class="gsmicon-chevron-left size-11 rounded-full flex-center bg-white text-lg text-gray-900"></i>
            </button>
        </div>
    </div>
</div>