<?php

namespace GSM\templates\tag;

use GSM\templates\general\General;
use WP_Query;

class Tag
{
    use General;
    protected $query;
    public $term;
    public function __construct($term = 0)
    {
        $this->term = $term;
    }


    public function setQuery($query)
    {
        $this->query = $query;
        $this->ajaxActions();
    }

    public function ajaxActions()
    {
        if ($this->query == 'filter') {
            $data =  sanitizeNestedObject(json_decode(stripslashes($_POST['data'])));
            $page = intval($data['page']);
            $brand = intval($data['brand']);
            $termId = intval($data['term']);
            $this->term = get_term_by( "term_id", $termId,  'post_tag');

            $args = array(
                'post_type'         => ['news', 'review', 'article'],
                'orderby'           => 'date',
                'order'             => 'DESC',
                'post_status'       => 'publish',
                'posts_per_page'    => 10,
                'paged'             => $page,
                'tax_query'         => [
                    [
                        'taxonomy'         => 'post_tag',
                        'terms'            => $termId,
                        'field'            => 'term_id',
                        'operator'         => 'IN',
                    ]
                ],
            );
            if ($brand) {
                $args['meta_query'][] = [
                    'key'     => 'brands',
                    'value'   => '"' . $brand . '"', // For serialized array match
                    'compare' => 'LIKE',
                ]; 
            }
            $filerList = new WP_Query($args);
            $list = $this->displayList($filerList);
            $pagination = $this->displayPagination($filerList->max_num_pages,$page);
            ajaxResponse(true, 'لیست با موفقیت بروزرسانی گردید', ['list' => $list, 'pagination' => $pagination]);
        }
    }

    public function displayList($tags)
    {
        ob_start();
        get_template_part('templates/tag/tag', 'list', ['_this' => $this, 'tags' => $tags]);
        return  ob_get_clean();
    }

    public function displayContent()
    {
        get_template_part('templates/tag/tag', 'content', ['_this' => $this]);
    }
}
