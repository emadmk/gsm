<?php

namespace GSM\templates\tag;

use GSM\includes\Api;
use WP_Query;

wp_enqueue_style('splide', GSM_URL . '/assets/css/splide-core.min.css', [], '4.1.2');
wp_enqueue_script('splide', GSM_URL . '/assets/js/splide.min.js', [], '4.1.2', true);
wp_enqueue_script('gsm-newsList', GSM_URL . '/assets/js/tag.js', ['jquery', 'splide'], GSM_VERSION, true);

$_this = $args['_this'];

$allArticleBrandIds = get_option('all_article_brands', []);
$allNewsBrandIds = get_option('all_news_brands', []);
$allReviewBrandIds = get_option('all_review_brands', []);
$allBrandIds = array_merge($allArticleBrandIds, $allNewsBrandIds, $allReviewBrandIds);

$allBrands = Api::getGSMBrands();
$brandList = [];
if (!empty($allBrands->results) && count($allBrandIds)) {
    foreach ($allBrands->results as $item) {
        if (in_array($item->id, $allBrandIds)) {
            $brandList[] = $item;
        }
    }
}

$page = $_GET['pg'] ?? 1;
$brandId = $_GET['brand'] ?? 0;
$args = array(
    'post_type'         => ['news', 'review', 'article'],
    'orderby'           => 'date',
    'order'             => 'DESC',
    'post_status'       => 'publish',
    'posts_per_page'    => 10,
    'paged'             => $page,
    'tax_query'         => [
        [
            'taxonomy'         => 'post_tag',
            'terms'            => intval($_this->term->term_id),
            'field'            => 'term_id',
            'operator'         => 'IN',
        ]
    ],
);

if ($brandId) {
    $args['meta_query'][] = [
        'key'     => 'brands',
        'value'   => '"' . $brandId . '"', // For serialized array match
        'compare' => 'LIKE',
    ];
}
$tags = new WP_Query($args);
$seoBox = get_field('seo-box');
?>
<div class="tag-list-container relative bg-gray-50 md:p-4" data-tag-id="<?= $_this->term->term_id  ?>">
    <div class="w-full h-full md:bg-white md:rounded-2xl">
        <main class="container xl:max-w-screen-xl lg:px-10 pb-[4.5rem]">
            <?php if (function_exists('rank_math_the_breadcrumbs')): ?>
                <div class="breadcrumb pt-5 md:pt-8 caption bg-white px-4 md:px-0">
                    <?= rank_math_the_breadcrumbs();   ?>
                </div>
            <?php endif ?>
            <div class="sticky w-full bg-white top-0 pb-4 border-b border-gray-100 z-40">
                <h1 class="h1 pt-4 md:pt-6 px-4 md:px-0"><?= $_this->term->name ?></h1>
                <div class="flex items-center gap-2 px-4 md:px-0 overflow-hidden mt-4 md:mt-12">
                    <p class="body-sm shrink-0"><?= __('نمایش براساس برند:', 'gsm') ?></p>
                    <div id="brand-slider" class="splide brand-slider caption min-w-0 grow flex-center px-6" aria-label="brand slider">
                        <nav class="splide__track">
                            <ul class="splide__list ">
                                <li class="splide__slide cursor-pointer filter-chips brand-item <?= $brandId == 0 ? 'selected' : '' ?>" data-value="0">
                                    <?= __('همه', 'gsm') ?>
                                </li>
                                <?php
                                if (!empty($brandList)) foreach ($brandList as  $brand) :
                                ?>
                                    <li class="splide__slide cursor-pointer filter-chips brand-item <?= $brandId == $brand->id ? 'selected' : '' ?>" data-value="<?= esc_attr($brand->id) ?>">
                                        <?= $brand->title ?>
                                    </li>
                                <?php endforeach;
                                ?>
                            </ul>
                        </nav>
                        <div class="splide__arrows brand_arrows flex-center gap-4 w-full absolute">
                            <button class="splide__arrow splide__arrow--prev absolute right-0">
                                <i class="gsmicon-chevron-right flex-center text-xl text-primary-500"></i>
                            </button>
                            <button class="splide__arrow splide__arrow--next absolute left-0">
                                <i class="gsmicon-chevron-left flex-center text-xl text-primary-500"></i>
                            </button>
                        </div>
                    </div>
                </div>
            </div>
            <div class="grid grid-cols-1 md:grid-cols-[1.5fr_1fr] gap-4 md:gap-8 py-2 md:py-8 ">
                <section class="list-container space-y-2 md:space-y-4 order-1">
                    <?= $_this->displayList($tags) ?>
                </section>
                <aside class="sidebar md:space-y-10 order-3 md:order-2">
                    <?php if (is_active_sidebar('tag-list-sidebar')): ?>
                        <?php dynamic_sidebar('tag-list-sidebar'); ?>
                    <?php endif ?>
                </aside>
                <nav class="pagination md:mt-8 order-2 md:order-3" aria-label="Page navigation">
                    <?= $_this->displayPagination($tags->max_num_pages, $page) ?>
                </nav>
            </div>
            <?php if ($seoBox): ?>
                <article class="w-full border-t pt-6 px-4 md:px-0 mt-12 border-gray-100 relative ">
                    <div class="h2 "><?= $seoBox['title'] ?></div>
                    <div class="text-justify body-sm pt-4 seo-content overflow-hidden transition-all"><?= $seoBox['content'] ?></div>
                    <span class="w-full absolute bottom-9 right-0 h-[4.5rem] hidden bg-show-more-cover-gray  md:bg-show-more-cover"></span>
                    <button class="show-more-seo-box hidden gap-1 subtitle-sm text-primary-500 pt-2">
                        <?= __('نمایش', 'gsm') ?> <span class="close"><?= __('بیشتر', 'gsm') ?></span>
                        <i class="gsmicon-chevron-down-small text-lg transition-all"></i>
                    </button>
                </article>
            <?php endif ?>
        </main>
    </div>
</div>