<?php

namespace GSM\templates\tag;


$_this = $args['_this'];
$tags = $args['tags'];
if ($tags->have_posts())  foreach ($tags->posts as $post):
    $user = get_user_by('ID', $post->post_author);
    $userImageId = get_field('profile-image', 'user_' . $user->ID);
    if (!empty($userImageId)) {
        $userImageUrl = wp_get_attachment_image_src($userImageId, 'thumbnail', false)[0];
    } else {
        $userImageUrl = get_avatar_url($user->ID);
    }
    $readingTime = get_post_meta($post->ID, 'word_count', true);


    switch ($post->post_type) {
        case 'post':
            $postType = 'خبر';
            break;
        case 'article':
            $postType = 'مقاله';
            break;
        case 'review':
            $postType = 'بررسی';
            break;

        default:
            $postType = 'خبر';
            break;
    }

?>
    <article class="w-full border border-gray-200 rounded-2xl p-4 bg-white flex gap-2 md:gap-4">
        <a href="<?= esc_url(get_permalink($new)) ?>" class="size-24 md:size-[7.5rem] shrink-0">
            <?php if (has_post_thumbnail($post)): ?>
                <?= get_the_post_thumbnail($post, 'full', ['class' => 'size-24 md:size-[7.5rem] object-cover shrink-0 rounded-lg', 'loading' => "lazy"]) ?>
            <?php else: ?>
                <div class="size-24 md:size-[7.5rem] shrink-0 rounded-lg bg-gray-200 flex-center ">
                    <i class="gsmicon-logo text-2xl"></i>
                </div>
            <?php endif ?>
        </a>
        <div class="grow flex flex-col justify-center">
            <header>
                <a href="<?= esc_url(get_permalink($new)) ?>" class="">
                    <div class="subtitle-sm md:subtitle-lg line-clamp-2"><?= esc_html($post->post_title) ?></div>
                </a>
            </header>
            <div class="hidden md:block">
                <p class="body-sm line-clamp-1 mt-2"><?= esc_html($post->post_excerpt) ?></p>
            </div>
            <footer class="flex items-center justify-between md:justify-start gap-2 mt-2 caption">
                <div class="caption bg-gray-100 text-gray-700 flex-center px-4 h-6 rounded-[0.25rem]"><?= $postType ?></div>
                <span class="hidden md:block size-[2px] rounded-full bg-gray-300"></span>
                <?php if (0): ?>
                    <div class="flex-center gap-1  text-gray-800">
                        <img src="<?= esc_url($userImageUrl) ?>" alt="<?= __('تصویر', 'gsm') ?> <?= $user->display_name ?>" class="hidden md:block size-5 rounded-full skeleton " width="20" height="20" loading="lazy">
                        <address class=""><?= esc_html($user->display_name) ?></address>
                    </div>
                    <span class="hidden md:block size-[2px] rounded-full bg-gray-300"></span>
                <?php endif ?>
                <?php esc_attr_e(date_i18n('d M Y - h:m', strtotime($post->post_date)))  ?>
                <span class="hidden md:block size-[2px] rounded-full bg-gray-300"></span>
                <div class="hidden md:block"><?= __('مطالعه', 'gsm') ?> <?= ceil(intval($readingTime) / 200) ?> <?= __('دقیقه', 'gsm') ?></div>
            </footer>
        </div>
    </article>
<?php endforeach ?>