<?php

namespace GSM\templates\layouts\footer;

$_this = $args['_this'];
$type  = $_this->type;
global $GSMComponents;
$column1 = get_field('column-1', 'option');
$column2 = get_field('column-2', 'option');
$column3 = get_field('column-3', 'option');
$column4 = get_field('column-4', 'option');
$column5 = get_field('column-5', 'option');
?>
<?php if ($type != 'empty') : ?>
    </div><!-- .main-page-wrapper -->
    <footer class="footer-wrapper md:px-4 md:pb-4  mt-auto relative  <?= $_this->background ?>">
        <div class="bg-footer text-white rounded-t-2xl md:rounded-2xl">
            <div class="footer-container container xl:max-w-screen-xl px-4 lg:px-10 py-10 md:pt-16 md:pb-6 grid grid-cols-1 md:grid-cols-[1.5fr_4fr] gap-10">
                <section class="column-1">
                    <?php if (isset($column1['logo'])): ?>
                        <?= wp_get_attachment_image($column1['logo'], 'full', false, ['class' => 'h-6 md:h-8 object-contain w-fit']) ?>
                    <?php else: ?>
                        <img src="<?= GSM_URL . '/assets/img/logo.png' ?>" alt="<?= __('لوگوی سایت جی‌اس‌ام', 'gsm') ?>" class="h-6 lg:h-8 object-contain w-fit " height="32" width="186">
                    <?php endif ?>
                    <div class="mt-6 text-justify body-sm"><?= isset($column1['description']) ? $column1['description'] : __('جی‌اس‌ام، اولین رسانه‌ تخصصی موبایل در ایران محسوب می‌شود. رسالت ما در جی‌اس‌ام راهنمای انتخاب و خرید موبایل در ایران است و در این راستا تلاش می‌کنیم با بررسی‌های تخصصی، اخبار و راهنمای خرید، همراه مخاطب باشیم.', 'gsm') ?></div>
                    <ul class="social-media social-list flex items-center justify-between flex-wrap gap-2 mt-7 text-2xl">
                        <?php if (isset($column1['socials']) && !empty($column1['socials'])) foreach ($column1['socials'] as $social): ?>
                            <li>
                                <a href="<?= $social['link']['url'] ?>" target="_blank" aria-label="<?= $social['link']['title'] ?>">
                                    <i class="<?= $social['class'] ?>"></i>
                                </a>
                            </li>
                        <?php endforeach ?>
                    </ul>
                </section>
                <section class="grid grid-cols-1 md:grid-cols-4 gap-10 w-full">
                    <?php if ($column2): ?>
                        <div class="footer-column column-2 md:justify-self-center">
                            <div class="h4 w-fit"><?= $column2['title'] ??  '' ?></div>
                            <ul class="space-y-4 mt-6 body-sm w-fit">
                                <?php if ($column2['item'] && is_array($column2['item'])) foreach ($column2['item'] as $column): ?>
                                    <li class=""><a href="<?= $column['link'] ?>" class=""><?= $column['title'] ?></a></li>
                                <?php endforeach ?>
                            </ul>
                        </div>
                    <?php endif ?>
                    <?php if ($column3): ?>
                        <div class="footer-column column-3 md:justify-self-center">
                            <div class="h4 w-fit"><?= $column3['title'] ??  '' ?></div>
                            <ul class="space-y-4 mt-6 body-sm w-fit">
                                <?php if ($column3['item'] && is_array($column3['item'])) foreach ($column3['item'] as $column): ?>
                                    <li class=""><a href="<?= $column['link'] ?>" class=""><?= $column['title'] ?></a></li>
                                <?php endforeach ?>
                            </ul>
                        </div>
                    <?php endif ?>
                    <?php if ($column4): ?>
                        <div class="footer-column column-4 md:justify-self-center">
                            <div class="h4 w-fit"><?= $column4['title'] ??  '' ?></div>
                            <ul class="space-y-4 mt-6 body-sm w-fit">
                                <?php if ($column4['item'] && is_array($column4['item'])) foreach ($column4['item'] as $column): ?>
                                    <li class=""><a href="<?= $column['link'] ?>" class=""><?= $column['title'] ?></a></li>
                                <?php endforeach ?>
                            </ul>
                        </div>
                    <?php endif ?>
                    <?php if ($column5): ?>
                        <div class="column-5 md:justify-self-center">
                            <div class="h4 w-fit"><?= $column5['title'] ??  '' ?></div>
                            <ul class="space-y-4 mt-6 body-sm w-fit">
                                <?php if ($column5['item'] && is_array($column5['item'])) foreach ($column5['item'] as $column): ?>
                                    <li class=""><a href="<?= $column['link'] ?>" class=""><?= $column['title'] ?></a></li>
                                <?php endforeach ?>
                            </ul>
                        </div>
                    <?php endif ?>
                </section>
                <?php if (0): ?>
                    <section class="column-4">
                        <p class="body-sm"><?= __('عضویت در خبرنامه', 'gsm') ?></p>
                        <div class="text-input relative flex-center mt-2">
                            <input type="text" name="main-search" id="main-search" class="h-12 w-full bg-primary-20 rounded-lg p-3 border border-gray-200 caption pr-8 placeholder-gray-300 outline-none focus:border-primary-500" placeholder="<?= __('آدرس ایمیل خود را وارد کنید', 'gsm') ?>">
                            <i class="gsmicon-email text-lg absolute right-3 text-gray-700"></i>
                        </div>
                        <?= $GSMComponents->button([
                            'class' => 'subtitle-sm mt-4 w-full',
                            'size' => 'lg',
                            'content' => __('عضویت', 'gsm'),
                            'variant' => 'primary'
                        ]) ?>
                        <div class="sign-container flex w-full gap-3 flex-wrap items-center">

                        </div>
                    </section>
                <?php endif ?>
                <section class="caption md:col-span-2 border-t border-gray-600">
                    <p class="pt-6 text-center"><?= __('© ۱۴۰۳ - ۱۳۸۷ کپی بخش یا کل هر کدام از مطالب جی اس ام تنها با کسب مجوز مکتوب امکان پذیر است.', 'gsm') ?></p>
                </section>
            </div>
            <div id="toast-container" class="body-sm"></div>
        </div>
    </footer>
    </div><!-- end website wrapper -->
<?php endif ?>
<?php wp_footer(); ?>
</body>

</html>