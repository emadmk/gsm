<?php

namespace GSM\templates\layouts\footer;

class Footer
{
    protected $query;
    public $type;
    public $background;
    public function __construct($type = 'normal',$background='bg-gray-50')
    {
        $this->type = $type;
        $this->background = $background;
    }

    public function setQuery($query)
    {
        $this->query = $query;
        $this->ajaxActions();
    }

    public function ajaxActions()
    {
    }

    public function displayContent()
    {
        get_template_part('templates/layouts/footer/footer', 'content', ['_this' => $this]);
    }
}
