<?php
namespace GSM\templates\layouts\header;

class Header
{
    protected $query;
    public $type;
    public function __construct($type='normal')
    {
        $this->type =$type;
    }

    public function setQuery($query)
    {
        $this->query = $query;
        $this->ajaxActions();
    }

    public function ajaxActions()
    {
        
    }

    public function displayHeaderAds($zone)
    {
        ob_start();
        get_template_part('templates/layouts/header/header', 'ads', ['_this' => $this, 'zone' => $zone]);
        return ob_get_clean();
    }

    public function displayContent()
    {
        get_template_part('templates/layouts/header/header', 'content', ['_this' => $this]);
    }
}
