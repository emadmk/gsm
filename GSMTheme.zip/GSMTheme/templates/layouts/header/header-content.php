<?php

namespace GSM\templates\layouts\header;

use GSM\includes\nav\NavWalker;

$_this = $args['_this'];
$type = $_this->type;
$user = wp_get_current_user();
$headerZone = false;
if (is_home() || is_front_page()) {
    $headerZone = "home_header";
} elseif (is_single()) {
    if (get_post_type() == "news") {
        $headerZone = "news_header";
    } elseif (get_post_type() == "review") {
        $headerZone = "review_header";
    } elseif (get_post_type() == "article") {
        // $headerZone = "article_header";
    }
}
global $GSMComponents;
$headerData = get_field('header', 'option');
?>
<!DOCTYPE HTML>
<html <?php language_attributes() ?>>

<head>
    <meta http-equiv="Content-Type" content="text/html; charset=<?php bloginfo('charset'); ?>" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
    <meta content="width=device-width, initial-scale=1, maximum-scale=1" name="viewport" />
    <title><?php bloginfo('name'); ?> <?php wp_title(); ?></title>
    <link rel="profile" href="http://gmpg.org/xfn/11">
    <link rel="pingback" href="<?php bloginfo('pingback_url'); ?>">

    <?php wp_head(); ?>
</head>

<body <?php body_class(); ?>>
    <?php do_action('wp_body_open'); ?>
    <?php if ($type != 'empty') : ?>
        <div class="website-wrapper flex flex-col relative min-h-dvh">
            <?php if ($headerZone) echo $_this->displayHeaderAds($headerZone) ?>
            <header class="gsm-header w-full border-b border-gray-100">
                <div class="container xl:max-w-screen-xl px-4 lg:px-10 py-3 lg:py-6 flex items-center justify-between lg:justify-start">
                    <i class="gsmicon-burger-menu hamburger-menu text-xl lg:hidden cursor-pointer"></i>
                    <a href="<?= home_url() ?>" class="" aria-label="<?= __('بازگشت به صفحه اصلی', 'gsm') ?>">
                        <?php if (isset($headerData['logo'])): ?>
                            <?= wp_get_attachment_image($headerData['logo'], 'full', false, ['class' => 'h-6 lg:h-8 object-contain w-fit']) ?>
                        <?php else: ?>
                            <img src="<?= GSM_URL . '/assets/img/logo.png' ?>" alt="<?= __('لوگوی سایت جی‌اس‌ام', 'gsm') ?>" class="h-6 lg:h-8 object-contain " height="32" width="186">
                        <?php endif ?>
                    </a>
                    

                    <div class="menu-container px-6  lg:px-0 w-full lg:w-auto grow flex flex-col fixed lg:static -right-full lg:right-auto top-0 lg:top-0 h-dvh lg:h-auto overflow-y-auto lg:overflow-visible transition-all duration-500 z-[99999] lg:z-40 lg:mr-6 lg:grow bg-white">
                        <div class="flex items-center justify-between gap-4 lg:hidden">
                            <i class="gsmicon-cross-large menu-close text-xl p-4"></i>
                        </div>
                        <?php echo
                        wp_nav_menu(
                            array(
                                'theme_location' => 'main-menu',
                                'container' => 'nav',
                                'menu_class' => 'main-ul ',
                                'walker' => new NavWalker(),
                            )
                        );
                        ?>
                    </div>
                    <i class="gsmicon-search search-btn text-xl cursor-pointer mr-auto pl-4 lg:pl-0"></i>
                    <form class="main-search-form w-full lg:w-auto lg:max-w-[20.5rem] text-input lg:relative fixed flex flex-col -right-full lg:right-auto top-0 lg:top-0 h-dvh lg:h-auto overflow-y-auto lg:overflow-visible transition-all duration-500 z-[999] lg:z-60 lg:mr-auto lg:ml-4 bg-white" role="search" aria-label="<?= __('فرم جستجو', 'gsm') ?>">
                        <div class="w-full flex items-center justify-between lg:hidden px-4 py-3 border-b border-gray-100">
                            <i class="gsmicon-cross-large search-close text-xl p-2 -mr-2"></i>
                            <img src="<?= GSM_URL . '/assets/img/logo.png' ?>" alt="<?= __('لوگوی سایت جی‌اس‌ام', 'gsm') ?>" class="h-6 object-contain " height="32" width="186">
                            <div class=""></div>
                        </div>

                        <div class="main-search-container lg:absolute lg:left-0 lg:top-20 w-full lg:w-[26.5rem] lf:border-gray rounded-lg p-4 lg:p-2 bg-white hidden z-[60] grow lg:max-h-[calc(100vh_-_9rem)] lg:overflow-y-auto thin-scrollbar">
                            <div class="input-container w-full  sticky top-0 flex-center p-4 lg:p-0">
                                <span class="w-full h-4 absolute -top-4 bg-white"></span>
                                <input type="text" name="s" id="main-search" class="h-12 w-full flex-center lg:bg-primary-20 lg:rounded-lg p-3 border-b lg:border lg:border-gray-200 caption pr-8 placeholder-gray-300 outline-none focus:border-primary-500" placeholder="<?= __('عبارت خود را جستجو کنید', 'gsm') ?>">
                                <i class="gsmicon-search text-lg absolute right-3 text-gray-700"></i>
                                <span class="loader hidden size-5 absolute left-3"></span>
                            </div>
                            <div class="main-search-result-content w-full"></div>

                        </div>

                    </form>
                    <?php if (is_user_logged_in() && 0): ?>
                        <div class="user-profile-container relative group">
                            <div class="profile-logo-container flex-center cursor-pointer">
                                <i class="gsmicon-user text-xl"></i>
                                <i class="gsmicon-chevron-down-small"></i>
                            </div>
                            <div class="profile-menu absolute top-10 left-0 w-[15rem] opacity-0 transition-all duration-300 pointer-events-none translate-y-4 lg:group-hover:opacity-100 lg:group-hover:pointer-events-auto lg:group-hover:translate-y-0 z-50">
                                <div class="relative flex flex-col gap-4 p-4 rounded-2xl bg-white text-sm  shadow-md">
                                    <div class="hidden lg:block absolute -top-4 h-4 w-full left-0"></div>
                                    <a href="<?= isset($headerData['profile_link']) ? $headerData['profile_link'] : '#' ?>" class="text-sm hover:text-primary-500 transition-all"><?= __('حساب کاربری', 'gsm') ?></a>
                                    <div class="text-sm cursor pointer flex items-center justify-between">
                                        <div class="text-red-500 cursor-pointer logout-btn">خروج از حساب کاربری</div>
                                        <div class="loader size-5 hidden"></div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    <?php else: ?>
                        <?= $GSMComponents->button([
                            'type' => 'a',
                            'href' => isset($headerData['register_link']) ? $headerData['register_link'] : '#',
                            'class' => 'subtitle-sm',
                            'size' => 'lg',
                            'content' => __('ورود | ثبت‌نام', 'gsm'),
                            'variant' => 'secondary'
                        ]) ?>
                    <?php endif ?>
                </div>
            </header>
            <div class="main-page-wrapper relative">
                <div class="search-result-backdrop absolute z-0 lg:z-50 inset-0 w-full h-full min-h-dvh invisible lg:visible pointer-events-none lg:pointer-events-auto hidden bg-black/60 lg:cursor-pointer"></div>

            <?php endif ?>