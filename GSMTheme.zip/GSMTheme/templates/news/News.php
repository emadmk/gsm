<?php

namespace GSM\templates\news;

use DOMDocument;
use GSM\includes\Query;
use GSM\templates\general\General;

class News
{
    use General;
    protected $query;
    public function __construct()
    {
        if (!is_admin()) {
            add_filter('the_content', [$this, 'addAnchorLinksToHeadings'], 10, 1);
            add_filter('the_content', [$this, 'addTableAfterFirstParagraph'], 11, 1);
            add_filter('the_content', [$this, 'addSuggestedPost'], 12, 1);
            add_filter('the_content', [$this, 'addBlockquoteIcon'], 13, 1);

        }
    }


    public function setQuery($query)
    {
        $this->query = $query;
        $this->ajaxActions();
    }

    public function ajaxActions()
    {
        if ($this->query == 'view') {
            $data = sanitizeNestedObject(json_decode(stripslashes($_POST['data'])));
            $postId = isset($data['id']) ? intval($data['id']) : 0;
            if ($postId <= 0) {
                ajaxResponse(false, 'شناسه پست نامعتبر است');
            }
            $count = intval(get_post_meta($postId, 'view_count', true));
            $authorId = get_post_field('post_author', $postId);
            $authorViewCount = get_user_meta($authorId, 'view_count', true) ?: 0;
            update_user_meta($authorId, 'view_count', $authorViewCount + 1);
            update_post_meta($postId, 'view_count', $count + 1);
            Query::updatePostViewCount($postId);
            ajaxResponse(true, 'بازدید با موفقیت ثبت گردید', [$count]);
        }
    }


    public function addTableAfterFirstParagraph($content)
    {
        // Check if the content contains any paragraphs  
        if (preg_match('/<p[^>]*>.*?<\/p>/i', $content)) {

            // Create your table HTML here  
            $tableHtml = $this->displayTableOfContent();

            $ads = $this->displayAds("news_share");

            // Find the position of the first paragraph  
            $firstParagraphPosition = strpos($content, '<p');

            // Check if a paragraph was found  
            if ($firstParagraphPosition !== false) {
                // Find the position of the closing </p> tag of the first paragraph  
                $endOfFirstParagraph = strpos($content, '</p>', $firstParagraphPosition);

                // Insert the table HTML after the first paragraph  
                if ($endOfFirstParagraph !== false) {
                    $endOfFirstParagraph += strlen('</p>'); // Move to after the closing tag  
                    return substr_replace($content, $ads . $tableHtml, $endOfFirstParagraph, 0);
                }
            }
        }
        return $content;
    }

    public function displayContent()
    {
        get_template_part('templates/news/news', 'content', ['_this' => $this]);
    }
}
