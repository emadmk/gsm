<?php

namespace GSM\templates\news;

use GSM\templates\general\General;
use WP_Query;

class NewsList
{
    use General;
    protected $query;
    public function __construct() {}


    public function setQuery($query)
    {
        $this->query = $query;
        $this->ajaxActions();
    }

    public function ajaxActions()
    {
        if ($this->query == 'filter') {
            $data =  sanitizeNestedObject(json_decode(stripslashes($_POST['data'])));
            $page = intval($data['page']);
            $brand = intval($data['brand']);
            $args = array(
                'post_type'         => 'news',
                'orderby'           => 'date',
                'order'             => 'DESC',
                'post_status'       => 'publish',
                'posts_per_page'    => 10,
                'paged'             => $page,
            );
            if ($brand) {
                $args['meta_query'][] = [
                    'key'     => 'brands',
                    'value'   => '"' . $brand . '"', // For serialized array match
                    'compare' => 'LIKE',
                ];
            }
            $filerList = new WP_Query($args);
            $list = $this->displayList($filerList);
            $pagination = $this->displayPagination($filerList->max_num_pages, $page);
            ajaxResponse(true, '', ['list' => $list, 'pagination' => $pagination]);
        }
    }

    public function displayList($news)
    {
        ob_start();
        get_template_part('templates/news/newsList', 'list', ['_this' => $this, 'news' => $news]);
        return  ob_get_clean();
    }

    public function displayContent()
    {
        get_template_part('templates/news/newsList', 'content', ['_this' => $this]);
    }
}
