<?php

namespace GSM\templates\news;


$_this = $args['_this'];
$news = $args['news'];
if ($news->have_posts())  foreach ($news->posts as $new):
    $user = get_user_by('ID', $new->post_author);
    $userImageId = get_field('profile-image', 'user_' . $user->ID);
    if (!empty($userImageId)) {
        $userImageUrl = wp_get_attachment_image_src($userImageId, 'thumbnail', false)[0];
    } else {
        $userImageUrl = get_avatar_url($user->ID);
    }
    $readingTime = get_post_meta($new->ID, 'word_count', true);


?>
    <article href="<?= esc_url(get_permalink($new)) ?>" class="w-full border border-gray-200 rounded-2xl p-4 bg-white flex gap-2 md:gap-4">
        <a href="<?= esc_url(get_permalink($new)) ?>" class="size-24 md:size-[7.5rem] shrink-0">
            <?php if (has_post_thumbnail($new)): ?>
                <?= get_the_post_thumbnail($new, 'full', ['class' => 'size-24 md:size-[7.5rem] object-cover shrink-0 rounded-lg', 'loading' => "lazy"]) ?>
            <?php else: ?>
                <div class="size-24 md:size-[7.5rem] shrink-0 rounded-lg bg-gray-100 flex-center ">
                    <i class="gsmicon-image text-xl text-gray-300"></i>
                </div>
            <?php endif ?>
        </a>
        <div class="grow flex flex-col justify-center">
            <header>
                <a href="<?= esc_url(get_permalink($new)) ?>" class="">
                    <div class="subtitle-sm md:subtitle-lg line-clamp-2"><?= esc_html($new->post_title) ?></div>
                </a>
            </header>
            <div class="hidden md:block">
                <p class="body-sm line-clamp-1 mt-2"><?= esc_html($new->post_excerpt) ?></p>
            </div>
            <footer class="flex items-center justify-between md:justify-start gap-2 mt-2 caption">
                <div class="flex-center gap-1  text-gray-800">
                    <img src="<?= esc_url($userImageUrl) ?>" alt="تصویر <?= $user->display_name ?>" class="hidden md:block size-5 rounded-full skeleton " width="20" height="20">
                    <address class="not-italic"><?= esc_html($user->display_name) ?></address>
                </div>
                <span class="hidden md:block size-[2px] rounded-full bg-gray-300"></span>
                <time datetime="<?= $new->post_date ?>"><?php esc_attr_e(date_i18n('d M Y - h:m', strtotime($new->post_date)))  ?></time>
                <span class="hidden md:block size-[2px] rounded-full bg-gray-300"></span>
                <div class="hidden md:block">مطالعه <?= ceil(intval($readingTime) / 200) ?> دقیقه</div>
            </footer>
        </div>
    </article>
<?php endforeach ?>