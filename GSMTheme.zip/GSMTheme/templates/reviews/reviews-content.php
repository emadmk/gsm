<?php

namespace GSM\templates\reviews;

use GSM\includes\comment\Comment;
use WP_Query;

global $post;

$_this = $args['_this'];
$faq = get_field('post_faq');
$jsDependency = ['jquery', 'glightbox'];
if ($faq) {
    wp_enqueue_script('gsm-toggleTab', GSM_URL . '/assets/js/toggle-tab.js', ['jquery'], GSM_VERSION, true);
    $jsDependency[] = 'gsm-toggleTab';
}
wp_enqueue_script('glightbox', GSM_URL . '/assets/js/glightbox.min.js', [], GSM_VERSION, true);
wp_enqueue_script('gsm-reviews', GSM_URL . '/assets/js/reviews.js', $jsDependency, GSM_VERSION, true);
wp_enqueue_style('glightbox', GSM_URL . '/assets/css/glightbox.min.css', [], GSM_VERSION);

// post data
$sponsor = get_field('sponsor');

// author data
$author = get_user_by('ID', get_the_author_meta('ID'));
$userImageId = get_field('profile-image', 'user_' . $author->ID);
$userLabel = !empty(get_field('author-label', 'user_' . $author->ID)) ? get_field('author-label', 'user_' . $author->ID) : 'نویسنده جی اس ام';
$shortDescription = get_field('short-description', 'user_' . $author->ID);
if (!empty($userImageId)) {
    $userImage = wp_get_attachment_image($userImageId, 'thumbnail', false,  ['class' => 'size-6 md:size-8 rounded-full object-cover shrink-0']);
} else {
    $userAvatar = get_avatar_url($author->ID);
    $userImage = '<img class="size-6 md:size-8 rounded-full object-cover shrink-0" src="' . $userAvatar . '">';
}
// brand data
$brandIds = get_post_meta(get_the_ID(), 'brands', true); // Assume this returns an array of IDs
// $allBrands = Api::getGSMBrands();
// $brandList = [];
// if (!empty($allBrands->results) && is_array($brandIds)) {
//     foreach ($allBrands->results as $item) {
//         if (in_array($item->id, $brandIds)) {
//             $brandList[] = $item;
//         }
//     }
// }

$totalComment = get_comments_number();
$readingTime = get_post_meta(get_the_ID(), 'word_count', true);


// related post data

$tagIds = [];
$tagList = [];
foreach (get_the_tags() as $tag) {
    $tagIds[] = $tag->term_id;
    $tagList[$tag->term_taxonomy_id] = $tag->name;
}
$metaQuery = ['relation' => 'OR'];
if (is_array($brandIds)) {
    foreach ($brandIds as $brandId) {
        $metaQuery[] = [
            'key'     => 'brands',
            'value'   => '"' . intval($brandId) . '"',
            'compare' => 'LIKE',
        ];
    }
}
$relatedPostArgs = [
    'post_type'         => ['review'],
    'none_content'      => true,
    'orderby'           => 'rand',
    'order'             => 'DESC',
    'post_status'       => 'publish',
    'post__not_in'      => [get_the_ID()],
    'posts_per_page'    => 6,
    'meta_query'        => $metaQuery,
];

$relatedPosts = new WP_Query($relatedPostArgs);
$products = get_field('products');

?>
<main class="reviews-container bg-white relative overflow-hidden" data-reviews-id="<?= esc_attr(get_the_ID()) ?>">
    <article class="container xl:max-w-screen-xl py-4 lg:px-10">
        <?php if (function_exists('rank_math_the_breadcrumbs')): ?>
            <div class="breadcrumb caption pb-4">
                <?= rank_math_the_breadcrumbs();   ?>
            </div>
        <?php endif ?>
        <div class="flex flex-col md:flex-row relative md:items-center ">
            <?php if (has_post_thumbnail()): ?>
                <figure class="w-full md:mr-[11rem]">
                    <?= get_the_post_thumbnail($post, 'full', ['class' => 'w-full object-cover skeleton aspect-[2_/_1]  md:rounded-lg']) ?>
                </figure>
            <?php else: ?>
                <figure class="w-full bg-gray-100 flex-center asp aspect-[2_/_1] md:mr-[11rem] md:rounded-lg">
                    <i class="gsmicon-image text-xl text-gray-300"></i>
                </figure>
            <?php endif ?>
            <div class="md:my-10 md:rounded-lg bg-gray-50/[0.85] md:absolute md:right-0 p-4 md:p-8 backdrop-blur-sm w-full md:max-w-[32.5rem] flex flex-col gap-2 md:gap-4">
                <a href="#author-section" class="flex items-center gap-2">
                    <?= $userImage ?>
                    <author class="body-sm"><?= $author->display_name ?></author>
                </a>
                <h1 class="h1 "><?= get_the_title() ?></h1>
                <p class="body-lg line-clamp-4 md:line-clamp-4 "><?= get_the_excerpt() ?></p>
                <ul class="grow flex items-center flex-wrap gap-2 caption text-gray-500 *:flex *:items-center *:gap-2">
                    <li class="">
                        <time class="" datetime="<?= get_the_date('Y-m-d H:i:s') ?>"><?= __('منتشر شده در', 'gsm') ?> <?= esc_attr__(get_the_date('d M Y'));  ?></ti>
                    </li>
                    <?php if ($readingTime): ?>
                        <li class="">
                            <span class="size-[0.125rem] rounded-full bg-gray-300"></span>
                            <div class=""><?= __('مطالعه', 'gsm') ?> <?= ceil(intval($readingTime) / 200) ?> <?= __('دقیقه', 'gsm') ?></div>
                        </li>
                    <?php endif ?>
                </ul>
                <ul class="flex gap-2 flex-wrap">
                    <?php foreach ($tagList as $tagId => $tag) : ?>
                        <li>
                            <a href="<?php echo esc_url(get_term_link($tagId)) ?>" class="caption flex-center h-[1.375rem] px-4 rounded-sm bg-primary-500/[0.08] text-primary-500" title="<?php esc_attr_e($tag) ?>"><?php esc_attr_e($tag) ?></a>
                        </li>
                    <?php endforeach ?>
                </ul>
                <div class="mr-auto shrink-0 flex-center gap-4 mt-2 md:mt-0">
                    <div class=" flex-center gap-1 caption">
                        <i class="gsmicon-chat text-base"></i>
                        <?= $totalComment ?>
                    </div>
                    <i class="gsmicon-share text-base"></i>
                </div>
            </div>
        </div>
        <div class="mx-auto px-4 md:px-0 md:max-w-[52.875rem]">
            <?= $_this->displayProducts($products) ?>
        </div>
        <div class="post-content review-content mx-auto px-4 md:px-0 md:max-w-[52.875rem] pt-4 md:pt-6">
            <?php the_content() ?>
        </div>
        <?php if ($sponsor && $sponsor['display_sponsor']): ?>
            <div class="flex items-center sponsor-container mx-auto md:max-w-[52.875rem] gap-2 py-4 px-6 md:px-8 rounded-lg bg-primary-20 border border-gray-100 caption md:my-6">
                <figure>
                    <img src="<?= GSM_URL . '/assets/img/mini-logo.svg' ?>" alt="" class="size-6 " loading="lazy">
                </figure>
                <div>
                    <?= $sponsor['content'] ?>
                </div>
            </div>
        <?php endif ?>
        <?php if ($faq && !empty($faq)): ?>
            <div class="mx-auto px-4 md:px-0 md:max-w-[52.875rem]">
                <?= $_this->displayFaq($faq) ?>
            </div>
        <?php endif ?>
        </section>
        <section id="author-section" class=" py-4 md:py-8 mt-6 border-t border-b border-gray-100 mx-auto px-4 md:px-0 md:max-w-[52.875rem]">
            <a href="<?= get_author_posts_url($author->ID) ?>" class="flex items-center gap-4 md:gap-6">
                <?= $userImage ?>
                <div class="space-y-2 md:spacey-4">
                    <author class="subtitle-sm"><?= $author->display_name ?></author>
                    <div class="caption mt-2"><?= $userLabel ?></div>
                </div>
            </a>
            <p class="text-justify mt-4 body-sm"><?= $shortDescription ?></p>
        </section>
        <section class=" py-4 md:py-8 mx-auto px-4 md:px-0 md:max-w-[52.875rem] border-b border-gray-100" id="related-articles">
            <div class="h3"><?= __('مطالب مرتبط', 'gsm') ?></div>
            <?php if ($relatedPosts): ?>
                <ul class="divide-y divide-gray-100 w-full">
                    <?php if (count($relatedPosts->posts)) foreach ($relatedPosts->posts as $post):
                        setup_postdata($post);
                    ?>
                        <li class="w-full">
                            <article class="w-full flex gap-4 py-6 group article-card" target="_blank">
                                <a href="<?= get_permalink() ?>" class="size-14 md:size-24 shrink-0">
                                    <?php if (has_post_thumbnail()): ?>
                                        <?= get_the_post_thumbnail($post, 'full', ['class' => 'size-14 md:size-24 rounded-[0.25rem] md:rounded-lg object-cover shrink-0', 'loading' => 'lazy']) ?>
                                    <?php else: ?>
                                        <div class="bg-gray-100 flex-center size-14 md:size-24 rounded-[0.25rem] md:rounded-lg object-cover shrink-0">
                                            <i class="gsmicon-image text-xl text-gray-300"></i>
                                        </div>
                                    <?php endif ?>
                                </a>
                                <div class="article-info grow md:py-2 group-hover:text-primary-500 *:transition-all *:duration-500 flex flex-col justify-center gap-2">
                                    <header>
                                        <a href="<?= get_permalink() ?>" class="subtitle-lg line-clamp-2 "><?= get_the_title() ?></a>
                                    </header>
                                    <footer>
                                        <p class="body-sm line-clamp-4 md:line-clamp-2"><?= get_the_excerpt() ?></p>
                                    </footer>
                                </div>
                            </article>
                        </li>
                    <?php
                        wp_reset_postdata();
                    endforeach ?>
                </ul>
            <?php endif ?>
        </section>
        <?php
        if (comments_open()) {
            $comment = new Comment('review');
            echo $comment->generateCustomComment(get_the_ID());
        }
        ?>
    </article>
</main>
<?php
wp_reset_postdata();
