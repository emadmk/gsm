<?php

namespace GSM\templates\reviews;


$_this = $args['_this'];
$reviews = $args['reviews'];
if ($reviews->have_posts())  foreach ($reviews->posts as $review):
    $user = get_user_by('ID', $review->post_author);
    $userImageId = get_field('profile-image', 'user_' . $user->ID);
    if (!empty($userImageId)) {
        $userImageUrl = wp_get_attachment_image_src($userImageId, 'thumbnail', false)[0];
    } else {
        $userImageUrl = get_avatar_url($user->ID);
    }
    $readingTime = get_post_meta($review->ID, 'word_count', true);

?>
    <article href="<?= esc_url(get_permalink($review)) ?>" class="w-full border border-gray-200 rounded-2xl bg-white flex md:flex-col overflow-hidden">
        <a href="<?= esc_url(get_permalink($review)) ?>" class="size-[6.5rem] md:w-full md:h-[10.5rem] shrink-0">
            <?php if (has_post_thumbnail($review)): ?>
                <?= get_the_post_thumbnail($review, 'full', ['class' => 'size-[6.5rem] md:w-full md:h-[10.5rem] object-cover shrink-0', 'loading' => "lazy"]) ?>
            <?php else: ?>
                <div class="size-[6.5rem] md:w-full md:h-[10.5rem] object-cover shrink-0 bg-gray-100 flex-center ">
                    <i class="gsmicon-image text-xl text-gray-300"></i>
                </div>
            <?php endif ?>
        </a>
        <div class="grow flex flex-col px-4 py-3 md:py-4">
            <header>
                <a href="<?= esc_url(get_permalink($review)) ?>" class="">
                    <div class="subtitle-sm md:subtitle-lg line-clamp-2"><?= esc_html($review->post_title) ?></div>
                </a>
            </header>
            <footer class="flex items-center justify-between gap-2 caption mt-[0.625rem]">
                <div class="flex-center gap-1  text-gray-800">
                    <img src="<?= esc_url($userImageUrl) ?>" alt="تصویر <?= $user->display_name ?>" class="hidden md:block size-5 rounded-full skeleton " width="20" height="20">
                    <address class="not-italic"><?= esc_html($user->display_name) ?></address>
                </div>
                <time datetime="<?= $review->post_date ?>"><?php esc_attr_e(date_i18n('d M Y - h:m', strtotime($review->post_date)))  ?></time>
            </footer>
        </div>
    </article>
<?php endforeach ?>