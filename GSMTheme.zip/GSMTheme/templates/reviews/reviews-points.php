<?php

namespace GSM\templates\reviews;

$_this = $args['_this'];
$pointsData = $args['pointsData'];
?>
<div class="points-container w-full mt-6">
    <h2 class="h2"><?= $pointsData['title'] ?></h2>
    <div class="grid grid-cols-1 md:grid-cols-2 gap-6 md:gap-4 w-full body-sm mt-6">
        <?php if ($pointsData['positive'] && is_array($pointsData['positive']) && count($pointsData['positive'])): ?>
            <div class="py-4 px-5 rounded-lg border border-gray-200 border-t-2 border-t-green-500">
                <div class="px-2 h3 pb-8 text-green-500"><?= __('نقاط مثبت', 'gsm') ?></div>
                <ul class="space-y-5">
                    <?php foreach ($pointsData['positive'] as $point): ?>
                        <li class="flex gap-2">
                            <i class="gsmicon-plus-large size-[1.125rem] rounded-[0.25rem] flex-center text-white bg-green-500 shrink-0"></i>
                            <?= $point['item'] ?>
                        </li>
                    <?php endforeach ?>
                </ul>
            </div>
        <?php endif ?>
        <?php if ($pointsData['negative'] && is_array($pointsData['negative']) && count($pointsData['negative'])): ?>
            <div class="py-4 px-5 rounded-lg border border-gray-200 border-t-2 border-t-red-500">
                <div class="px-2 h3 pb-8 text-red-500"><?= __('نقاط مثبت', 'gsm') ?></div>
                <ul class="space-y-5">
                    <?php foreach ($pointsData['negative'] as $point): ?>
                        <li class="flex gap-2">
                            <i class="gsmicon-minus-large size-[1.125rem] rounded-[0.25rem] flex-center text-white bg-red-500 shrink-0"></i>
                            <?= $point['item'] ?>
                        </li>
                    <?php endforeach ?>
                </ul>
            </div>
        <?php endif ?>
    </div>
</div>