<?php

namespace GSM\templates\reviews;

use WP_Query;

wp_enqueue_style('splide', GSM_URL . '/assets/css/splide-core.min.css', [], '4.1.2');
wp_enqueue_script('splide', GSM_URL . '/assets/js/splide.min.js', [], '4.1.2', true);
wp_enqueue_script('gsm-reviewsList', GSM_URL . '/assets/js/reviews-list.js', ['jquery', 'splide'], GSM_VERSION, true);

$_this = $args['_this'];

$pinnedReviewIds = get_field('pinned_post');
if ($pinnedReviewIds) {
    $pinArgs = array(
        'post_type'         => 'review',
        'post__in'         => $pinnedReviewIds,
        'orderby'           => 'post__in',
        'post_status'       => 'publish',
        'posts_per_page'    => -1,
    );
    $pinReview = new WP_Query($pinArgs);
}


$page = $_GET['pg'] ?? 1;
$brandId = $_GET['brand'] ?? 0;
$args = array(
    'post_type'         => 'review',
    'orderby'           => 'date',
    'order'             => 'DESC',
    'post_status'       => 'publish',
    'posts_per_page'    => 8,
    'paged'             => $page,
);
if ($brandId) {
    $args['meta_query'][] = [
        'key'     => 'brands',
        'value'   => '"' . $brandId . '"', // For serialized array match
        'compare' => 'LIKE',
    ];
}
if ($pinnedReviewIds) {
    $args['post__not_in'] = $pinnedReviewIds;
}
$reviews = new WP_Query($args);
$seoBox = get_field('seo-box');
?>
<div class="reviews-list-container relative bg-gray-50 md:p-4" data-pinned-list="<?= implode(',', $pinnedReviewIds) ?>">
    <div class="w-full h-full md:bg-white md:rounded-2xl">
        <main class="container xl:max-w-screen-xl lg:px-10 pb-[4.5rem]">
            <?php if (function_exists('rank_math_the_breadcrumbs')): ?>
                <div class="breadcrumb pt-5 md:pt-8 caption bg-white px-4 md:px-0">
                    <?= rank_math_the_breadcrumbs();   ?>
                </div>
            <?php endif ?>
            <section>
                <h1 class="h1 pt-6 md:pt-8 px-4 md:px-0 bg-white"><?= get_the_title() ?></h1>
                <?php if (count($pinReview->posts)): ?>
                    <div id="pin-review-slider" class="splide pin-review-slider pt-5 md:pt-6 bg-white" aria-label="pin review slider">
                        <div class="splide__track">
                            <div class="splide__list ">
                                <?php foreach ($pinReview->posts as  $review) :
                                    $user = get_user_by('ID', $review->post_author);
                                    $userImageId = get_field('profile-image', 'user_' . $user->ID);
                                    if (!empty($userImageId)) {
                                        $userImageUrl = wp_get_attachment_image_src($userImageId, 'thumbnail', false)[0];
                                    } else {
                                        $userImageUrl = get_avatar_url($user->ID);
                                    }

                                ?>
                                    <li class="splide__slide group">
                                        <article class="w-full  md:rounded-t-lg overflow-hidden relative flex flex-col h-[14.25rem] md:h-[19.5rem]">
                                            <a href="<?= esc_url(get_permalink($review)) ?>" class="w-full h-[14.25rem] md:h-[19.5rem] flex flex-col">
                                                <?php if (has_post_thumbnail($review)): ?>
                                                    <?= get_the_post_thumbnail($review, 'full', ['class' => 'w-full h-full  object-cover absolute inset-0 z-0', 'loading' => "lazy"]) ?>
                                                <?php else: ?>
                                                    <div class="w-full h-[14.25rem] md:h-[19.5rem] object-cover absolute inset-0 z-0 bg-gray-200 flex-center ">
                                                        <i class="gsmicon-logo text-2xl"></i>
                                                    </div>
                                                <?php endif ?>
                                                <div class="relative z-10 p-4 md:p-6 backdrop-blur-[20px] text-white md:translate-y-[2.75rem] group-hover:translate-y-0 transition-all duration-300 mt-auto">
                                                    <header>
                                                        <div class="h4 line-clamp-1 md:mb-6 "><?= esc_html($review->post_title) ?></div>
                                                    </header>
                                                    <footer class="hidden md:flex items-center justify-between gap-2 caption mt-[0.625rem]">
                                                        <div class="flex-center gap-1">
                                                            <img src="<?= esc_url($userImageUrl) ?>" alt="تصویر <?= $user->display_name ?>" class="hidden md:block size-5 rounded-full skeleton " width="20" height="20">
                                                            <address class="not-italic"><?= esc_html($user->display_name) ?></address>
                                                        </div>
                                                        <time class="" datetime="<?= $review->post_date ?>"><?php esc_attr_e(date_i18n('d M Y - h:m', strtotime($review->post_date)))  ?></time>
                                                    </footer>
                                                </div>
                                            </a>
                                        </article>
                                    </li>
                                <?php endforeach;
                                ?>
                            </div>
                        </div>
                        <ul class="splide__pagination pt-2 pb-4 rounded-full overflow-hidden w-full flex-center gap-1"></ul>
                    </div>
                <?php endif ?>
            </section>
            <section class="md:pt-4">
                <h2 class="hidden md:block h2"><?= __('جدیدترین بررسی‌ها', 'gsm') ?></h2>
                <div class="list-container grid grid-cols-1 md:grid-cols-4 gap-2 md:gap-4 py-2 md:py-4">
                    <?= $_this->displayList($reviews) ?>
                </div>
                <nav class="pagination mt-4 md:mt-8" aria-label="Page navigation">
                    <?= $_this->displayPagination($reviews->max_num_pages, $page) ?>
                </nav>
            </section>
            <?php if ($seoBox): ?>
                <article class="w-full border-t pt-6 mt-12 border-gray-100 relative ">
                    <div class="h2 "><?= $seoBox['title'] ?></div>
                    <div class="text-justify body-sm pt-4 seo-content overflow-hidden transition-all"><?= $seoBox['content'] ?></div>
                    <span class="w-full absolute bottom-9 right-0 h-[4.5rem] hidden bg-show-more-cover"></span>
                    <button class="show-more-seo-box hidden gap-1 subtitle-sm text-primary-500 pt-2">
                        <?= __('نمایش', 'gsm') ?> <span class="close"><?= __('بیشتر', 'gsm') ?></span>
                        <i class="gsmicon-chevron-down-small text-lg transition-all"></i>
                    </button>
                </article>
            <?php endif ?>
        </main>
    </div>
</div>