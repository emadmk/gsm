<?php

namespace GSM\templates\reviews;

use GSM\templates\general\General;
use WP_Query;

class ReviewsList
{
    use General;
    protected $query;
    public function __construct() {}


    public function setQuery($query)
    {
        $this->query = $query;
        $this->ajaxActions();
    }

    public function ajaxActions()
    {
        if ($this->query == 'filter') {
            $data =  sanitizeNestedObject(json_decode(stripslashes($_POST['data'])));
            $page = intval($data['page']);
            $pinned = isset($data['pinned']) ? (array)$data['pinned'] : [];
            $pinned = array_map('intval', $pinned);
            $args = array(
                'post_type'         => 'review',
                'orderby'           => 'date',
                'order'             => 'DESC',
                'post_status'       => 'publish',
                'posts_per_page'    => 8,
                'paged'             => $page,
            );
            if (count($pinned)) {
                $args['post__not_in'] = $pinned;  
            }
            $filerList = new WP_Query($args);
            $list = $this->displayList($filerList);
            $pagination = $this->displayPagination($filerList->max_num_pages, $page);
            ajaxResponse(true, '', ['list' => $list, 'pagination' => $pagination]);
        }
    }
    
    public function displayList($reviews)
    {
        ob_start();
        get_template_part('templates/reviews/reviewsList', 'list', ['_this' => $this, 'reviews' => $reviews]);
        return  ob_get_clean();
    }

    public function displayContent()
    {
        get_template_part('templates/reviews/reviewsList', 'content', ['_this' => $this]);
    }
}
