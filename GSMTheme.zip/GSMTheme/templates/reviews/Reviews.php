<?php

namespace GSM\templates\reviews;

use DOMDocument;
use GSM\includes\Query;
use GSM\templates\general\General;

class Reviews
{
    use General;
    protected $query;
    public function __construct()
    {
        if (!is_admin()) {
            add_filter('the_content', [$this, 'addAnchorLinksToHeadings'], 10, 1);
            add_filter('the_content', [$this, 'addTableAfterFirstParagraph'], 11, 1);
            add_filter('the_content', [$this, 'addSuggestedPost'], 12, 1);
            add_filter('the_content', [$this, 'addBlockquoteIcon'], 13, 1);
            add_filter('the_content', [$this, 'addPoints'], 14, 1);
            add_filter('the_content', [$this, 'wrapImagesWithLightbox'], 15, 1);
        }
    }


    public function setQuery($query)
    {
        $this->query = $query;
        $this->ajaxActions();
    }

    public function ajaxActions()
    {
        if ($this->query == 'view') {
            $data = sanitizeNestedObject(json_decode(stripslashes($_POST['data'])));
            $postId = isset($data['id']) ? intval($data['id']) : 0;
            if ($postId <= 0) {
                ajaxResponse(false, 'شناسه پست نامعتبر است');
            }
            $count = intval(get_post_meta($postId, 'view_count', true));
            $authorId = get_post_field('post_author', $postId);
            $authorViewCount = get_user_meta($authorId, 'view_count', true) ?: 0;
            update_user_meta($authorId, 'view_count', $authorViewCount + 1);
            update_post_meta($postId, 'view_count', $count + 1);
            Query::updatePostViewCount($postId);
            ajaxResponse(true, 'بازدید با موفقیت ثبت گردید', [$count]);
        }
    }

    public function addTableAfterFirstParagraph($content)
    {
        // Check if the content contains any paragraphs  
        if (preg_match('/<p[^>]*>.*?<\/p>/i', $content)) {

            // Create your table HTML here  
            $tableHtml = $this->displayTableOfContent();

            // ob_start();
            // get_template_part('templates/reviews/reviews', 'ads', ['_this' => $this]);
            // $ads = ob_get_clean();

            // Find the position of the first paragraph  
            $firstParagraphPosition = strpos($content, '<p');

            // Check if a paragraph was found  
            if ($firstParagraphPosition !== false) {
                // Find the position of the closing </p> tag of the first paragraph  
                $endOfFirstParagraph = strpos($content, '</p>', $firstParagraphPosition);

                // Insert the table HTML after the first paragraph  
                if ($endOfFirstParagraph !== false) {
                    $endOfFirstParagraph += strlen('</p>'); // Move to after the closing tag  
                    return substr_replace($content, $tableHtml, $endOfFirstParagraph, 0);
                }
            }
        }
        return $content;
    }


    public function addPoints($content)
    {
        $pointsData =  get_field('points');
        if ($pointsData && is_array($pointsData['positive']) && count($pointsData['negative'])) {

            ob_start();
            get_template_part('templates/reviews/reviews', 'points', ['_this' => $this, 'pointsData' => $pointsData]);
            $pointsHtml =  ob_get_clean();
            $content = $this->prefixInsertAfterParagraph($pointsHtml, $pointsData['paragraph'], $content);
        }
        return $content;
    }

    public function wrapImagesWithLightbox($content)
    {
        $pattern = '/<img([^>]+)src="([^"]+)"([^>]*)>/i';

        $content = preg_replace_callback($pattern, function ($matches) {
            $imgAttributesBeforeSrc = $matches[1];
            $src = $matches[2];
            $imgAttributesAfterSrc = $matches[3];

            // Replace 's3' with 's5' in the src for the href
            $href = str_replace('s3.gsm.ir', 's5.gsm.ir', $src);

            return '<a class="glightbox" href="' . $href . '"><img' . $imgAttributesBeforeSrc . 'src="' . $src . '"' . $imgAttributesAfterSrc . '></a>';
        }, $content);

        return $content;
    }

    public function displayContent()
    {
        get_template_part('templates/reviews/reviews', 'content', ['_this' => $this]);
    }
}
