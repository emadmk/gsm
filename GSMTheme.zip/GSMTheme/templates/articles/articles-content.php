<?php

namespace GSM\templates\articles;

use GSM\includes\Api;
use GSM\includes\comment\Comment;
use WP_Query;

$_this = $args['_this'];
$faq = get_field('post_faq');
$jsDependency = ['jquery'];
if ($faq) {
    wp_enqueue_script('gsm-toggleTab', GSM_URL . '/assets/js/toggle-tab.js', ['jquery'], GSM_VERSION, true);
    $jsDependency[] = 'gsm-toggleTab';
}
wp_enqueue_script('gsm-articles', GSM_URL . '/assets/js/articles.js', $jsDependency, GSM_VERSION, true);

// post data
$responsibility = get_field('responsibility');
$api = get_field('apis', 'option');
$site_address = isset($api['site_address']) && !empty($api['site_address']) ? $api['site_address'] : 'https://www.gsm.ir';

// author data
$author = get_user_by('ID', get_the_author_meta('ID'));
$userImageId = get_field('profile-image', 'user_' . $author->ID);
$userLabel = !empty(get_field('author-label', 'user_' . $author->ID)) ? get_field('author-label', 'user_' . $author->ID) : __('نویسنده جی اس ام', 'gsm');
$shortDescription = get_field('short-description', 'user_' . $author->ID);
if (!empty($userImageId)) {
    $userImage = wp_get_attachment_image($userImageId, 'thumbnail', false,  ['class' => 'size-10 rounded-full object-cover shrink-0']);
} else {
    $userAvatar = get_avatar_url($author->ID);
    $userImage = '<img class="size-10 rounded-full object-cover shrink-0" src="' . $userAvatar . '">';
}
// brand data
$brandIds = get_post_meta(get_the_ID(), 'brands', true); // Assume this returns an array of IDs
$allBrands = Api::getGSMBrands();
$brandList = [];
if (!empty($allBrands->results) && is_array($brandIds)) {
    foreach ($allBrands->results as $item) {
        if (in_array($item->id, $brandIds)) {
            $brandList[] = $item;
        }
    }
}

$totalComment = get_comments_number();
$readingTime = get_post_meta(get_the_ID(), 'word_count', true);


// related post data

$tagIds = [];
$tagList = [];
foreach (get_the_tags() as $tag) {
    $tagIds[] = $tag->term_id;
    $tagList[$tag->term_taxonomy_id] = $tag->name;
}
$metaQuery = ['relation' => 'OR'];
if (is_array($brandIds)) {
    foreach ($brandIds as $brandId) {
        $metaQuery[] = [
            'key'     => 'brands',
            'value'   => '"' . intval($brandId) . '"',
            'compare' => 'LIKE',
        ];
    }
}
$relatedPostArgs = [
    'post_type'         => ['review', 'article'],
    'none_content'      => true,
    'orderby'           => 'rand',
    'order'             => 'DESC',
    'post_status'       => 'publish',
    'post__not_in'      => [get_the_ID()],
    'posts_per_page'    => 6,
    'meta_query'        => $metaQuery,
];

$relatedPosts = new WP_Query($relatedPostArgs);
$products = get_field('products');
?>
<div class="articles-container bg-gray-50 relative" data-articles-id="<?= esc_attr(get_the_ID()) ?>">
    <main class="container xl:max-w-screen-xl py-4 lg:px-10 grid grid-cols-1 md:grid-cols-[3fr_1fr] gap-4 md:gap-6">
        <article class="bg-white md:rounded-lg px-4 pb-4 md:p-6 shadow-post-box">
            <?php if (function_exists('rank_math_the_breadcrumbs')): ?>
                <div class="breadcrumb caption pb-4">
                    <?= rank_math_the_breadcrumbs();   ?>
                </div>
            <?php endif ?>
            <ul class="flex gap-2 flex-wrap">
                <?php foreach ($tagList as $tagId => $tag) : ?>
                    <li>
                        <a href="<?php echo esc_url(get_term_link($tagId)) ?>" class="caption flex-center h-[1.375rem] px-4 rounded-sm bg-primary-500/[0.08] text-primary-500" title="<?php esc_attr_e($tag) ?>"><?php esc_attr_e($tag) ?></a>
                    </li>
                <?php endforeach ?>
            </ul>
            <h1 class="h1 py-2"><?= get_the_title() ?></h1>
            <div class="flex flex-col md:flex-row md:justify-between gap-2">
                <ul class="grow flex items-center flex-wrap gap-2 caption text-gray-500 *:flex *:items-center *:gap-2">
                    <li>
                        <a href="#author-section" class="">
                            <?= __('نوشته', 'gsm') ?> <author class=""> <?= get_the_author() ?></author>
                        </a>
                    </li>
                    <li class="">
                        <span class="size-[0.125rem] rounded-full bg-gray-300"></span>
                        <time class="" datetime="<?= get_the_date('Y-m-d H:i:s') ?>"><?= __('منتشر شده در', 'gsm') ?> <?= esc_attr__(get_the_date('d M Y'));  ?></ti>
                    </li>

                    <?php if (get_the_modified_date()): ?>
                        <li class="">
                            <span class="size-[0.125rem] rounded-full bg-gray-300"></span>
                            <time class="" datetime="<?= get_the_modified_date('Y-m-d H:i:s') ?>"><?= __('بروزرسانی در', 'gsm') ?> <?= esc_attr__(get_the_modified_date('d M Y'));  ?></time>
                        </li>
                    <?php endif ?>
                    <?php if ($readingTime): ?>
                        <li class="">
                            <span class="size-[0.125rem] rounded-full bg-gray-300"></span>
                            <div class=""><?= __('مطالعه', 'gsm') ?> <?= ceil(intval($readingTime) / 200) ?> <?= __('دقیقه', 'gsm') ?></div>
                        </li>
                    <?php endif ?>
                </ul>
                <div class="mr-auto shrink-0 flex-center gap-4">
                    <div class=" flex-center gap-1 caption">
                        <i class="gsmicon-chat text-base"></i>
                        <?= $totalComment ?>
                    </div>
                    <i class="gsmicon-share text-base"></i>
                </div>
            </div>
            <div class="body-lg pt-4 pb-6"><?= get_the_excerpt() ?></div>
            <?php if (has_post_thumbnail()): ?>
                <?= get_the_post_thumbnail($post, 'full', ['class' => 'w-full object-contain']) ?>
            <?php endif ?>
            <?= $_this->displayProducts($products) ?>
            <div class="post-content pt-4 md:pt-6 overflow-hidden">
                <?php the_content() ?>
            </div>
            <?php if ($responsibility && $responsibility['display_responsibility']): ?>
                <div class="flex items-center gap-2 py-2 px-4 rounded-lg bg-orange-1 border border-orange-2 body-sm my-4 md:my-6">
                    <i class="gsmicon-alert-filled text-orange-3 text-xl"></i>
                    <?= $responsibility['content'] ?>
                </div>
            <?php endif ?>
            <?= $_this->displayFaq($faq) ?>
            </section>
            <?= $_this->displayAds("article_middle"); ?>
            <section id="author-section" class="bg-white md:rounded-lg px-4 py-6 md:p-6 shadow-post-box mt-4">
                <a href="<?= get_author_posts_url($author->ID) ?>" class="flex items-center gap-4 md:gap-6">
                    <?= $userImage ?>
                    <div class="space-y-2 md:spacey-4">
                        <author class="subtitle-sm"><?= $author->display_name ?></h3>
                            <div class="caption mt-2"><?= $userLabel ?></div>
                    </div>
                </a>
                <p class="text-justify mt-4 body-sm"><?= $shortDescription ?></p>
            </section>
            <?php
            if (comments_open()) {
                $comment = new Comment();
                echo $comment->generateCustomComment(get_the_ID());
            }
            ?>
            <?php if ($relatedPosts): ?>
                <div class="w-full bg-gray-100 my-4 md:my-6 h-[1px]"></div>
                <section class="bg-white md:rounded-lg shadow-post-box p-6" id="related-articles">
                    <div class="h3"><?= __('مطالب مرتبط', 'gsm') ?></div>
                    <ul class="divide-y divide-gray-100 w-full">
                        <?php if (count($relatedPosts->posts)) foreach ($relatedPosts->posts as $post):
                            setup_postdata($post);
                        ?>
                            <li class="w-full">
                                <article class="w-full flex gap-4 py-6 group article-card" target="_blank">
                                    <a href="<?= get_the_permalink() ?>" class="shrink-0">
                                        <?php if (has_post_thumbnail()): ?>
                                            <?= get_the_post_thumbnail($post, 'full', ['class' => 'skeleton size-14 md:size-24 rounded-[0.25rem] md:rounded-lg object-cover shrink-0', 'loading' => 'lazy']) ?>
                                        <?php else: ?>
                                            <div class="bg-gray-100 flex-center size-14 md:size-24 rounded-[0.25rem] md:rounded-lg object-cover shrink-0">
                                                <i class="gsmicon-image text-xl text-gray-300"></i>
                                            </div>
                                        <?php endif ?>
                                    </a>
                                    <div class="article-info grow md:py-2 group-hover:text-primary-500 *:transition-all *:duration-500 flex flex-col gap-2 justify-center">
                                        <header>
                                            <a href="<?= get_the_permalink() ?>" class="subtitle-lg line-clamp-2 "><?= get_the_title() ?></a>
                                        </header>
                                        <footer>
                                            <div class="body-sm line-clamp-4 md:line-clamp-2"><?= get_the_excerpt() ?></d>
                                        </footer>
                                    </div>
                                </article>
                            </li>
                        <?php
                            wp_reset_postdata();
                        endforeach ?>
                    </ul>
                </section>
            <?php endif ?>
        </article>
        <aside class="w-full h-full flex">
            <div id="sticky-sidebar" class="h-fit md:sticky md:bottom-0 w-full md:self-end md:pb-4">
                <?php if (count($brandList)): ?>
                    <section class="flex flex-col p-4  shadow-post-box bg-white gap-6 w-full rounded-lg">
                        <?php foreach ($brandList as $brand): ?>
                            <div class="flex gap-4 w-full">
                                <figure>
                                    <a href="<?= $site_address . "/brands/" . str_replace('', '-', strtolower($brand->title_en)) ?>">

                                        <img src="<?= $brand->logo  ?>" alt="" class="size-[4.5rem] object-contain shrink-0" width="72" height="72">
                                    </a>
                                </figure>
                                <div class="grow space-y-2">
                                    <a href="<?= $site_address . "/brands/" . str_replace('', '-', strtolower($brand->title_en)) ?>" class="">
                                        <div class="subtitle-lg"><?= $brand->title ?></div>
                                    </a>
                                    <div class="body-sm text-gray-400"><?= $brand->title_en ?></div>
                                </div>
                            </div>
                        <?php endforeach ?>
                    </section>
                <?php endif ?>
                <div class="main-sidebar-container w-full  space-y-4 md:space-y-6 <?= $brand ? 'mt-6' : '' ?>">
                    <?php if (is_active_sidebar('articles-single-sidebar')): ?>
                        <?php dynamic_sidebar('articles-single-sidebar'); ?>
                    <?php endif ?>
                </div>
            </div>
        </aside>
        <?= $_this->displayFooterAds("article_footer") ?>
    </main>
</div>
<?php
wp_reset_postdata();
