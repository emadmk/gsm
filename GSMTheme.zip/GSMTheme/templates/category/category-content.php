<?php

namespace GSM\templates\category;

use WP_Query;

$_this = $args['_this'];
