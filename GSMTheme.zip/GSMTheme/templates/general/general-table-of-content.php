<?php

$_this = $args['_this'];
global $contentHeadingList;
if (is_array($contentHeadingList) && count($contentHeadingList) > 0):?>
    <div class="table-of-content flex flex-col w-full mt-4 bg-gray-50 rounded-lg py-2 px-4">
        <div class="head-section text-lg-bold md:text-xl-bold flex items-center justify-between w-full py-4 z-10 cursor-pointer">
            <div class="flex-center gap-2 h4">
                <i class="gsmicon-menu-2 text-primary-500 text-xl"></i>
                <?= __('فهرست مطالب', 'gsm') ?>
            </div>
            <i class="gsmicon-chevron-bottom arrow text-xl transition-all duration-500"></i>
        </div>
        <ol class="content-section flex flex-col py-2 px-2 subtitle-sm border-t border-gray-100">
            <?php
            $i = 1;
            if (is_array($contentHeadingList)) foreach ($contentHeadingList as $heading) {
                echo $_this->displayNestedHeading($heading, 1, $i);
                $i++;
            }
            ?>

        </ol>
    </div>
<?php endif; ?>