<?php

namespace GSM\templates\general;

$_this = $args['_this'];
$maxNumPages = $args['maxNumPages'];
$page = $args['page'];
$paginationOffset = $args['paginationOffset'];

if ($maxNumPages > 1): ?>
    <ul class="gsm-pagination flex-center gap-2 w-full">
        <!-- Previous Page Button -->
        <li class="page-item flex-center cursor-pointer transition-all gap-1 <?= $page == 1 ? 'text-gray-300' : '' ?>" data-page="<?= $page - 1 ?>" aria-label="back">
            <i class="gsmicon-chevron-right"></i>
            <p class="hidden md:block"><?= __('قبلی', 'gsm') ?></p>
        </li>

        <!-- Page Numbers -->
        <ol class="page-numbers flex flex-wrap justify-center gap-2">
            <?php
            // First Page
            if ($page > $paginationOffset + 1): ?>
                <li class="page-item size-8 md:size-10 rounded-lg flex-center flex cursor-pointer transition-all <?= $page == 1 ? 'bg-primary-500 text-white selected' : 'hover:bg-primary-500 hover:text-white'; ?>" data-page="1">1</li>
            <?php endif;

            // Leading Ellipsis
            if ($page > $paginationOffset + 2): ?>
                <li class="page-item size-8 md:size-10 rounded-lg flex-center flex transition-all">...</li>
            <?php endif;

            // Dynamic Range of Pages
            for ($i = max(1, $page - $paginationOffset); $i <= min($maxNumPages, $page + $paginationOffset); $i++): ?>
                <li class="page-item size-8 md:size-10 rounded-lg flex-center flex cursor-pointer transition-all <?= $i == $page ? 'bg-primary-500 text-white selected' : 'hover:bg-primary-500 hover:text-white'; ?>" data-page="<?= $i ?>"><?= $i ?></li>
            <?php endfor;

            // Trailing Ellipsis
            if ($page < $maxNumPages - $paginationOffset - 1): ?>
                <li class="page-item size-8 md:size-10 rounded-lg flex-center flex transition-all">...</li>
            <?php endif;

            // Last Page
            if ($page < $maxNumPages - $paginationOffset): ?>
                <li class="page-item size-8 md:size-10 rounded-lg flex-center flex cursor-pointer transition-all <?= $page == $maxNumPages ? 'bg-primary-500 text-white selected' : 'hover:bg-primary-500 hover:text-white'; ?>" data-page="<?= $maxNumPages ?>"><?= $maxNumPages ?></li>
            <?php endif; ?>
        </ol>

        <!-- Next Page Button -->
        <li class="page-item flex-center cursor-pointer transition-all gap-1 <?= $page == $maxNumPages ? 'text-gray-300' : '' ?>" data-page="<?= $page + 1 ?>" aria-label="next">
            <p class="hidden md:block"><?= __('بعدی', 'gsm') ?></p>
            <i class="gsmicon-chevron-right rotate-180"></i>
        </li>

    </ul>
<?php endif; ?>