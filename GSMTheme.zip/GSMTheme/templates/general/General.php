<?php

namespace GSM\templates\general;

use DOMDocument;

if (!defined('ABSPATH')) {
    exit;
}

trait General
{

    public function addAnchorLinksToHeadings($content)
    {
        global $contentHeadingList;
        $dom = new DOMDocument('1.0', 'UTF-8');

        libxml_use_internal_errors(true);
        $dom->loadHTML('<?xml encoding="utf-8" ?>' .$content, LIBXML_HTML_NOIMPLIED | LIBXML_HTML_NODEFDTD);
        libxml_clear_errors();

        $this->wrapTablesWithDiv($dom);

        $contentHeadingList = [];
        $stack = [];

        foreach ($dom->getElementsByTagName('*') as $element) {
            if (preg_match('/^h\d$/i', $element->nodeName)) {
                $level = (int) substr($element->nodeName, 1);
                $headingText = trim($element->nodeValue);
                $anchorId = urlencode(strtolower(str_replace(' ', '-', $headingText)));
                $element->setAttribute('id', $anchorId);
                $anchorLink = '#' . $anchorId;

                // Remove elements that are at a higher or equal level
                while (!empty($stack) && end($stack)['level'] >= $level) {
                    array_pop($stack);
                }

                $headingItem = [
                    "text" => $headingText,
                    "link" => $anchorLink,
                    "index" => $level
                ];

                if (empty($stack)) {
                    // Top-level heading
                    $contentHeadingList[] = $headingItem;
                    $stack[] = ["level" => $level, "ref" => &$contentHeadingList[count($contentHeadingList) - 1]];
                } else {
                    // Nested heading: Attach to the correct parent
                    $parent = &$stack[count($stack) - 1]['ref'];

                    // Ensure the parent has children
                    if (!isset($parent['children'])) {
                        $parent['children'] = [];
                    }

                    $parent['children'][] = $headingItem;
                    $stack[] = ["level" => $level, "ref" => &$parent['children'][count($parent['children']) - 1]];
                }
            }
        }

        $html =  $dom->saveHTML();
        return $this->decodeNumericEntitiesPreservingReserved($html);
    }

    	/**
	 * Convert numeric HTML entities to UTF-8, but keep reserved entities like &lt; &gt; &amp; &quot; &apos;
	 */
	private function decodeNumericEntitiesPreservingReserved($html)
	{
		// Decimal numeric entities
		$html = preg_replace_callback('/&#(\d+);/', function ($m) {
			$code = (int) $m[1];
			// Keep reserved HTML entities encoded
			if (in_array($code, [34, 38, 39, 60, 62], true)) {
				return $m[0];
			}
			return mb_convert_encoding($m[0], 'UTF-8', 'HTML-ENTITIES');
		}, $html);

		// Hex numeric entities
		$html = preg_replace_callback('/&#x([0-9a-fA-F]+);/', function ($m) {
			$code = hexdec($m[1]);
			if (in_array($code, [34, 38, 39, 60, 62], true)) {
				return $m[0];
			}
			return mb_convert_encoding($m[0], 'UTF-8', 'HTML-ENTITIES');
		}, $html);

		return $html;
	}

    /**
     * Wraps table elements with a div that has the class "table-wrapper"
     * 
     * @param DOMDocument $dom The DOM document containing the tables
     * @return void
     */
    protected function wrapTablesWithDiv($dom)
    {
        $tables = $dom->getElementsByTagName('table');

        // Convert to array to avoid live node list issues
        $tablesArray = [];
        foreach ($tables as $table) {
            $tablesArray[] = $table;
        }

        foreach ($tablesArray as $table) {
            // Create wrapper div
            $wrapper = $dom->createElement('div');
            $wrapper->setAttribute('class', 'table-wrapper thin-scrollbar');

            // Get table's parent node
            $parent = $table->parentNode;

            // Insert wrapper before table
            $parent->insertBefore($wrapper, $table);

            // Move table inside wrapper
            $wrapper->appendChild($table);
        }
    }

    public function addBlockquoteIcon($content)
    {

        if (preg_match('/<blockquote>/i', $content)) {
            $blockquotes = explode('</blockquote>', $content);

            foreach ($blockquotes as $index => $blockquote) {
                if ($index < count($blockquotes) - 1)
                    $blockquotes[$index] .= '<i class="gsmicon-quote"></i></blockquote>';
            }
            return implode('', $blockquotes);
        }
        return $content;
    }

    public function prefixInsertAfterParagraph($insertion, $paragraph_id, $content)
    {
        $closing_p = '</p>';
        $paragraphs = explode($closing_p, $content);
        foreach ($paragraphs as $index => $paragraph) {
            if (trim($paragraph)) {
                $paragraphs[$index] .= $closing_p;
            }
            if ($paragraph_id == $index + 1) {
                $paragraphs[$index] .= $insertion;
            }
        }
        return implode('', $paragraphs);
    }

    public function addTableBeforeFirstHeading($content)
    {
        // Check if the content contains any headings
        if (preg_match('/<h\d/i', $content)) {
            preg_match_all('/<h\d/i', $content, $matches);
            $tableHtml = $this->displayTableOfContent();

            // Find the position of the first heading
            $hNumber = (int) substr($matches[0][0], 2, 1);
            $firstHeadingPosition = strpos($content, '<h' . $hNumber);

            // Insert the table HTML before the first heading
            return substr_replace($content, $tableHtml, $firstHeadingPosition, 0);
        }
        return $content;
    }

    public function addSuggestedPost($content)
    {
        $suggestedPosts =  get_field('post_suggested_posts');
        if ($suggestedPosts && is_array($suggestedPosts) && count($suggestedPosts)) {
            foreach ($suggestedPosts as $suggested) {
                ob_start();
                get_template_part('templates/general/general', 'suggested-post', ['_this' => $this,'suggestedPost'=>$suggested['post']]);
                $suggestedPostHtml =  ob_get_clean();
                $content = $this->prefixInsertAfterParagraph($suggestedPostHtml,$suggested['paragraph'],$content);
            }
        }
        return $content;
    }

    public function displayAds($zone){
        ob_start();
            get_template_part('templates/general/general', 'ads', ['_this' => $this,'zone'=>$zone]);
            $ads = ob_get_clean();
        return $ads;
    }


    public function displayNestedHeading($heading, $level, $number)
    {

        ob_start();
        get_template_part('templates/general/general', 'table-of-content-item', ['_this' => $this, 'heading' => $heading, 'level' => $level, 'number' => $number]);
        return ob_get_clean();
    }

    public function displayTableOfContent()
    {
        ob_start();
        get_template_part('templates/general/general', 'table-of-content', ['_this' => $this,]);
        return ob_get_clean();
    }

    public function displayFooterAds($zone)
    {
        ob_start();
        get_template_part('templates/general/general', 'footer-ads', ['_this' => $this, 'zone' => $zone]);
        return ob_get_clean();
    }

    public function displayProducts($products)
    {
        ob_start();
        get_template_part('templates/general/general', 'product', ['_this' => $this, 'products' => $products]);
        return  ob_get_clean();
    }

    public function displayFaq($faq)
    {
        get_template_part('templates/general/general', 'faq', ['_this' => $this, 'faq' => $faq]);
    }

    public function displayPagination($maxNumPages,$page = 1,$paginationOffset = 3)
    {
        ob_start();
        get_template_part('templates/general/general', 'pagination', ['_this' => $this, 'page' => $page, 'paginationOffset' => $paginationOffset, 'maxNumPages' => $maxNumPages]);
        return  ob_get_clean();
    }
}
