<?php

$faq = $args['faq'];

if ($faq && !empty($faq)):
    $flags = (JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE);
    $schema = [
        '@context' => 'https://schema.org',
        '@type' => 'FAQPage',
        'mainEntity' => [],
    ];
    foreach ($faq as $item) {
        $schema['mainEntity'][] = [
            '@type' => 'Question',
            'name' => $item['title'],
            'acceptedAnswer' => [
                '@type' => 'Answer',
                'text' => $item['content'],
            ],
        ];
    }

    $output = wp_json_encode($schema, $flags);
    $output = \str_replace("\n", \PHP_EOL . "\t", $output);
    echo '<script type="application/ld+json" class="gsm-faq-schema">' . $output . '</script>';
?>
    <h2 class="h3 py-4 md:py-6"><?= __('سوالات متداول', 'gsm') ?></h2>
    <div class="faq-section space-y-2">
        <?php foreach ($faq as $item): ?>
            <div class="w-full border-t border-gray-100 py-6 px-2 md:px-8 bg-gray-50 rounded-lg">
                <div class="faq-section-item w-full flex items-center gap-2 cursor-pointer  ">
                    <div class="plus-container *:bg-primary-500 size-4 flex-center">
                        <span class="w-4 h-[1.5px]"></span>
                        <span class="w-4 h-[1.5px] plus transition-all duration-300 absolute rotate-90 "></span>
                    </div>
                    <h3 class=" grow body-sm transition-all"><?= $item['title'] ?></h3>
                </div>
                <div class="faq-section-content hidden text-justify pt-6">
                    <?= $item['content'] ?>
                </div>
            </div>
        <?php endforeach; ?>
    </div>
<?php endif; ?>