<?php

$zone = $args['zone'];
?>
    <section class="ads-container">
        <div class="ads-title subtitle-lg text-gray-300 pb-2 pt-4 md:pt-6 flex items-center justify-between">
            <?= __('تبلیغات', 'gsm') ?>
            <i class="gsmicon-cross-large size-6 rounded-full bg-black/[0.24] text-white flex-center close-ads cursor-pointer"></i>
        </div>
        <div class="ads-content w-full cursor-pointer" data-zone="<?= $zone ?>">
            <div class="aspect-[4/1] md:aspect-[9.3/1]  rounded-lg skeleton"></div>
        </div>
    </section>
