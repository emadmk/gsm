<?php
$zone = $args['zone'];
?>
<section class="ads-container md:hidden fixed bottom-0 left-0 right-0 w-full z-50 ">
    <div class="relative w-full">
        <div class="ads-title subtitle-lg text-gray-300 flex items-center justify-between">
            <i class="gsmicon-cross-large size-6 absolute top-0 left-0 bg-black/[0.24] text-white flex-center close-ads cursor-pointer mr-auto"></i>
        </div>
        <div class="ads-content w-full cursor-pointer" data-zone="<?= $zone ?>">
        </div>
    </div>
</section>