<?php

use GSM\includes\Api;

$products = $args['products'];
$api = get_field('apis', 'option');
$siteAddress = isset($api['site_address']) && !empty($api['site_address']) ? $api['site_address'] : 'https://www.gsm.ir';

if (is_array($products)):
?>
    <section class="product-container my-4 md:my-6 <?= count($products) > 1 ? 'grid grid-cols-1 md:grid-cols-2 gap-4' : '' ?>">
        <?php foreach ($products as $productId):
            $product = Api::getGSMProduct($productId);
        ?>
            <a href="<?= $siteAddress . '/product' . '/gp-' . $product->id . '/' . $product->slug ?>" class="product-item w-full flex items-center gap-2 px-4 py-3 bg-primary-500/[0.08] border border-primary-500/[0.16] rounded-lg hover:bg-primary-500/[0.16] transition-all duration-300 cursor-pointer" target="_blank">
                <?php if ($product->images[0]->url): ?>
                    <img src="<?= $product->images[0]->url ?>" alt="<?= __('تصویر', 'gsm') ?> <?= $product->title ?>" class="size-16 object-contain shrink-0 skeleton" width="64" height="64" loading="lazy">
                <?php else: ?>
                    <div class="bg-gray-100 flex-center size-16 shrink-0">
                        <i class="gsmicon-image text-xl text-gray-300"></i>
                    </div>
                <?php endif ?>
                <div class="flex flex-col gap-1 grow">
                    <h3 class="text-sm font-bold line-clamp-2"><?= $product->title ?></h3>
                </div>
            </a>
        <?php endforeach; ?>
    </section>
<?php endif; ?>