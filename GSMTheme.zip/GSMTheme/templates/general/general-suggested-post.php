<?php

$_this = $args['_this'];
$suggestedPost = $args['suggestedPost'];
setup_postdata($suggestedPost);
$post = $suggestedPost;

?>
<div class="suggested-post-item w-full bg-gray-20 rounded-lg p-4 flex items-center border border-gray-100 gap-4">
    <a class="shrink-0" href="<?= get_permalink() ?>">
        <figure>
            <?php if (has_post_thumbnail()): ?>
                <?= get_the_post_thumbnail($post, 'full', ['class' => 'skeleton h-16 w-[5.75rem] object-cover  rounded-md', 'loading' => 'lazy']) ?>
            <?php else: ?>
                <div class="bg-gray-100 flex-center h-16 w-[5.75rem] object-cover shrink-0 rounded-md">
                    <i class="gsmicon-image text-xl text-gray-300"></i>
                </div>
            <?php endif ?>
        </figure>
    </a>
    <div class="grow space-y-1">
        <div class="text-primary-500/[0.64] overline-font"><?= __('پیشنهاد خواندنی', 'gsm') ?></div>
        <a href="<?= get_permalink() ?>" class="subtitle-lg">
            <div class=""><?= get_the_title() ?></div>
        </a>
    </div>
</div>
<?php
wp_reset_postdata();
