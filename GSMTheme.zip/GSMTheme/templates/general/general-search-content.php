<?php

namespace GSM\templates\general;

$_this = $args['_this'];
$posts = $args['posts'];
$products = $args['products'];
$search = $args['search'];
?>
<div class="search-result w-full flex flex-col h-full grow md:min-h-40">
    <?php if (!empty($posts) || !empty($products)): ?>
        <div class="search-tab-items  caption flex gap-2 flex-wrap text-primary-500 md:py-5">
            <div class="search-tab-item bg-primary-500 text-white  border border-primary-500 h-8 rounded-full flex-center px-7 cursor-pointer" data-tab='all'><?= __('همه نتایج', 'gsm') ?></div>
            <?php if ($products && !empty($products)): ?>
                <div class="search-tab-item border border-primary-500 h-8 rounded-full flex-center px-7 cursor-pointer" data-tab='product'><?= __('محصولات', 'gsm') ?></div>
            <?php endif ?>
            <?php if ($posts && !empty($posts)): ?>
                <div class="search-tab-item  h-8 rounded-full flex-center px-7 cursor-pointer border border-primary-500" data-tab='post'><?= __('مطالب', 'gsm') ?></div>
            <?php endif ?>
        </div>
        <?php if ($products && !empty($products)):
            $api = get_field('apis', 'option');
            $siteAddress = isset($api['site_address']) && !empty($api['site_address']) ? $api['site_address'] : 'https://www.gsm.ir';

        ?>
            <div class="search-tab-content search-tab-product w-full space-y-4  text-gray-500 subtitle-sm py-4 lg:p-4 grow">
                <h3 class="flex items-center gap-2 text-primary-500 caption ">
                    <i class="gsmicon-mobile-fill text-lg"></i>
                    <?= __('محصولات', 'gsm') ?>
                </h3>
                <?php foreach ($products as $key => $product):
                    if ($key > 4) break;
                ?>
                    <a href="<?= $siteAddress . '/product' . '/gp-' . $product->id . '/' . $product->slug ?>" class="flex items-center gap-2 w-full hover:text-primary-500 transition-all ">
                        <img src="<?= $product->image ?>" alt="<?= __('تصویر', 'gsm') ?> <?= $product->title ?>" class="size-14 rounded-[0.25rem] object-contain shrink-0 skeleton" width="48" height="48" loading="lazy">
                        <?= esc_html($product->title) ?>
                    </a>
                <?php endforeach ?>
            </div>
        <?php endif ?>
        <?php if ($posts && !empty($posts)): ?>
            <div class="search-tab-content search-tab-post w-full space-y-4 text-gray-500 subtitle-sm py-4 lg:p-4 grow">
                <h3 class="flex items-center gap-2 text-primary-500 caption">
                    <i class="gsmicon-article text-lg"></i>
                    <?= __('دسته مطالب', 'gsm') ?>
                </h3>
                <?php foreach ($posts as $post): ?>
                    <a href="<?= get_permalink($post->ID) ?>" class="flex items-center gap-2 w-full hover:text-primary-500 transition-all">
                        <?php if (has_post_thumbnail($post)): ?>
                            <?= get_the_post_thumbnail($post->ID, 'thumbnail', ['class' => ' skeleton size-14 rounded-[0.25rem] object-contain shrink-0']) ?>
                        <?php else: ?>
                            <div class="size-14 rounded-[0.25rem] bg-gray-100 flex-center shrink-0">
                                <i class="gsmicon-image text-xl text-gray-300"></i>
                            </div>
                        <?php endif ?>
                        <?= esc_html($post->post_title) ?>
                    </a>
                <?php endforeach ?>
            </div>
        <?php endif ?>

    <?php else: ?>
        <div class="empty-result-container h3 py-5 text-center w-full h-full flex-center">
            <?= __('نتیجه ی یافت نشد', 'gsm') ?>
        </div>
    <?php endif ?>
</div>
<a href="<?= home_url() . '/?s=' . $search ?>" class="w-full flex-center py-4 subtitle-lg text-primary-500 border-t border-gray-100 -mx-4">مشاهده همه نتایج </a>