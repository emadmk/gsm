<?php
$_this = $args['_this'];
$heading = $args['heading'];
$level = $args['level'];
$number = $args['number'];
$i = 1;

if (isset($heading['link'])): ?>
    <li class="pr-3 flex flex-col gap-2 body-sm py-2" style="padding-right:<?= $level>1?$level:0 ?>rem">
        <a href="<?= $heading['link'] ?>" class="flex table-of-content-<?= $level ?>">
            <div class="flex items-center gap-2">
                <?php if (0): ?>
                    <span><?= $number . '.' ?></span>
                <?php endif ?>
                <?= $heading['text'] ?>
            </div>
        </a>
    </li>

<?php endif;
// Check if there are children
if (isset($heading['children']) && is_array($heading['children'])):
?>
    <ol class="flex flex-col">
        <?php foreach ($heading['children'] as $key => $child): ?>
            <?= $_this->displayNestedHeading($child, $level + 1, $i  . '.' . $number) ?>
            <?php $i++; ?>
        <?php endforeach; ?>
    </ol>
<?php endif; ?>