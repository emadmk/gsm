<?php

namespace GSM\templates\general;

use DOMDocument;
use GSM\includes\Api;
use GSM\includes\Query;
use GSM\templates\general\General;

class GeneralAction
{
    protected $query;
    public function __construct() {}


    public function setQuery($query)
    {
        $this->query = $query;
        $this->ajaxActions();
    }

    public function ajaxActions()
    {
        if ($this->query == 'view') {
            $data = sanitizeNestedObject(json_decode(stripslashes($_POST['data'])));
            $postId = isset($data['id']) ? intval($data['id']) : 0;
            if ($postId <= 0) {
                ajaxResponse(false, 'شناسه پست نامعتبر است');
            }
            $count = intval(get_post_meta($postId, 'view_count', true));
            $authorId = get_post_field('post_author', $postId);
            $authorViewCount = get_user_meta($authorId, 'view_count', true) ?: 0;
            update_user_meta($authorId, 'view_count', $authorViewCount + 1);
            update_post_meta($postId, 'view_count', $count + 1);
            Query::updatePostViewCount($postId);
            ajaxResponse(true, 'بازدید با موفقیت ثبت گردید', [$count]);
        } elseif ($this->query == 'search') {
            $data = sanitizeNestedObject(json_decode(stripslashes($_POST['data'])));
            $search = isset($data['search']) ? sanitize_text_field($data['search']) : '';
            $posts = Query::getSearchPost($search);
            $products = Api::getGSMProducts(['search' => $search]);
            $result = $this->searchResultContent($posts, $products->data, $search);
            ajaxResponse(true, 'جستجو با موفقیت انجام شد', [
                'result' => $result
            ]);
        } elseif ($this->query == 'logout') {
            if (!is_user_logged_in()) {
                ajaxResponse(false, __('شما لاگین نمی باشد', 'bitfa'));
            }
            wp_logout();
            ajaxResponse(true, __("شما با موفقیت از حساب کاربری خود خارج شدید", 'bitfa'));
        }
    }

    public function searchResultContent($posts, $products,$search)
    {
        ob_start();
        get_template_part('templates/general/general', 'search-content', ['class' => $this, 'posts' => $posts, 'products' => $products,'search'=>$search]);
        return ob_get_clean();
    }
}
