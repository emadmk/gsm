<?php

namespace GSM\templates\terms;

$faq = get_field('terms_faq');
$endSection = get_field('end-section');
wp_enqueue_script('gsm-toggleTab', GSM_URL . '/assets/js/toggle-tab.js', ['jquery'], GSM_VERSION, true);
wp_enqueue_script('gsm-terms', GSM_URL . '/assets/js/terms.js', ['jquery', 'gsm-toggleTab'], GSM_VERSION, true);

?>

<div class="terms-container relative bg-gray-50 md:p-4">
    <div class="w-full h-full bg-white md:rounded-2xl px-4 md:px-0">
        <main class="container xl:max-w-screen-xl lg:px-10 pb-[4.5rem]">
            <?php if (function_exists('rank_math_the_breadcrumbs')): ?>
                <div class="breadcrumb pt-5 md:pt-8 caption ">
                    <?= rank_math_the_breadcrumbs(); ?>
                </div>
            <?php endif ?>
            <h1 class="h1 pt-6 md:pt-8 bg-white"><?= get_the_title() ?></h1>
            <p class="body-lg text-justify mt-4"><?= get_the_content() ?></p>
            <div class="faq-section py-8">
                <?php if ($faq && count($faq)) foreach ($faq as $item): ?>
                    <div class="w-full border-t border-gray-100 py-6 px-2 md:px-8">
                        <div class="faq-section-item w-full flex items-center justify-between cursor-pointer  ">
                            <h4 class=" grow h4 "><?= $item['title'] ?></h4>
                            <div class="plus-container *:bg-primary-500 size-4 flex-center">
                                <span class="w-4 h-[1.5px]"></span>
                                <span class="w-4 h-[1.5px] plus transition-all duration-300 absolute rotate-90 "></span>
                            </div>
                        </div>
                        <div class="faq-section-content hidden text-justify pt-6">
                            <?= $item['content'] ?>
                        </div>
                    </div>
                <?php endforeach; ?>
            </div>
            <div class="px-4 py-6 md:p-8 subtitle-sm w-full flex flex-col gap-2 bg-primary-500/[0.08] rounded-2xl">
                <?php if ($endSection && count($endSection)) foreach ($endSection as $item): ?>
                    <P><?= $item['item'] ?></P>
                <?php endforeach; ?>
                <a href="mailto:info@gsm.ir" class="mr-auto text-primary-700 subtitle-lg mt-4">info@gsm.ir</a>
            </div>

        </main>
    </div>
</div>