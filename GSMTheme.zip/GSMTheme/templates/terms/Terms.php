<?php
namespace GSM\templates\terms;
use Collator;
class Terms
{
    protected $query;
    public function __construct()
    {
    }


    public function setQuery($query)
    {
        $this->query = $query;
        $this->ajaxActions();
    }

    public function ajaxActions()
    {
        if ($this->query == 'get-sub-category') {
            
        }
    }

    public function displayContent()
    {
        get_template_part('templates/terms/terms', 'content', ['class' => $this]);
    }
}
