<?php

namespace GSM\templates\page404;

?>
<div class="error-container relative bg-white md:bg-gray-50 md:p-4">
    <div class="w-full h-full md:bg-white md:rounded-2xl relative overflow-hidden">
        <img src="<?= GSM_URL . '/assets/img/404-pattern.svg' ?>" class="object-cover bg-repeat absolute inset-0 z-0 w-full h-full">
        <img src="<?= GSM_URL . '/assets/img/404-logo.svg' ?>" class="object-contain h-14 md:h-32 z-0 absolute bottom-10 left-6 md:left-10">
        <div class="size-44 md:size-60 rounded-full bg-primary-500/[0.16] absolute -top-8  -right-28 md:top-0"></div>
        <main class="container xl:max-w-screen-xl lg:px-10 w-full h-[calc(100dvh_-_3.5rem)] flex-center flex-col relative z-10">
            <h1 class="text-[5.5rem] md:text-[12.125rem] text-[#EAE7FF] font-bold text-shadow">404</h1>
            <div class="h2 "><?= __('صفحه مورد نظر یافت نشد', 'gsm') ?></div>
            <p class="body-lg text-center mt-2 md:mt-4 mb-10"><?= __('متأسفانه صفحه موردنظر شما پیدا نشد. لطفاً آدرس را دوباره بررسی کنید یا به صفحه اصلی بازگردید.', 'gsm') ?></p>
        </main>
    </div>
</div>