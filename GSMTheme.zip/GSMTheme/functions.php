<?php

namespace GSM;

use GSM\includes\Enqueue;
use GSM\includes\SetupTheme;
use GSM\includes\nav\Navigation;
use GSM\includes\comment\Comment;
use GSM\includes\Rewrite;
use GSM\includes\Assign;
use GSM\includes\ACF;
use GSM\includes\Activation;
use GSM\includes\admin\Admin;
use GSM\includes\components\Components;
use GSM\includes\Cron;
use GSM\includes\Init;
use GSM\includes\SEO;
use GSM\includes\Security;
use GSM\includes\shortcodes\Shortcodes;

if (!defined('GSM_VERSION')) {
    define('GSM_VERSION', wp_get_theme()->get('Version'));
}

if (!defined('GSM_DIR')) {
    define('GSM_DIR', get_template_directory());
}

if (!defined('TEMPLATE_DIR')) {
    define('TEMPLATE_DIR', GSM_DIR . '/templates');
}

if (!defined('GSM_URL')) {
    define('GSM_URL', get_template_directory_uri());
}

include_once GSM_DIR . '/vendor/autoload.php';


class GSM
{
    public static $activatedPlugin;
    function __construct()
    {
        self::$activatedPlugin = get_option('active_plugins');
        $this->setHooks();
    }

    public function setHooks()
    {
        # ======================================================
        # Theme init ===========================================
        # ======================================================
        $init = new Init();
        add_action('init', [$init, 'registerPostTypeAndTaxonomy']);
        add_action('widgets_init', [$init, 'registerSidebarAndWidgets']);
        // replace image src
        // add_filter('wp_get_attachment_image_src',  [$init,'replaceImageSrcInAttachment'], 10, 4);
        // add_filter('the_content', [$init,'replaceImageSrcInContent']);





        # ======================================================
        #  SEO & Schema ========================================
        # ======================================================
        $SEO = new SEO();
        add_filter('rank_math/frontend/breadcrumb/args', [$SEO, 'addCustomSeparator']);
        add_filter('rank_math/frontend/breadcrumb/items', [$SEO, 'changeBreadcrumbItems'], 10, 2);
        add_filter( 'do_rocket_generate_caching_files', '__return_false' );


        # ======================================================
        #  Security =============================================
        # ======================================================
        // $security = new Security();
        // add_filter('rest_authentication_errors', [$security, 'disableRestApi']);
        // add_filter('xmlrpc_enabled', [$security, 'disableXmlRpc']);
        // add_action('init', [$security, 'preventPhpExecutionInUploads']);
        // add_action('send_headers', [$security, 'sendBasicSecurityHeaders']);

        # ======================================================
        # setup theme ==========================================
        # ======================================================
        $setupTheme = new SetupTheme();
        add_action('after_setup_theme', [$setupTheme, 'init']);
        add_action('after_setup_theme', [$setupTheme, 'textdomainHandler']);

        # ======================================================
        # rewrite rules ========================================
        # ======================================================
        $rewrite = new Rewrite();
        add_action('init',  [$rewrite, 'addRewriteRules']);
        add_filter('query_vars', [$rewrite, 'addQueryVars']);
        add_action('template_redirect', [$rewrite, 'templateRedirectHandler']);
        add_filter('post_type_link', [$rewrite, 'changePostTypePermalink'], 10, 2);
        add_filter('term_link', [$rewrite, 'customTermLink'], 10, 3);
        // Handle Strapi ID in URLs
        add_filter('request', [$rewrite, 'handle_strapi_id_request']);
        add_action('template_redirect', [$rewrite, 'maybe_redirect_to_pretty_permalink'],11);


        # ======================================================
        #  enqueue and dequeue css and js ======================
        # ======================================================
        $enqueue = new Enqueue();
        add_action('wp_enqueue_scripts', [$enqueue, 'enqueueScripts'], 1);
        add_action('wp_default_scripts', [$enqueue, 'removeJQueryMigrate']);
        add_action('admin_enqueue_scripts', [$enqueue, 'adminEnqueueScripts']);
        // add_action('admin_menu', [$enqueue, 'addAdminMenu']);


        # ======================================================
        #  assign to header and footer =========================
        # ======================================================
        $assign = new Assign();
        add_action('wp_head', [$assign, 'addToHeader'], 1);
        add_action('wp_footer', [$assign, 'addToFooter']);
        add_action('wp_body_open', [$assign, 'addToBody'], 1);

        # ======================================================
        #  MENU Navigation =====================================
        # ======================================================
        if (is_admin()) {
            $navigation = new Navigation();
            add_action('wp_nav_menu_item_custom_fields',  [$navigation, 'menuCustomFields'], 10, 5);
            add_action('wp_update_nav_menu_item',  [$navigation, 'navUpdate'], 10, 2);
        }

        # ======================================================
        #  Components ==========================================
        # ======================================================
        global $GSMComponents;
        $GSMComponents = new Components();

        # ======================================================
        #  shortcode ===========================================
        # ======================================================
        $shortcode = new Shortcodes();
        add_shortcode('gsm_image', [$shortcode, 'customSingleImage']);
        add_shortcode('gsm_image_grid', [$shortcode, 'customGridImage']);
        add_shortcode('gsm_highlighter', [$shortcode, 'customHighlighter']);



        # ======================================================
        #  Admin ===============================================
        # ======================================================
        $admin = new Admin();
        add_action('save_post',  [$admin, 'savePostExtraData']);


        # ======================================================
        #  Custom Comment ======================================
        # ======================================================
        $comment = new Comment();
        add_action('wp_insert_comment', [$comment, 'addRoleForAdminCommentReplay'], 10, 2);
        add_action('haal_custom_comment', [$comment, 'generateCustomComment'], 10, 1);

        # =======================================================
        #  Advance Custom Field =================================
        # =======================================================
        if (class_exists('ACF')) {
            $ACF = new ACF();
        }


        # =======================================================
        #  Activation Action ====================================
        # =======================================================
        $activation = new Activation();
        add_action('after_switch_theme', [$activation, 'generateNotificationTable']);
        add_action('after_switch_theme', [$activation, 'generateViewTables']);

        # =======================================================
        #  Cron Action ==========================================
        # =======================================================
        $cron = new Cron();
    }
}

$gsmGame = new GSM();
