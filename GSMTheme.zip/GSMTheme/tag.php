<?php

namespace GSM;

use GSM\templates\tag\Tag;

get_header();
$term = get_term_by( "term_id", get_queried_object()->term_id,  'post_tag');

$tag = new Tag($term);
$tag->displayContent();
get_footer();