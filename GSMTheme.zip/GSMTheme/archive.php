<?php

namespace GSM;

use GSM\templates\articles\ArticlesList;
use GSM\templates\news\NewsList;
use GSM\templates\reviews\ReviewsList;

get_header();
if (get_post_type() == 'news') {
    $news = new NewsList();
    $news->displayContent();
}else if (get_post_type() == 'article'){
    $articles = new ArticlesList();
    $articles->displayContent();
}else if (get_post_type() == 'review'){
    $reviews = new ReviewsList();
    $reviews->displayContent();
}
get_footer();
